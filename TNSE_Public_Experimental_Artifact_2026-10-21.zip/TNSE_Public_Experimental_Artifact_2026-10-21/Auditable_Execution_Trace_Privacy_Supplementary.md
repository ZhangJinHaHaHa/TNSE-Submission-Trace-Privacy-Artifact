> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Submission-trace privacy: revised technical supplement

**Manuscript:** *Auditable Submission-Trace Privacy for Stateful Trading Agents*  
**Previous ID:** TNSE-2026-07-2191  
**Revision baseline:** 4 October 2026; physical-edge addendum: 17 October 2026; reproducibility amendment: 21 October 2026

This document links the formal claim to the implemented evidence without merging distinct test harnesses. There are three primary evidence layers: (1) the accepted-order synthetic LOB benchmark, (2) a **paired-state, scheduled-trace synthetic LOB kernel** that runs randomized disposition and noisy order fields together, and (3) a **separate** signed-slot accounting/export test. A targeted Qwen2.5-3B-Instruct checkpoint run on a short LOBSTER historical replay, the offline prompt surrogate, and local fault diagnostics are additional, independently scoped studies. No single artifact combines a signed production gateway, all exchange lifecycle events, a live venue, and an externally anchored ledger.

## A. Conditional privacy statement and implementation assumptions

Let adjacency change one declared component of a fixed agent state while holding the other components fixed. For each public decision slot and each public history feasible under either adjacent state, a versioned certificate must define a *nonempty, deterministic* action cell of diameter `Delta_t = 4`, `Delta_q = 4`, and `Delta_d = 3` in the protected coordinates. A raw no-order action maps to a public default inside the same cell. With five possible status labels and `epsilon_o = 0.25`, randomized response emits a fixed-schedule status. If the public output is `order`, the authorized action — including the public default after a raw no-order decision — is randomized with two-sided Laplace timing and delay noise, Gaussian signed-quantity noise, and deterministic post-processing for lot size, side, splits, and public price. An `order` token without a corresponding executable cover-order path cannot be treated as venue-level masking of raw absence.

The interactive proof requires a per-slot conditional kernel satisfying the bounds for **every common public prefix**. Any downstream market and venue observations must depend only on that public prefix and already randomized outputs; a raw-state-dependent price rule, routing rule, cancellation, unrandomized reject, telemetry field, or missing placeholder violates the premise. The primary benchmark's raw no-order and private-dependent decision interval violate it. The new synthetic kernel exercises fixed scheduled submissions but **does not simulate every subsequent acknowledgment, partial fill, cancellation, and modification** as one fully protected public lifecycle. A real venue with no public placeholder/disposition channel is outside the claimed ideal complete-trace ETI contract.

For a fixed schedule of `T` live slots, randomized status cost `epsilon_o` per slot, additional action cost `epsilon_a = epsilon_t + epsilon_q + epsilon_d` for at most `m` final public `order` outputs, and Gaussian failure `delta_a` per action, the conditional gated-kernel bound is `(T*epsilon_o + m*epsilon_a, m*delta_a)`. At a disposition-available slot the implementation first samples a **latent** randomized-response candidate `r_i`, then publishes `tilde z_i = F(h_{i-1}, r_i)`, where `F` is a deterministic coarsening using the public history and the already sampled candidate. When the action cap or remaining action budget blocks an action, `F` maps latent `r_i=order` to final public `budget-exhausted`; this final status is not deterministic from the prior public prefix alone and the `epsilon_o` RR charge has already been incurred. Only when the **disposition channel** is exhausted before sampling does the implementation emit a prefix-determined `budget-exhausted` token with zero additional charge. This conditional statement does not establish that a proposed real implementation enforces the certificate or that all venue fields have been classified correctly. A small measured attack AUC does not itself prove a small DP/ETI epsilon.

Raw proposals, raw no-order/rejection causes, pre-noise projected coordinates, membership labels, and signing keys are **not** PETI-adversary outputs. Research-only session metrics contain labels for scoring but cannot serve as deployment telemetry. The public signed slot ledger contains only final status, slot/certificate metadata, and budget recurrence. We removed projected coordinates from the legacy HMAC sample; its remaining post-noise fields do not make a keyed log publicly verifiable.

### 21 October 2026 release-validation calibration amendment

`experiments/strengthening/bounded_release.py` validates finite non-negative declared sensitivities and `0 < delta < 1`, and numerically calibrates the quantity channel with the exact one-dimensional analytic-Gaussian hockey-stick profile of Balle and Wang (2018): `Phi(mu/2-epsilon/mu) - exp(epsilon) Phi(-mu/2-epsilon/mu)`, with `mu = Delta_q/sigma`. The default keeps the larger of the legacy positive classic value and the analytic minimum, so it is conservative for the reported scales. The repaired pre-noise cells are signed quantity `[-2,2]`, timing `[0,4]`, and delay `[0,3]`, enforcing the declared diameters `(4,4,3)`; the separate post-noise output clipping retains quantity `[-2,2]` and timing/delay `[0,10]`. Zero declared sensitivity collapses the relevant pre-noise coordinate to a constant. `validate_release.py` writes calibration, projection-diameter, ordered-pair, and session checks to `experiments/strengthening/results/release_validation_projection_repair_2026-10-21/`. All three quantity scales pass the target `delta=1e-5`; 11 regression tests, 2,028 ordered coordinate pairs, and 24 session checks pass. These checks exercise the implementation premises rather than proving differential privacy by sampling. Historical outputs remain unchanged; they are not represented as having been regenerated by this repair.

## B. New paired-state scheduled synthetic LOB experiment

Run `experiments/end_to_end_trace_eval.py` from its parent directory with `--seeds 0 1 2 3 4 5 6 7 8 9 --pairs 100 --out results/pairedseq_temporal_mlp_rerun_2026-10-21`; this leaves the historical `results/end_to_end/` bytes unchanged. Each of ten independent seeds has 100 public market/risk/strategy paths, and each path is reused under protected membership states 0 and 1. Both states have separately seeded randomized release streams. This produces 2,000 raw and 2,000 protected sessions in total. Each session has 72 decision steps and 18 publicly scheduled decisions (one every four steps). Per protected slot, the script samples a latent five-category RR candidate and publishes the final state `F(h,r)`; only a final public `order` opens the action channel. It then projects a signed quantity and timing/delay offsets to the fixed cell, adds noise, derives side and splits from privatized quantities, and submits synthetic orders to the bundled LOB. A raw no-order decision can produce a **cover release** and a synthetic executable order. Future-dated orders are processed in a fixed-background continuation beyond the 72-step decision window, not silently dropped. This continuation is artificial and its P&L is not presented as a market-utility estimate.

The configured budget is `18 × 0.25 + 7 × (0.45 + 0.70 + 0.35) = 15.0` with `delta_max = 7e-5`. The public status and observed order fields form the attacker input. The research-only `session_metrics.csv` additionally includes membership labels and privacy accounting **for evaluation, not for the public observer**. `public_trace_sample.jsonl` contains two sampled views with public statuses and submitted-order fields but excludes labels, raw causes, `eps_after`, and projected inputs. `run_metrics.csv` contains the ten seed-level metrics and balanced test sizes. To prevent information leakage between matched paths, both private states of each path stay in the same train or test partition; per seed, 70 pairs are for training and 30 pairs (60 sessions, 30 per class) for testing. Feature-based and flattened 18-slot sequence logistic models use the provided public features; AUC uses tie-averaged ranks. The following logistic table is retained as the **frozen historical baseline** from `results/end_to_end/`; it is not relabeled as output of the 21 October public-array/TemporalMLP rerun.

| Ten-seed metric | Raw submissions | Fixed-slot protected view |
| --- | ---: | ---: |
| Feature-attacker AUC, seed mean ± SD | 0.995 ± 0.006 | 0.514 ± 0.085 |
| Flattened-sequence AUC, seed mean ± SD | 0.977 ± 0.013 | 0.517 ± 0.090 |
| Maximum realized epsilon | 0 | 15.0 |
| Mean realized epsilon | 0 | 10.222 |
| Raw no-order → authorized synthetic cover release | 0 | 3,689 across 2,000 protected sessions |
| Sessions reaching seven authorized releases | 0 | 131 |

On the ten paired outer seeds, the mean raw-minus-protected feature AUC difference is `0.481`; a percentile interval from **50,000 fixed-seed bootstrap resamples of the ten seed effects** is `[0.434, 0.530]`. The corresponding sequence difference is `0.460`, interval `[0.406, 0.509]`. These intervals summarize only the synthetic seed variation under two specified attacks; they are not distribution-free confidence about historical markets. `robust_analysis/make_integrated_figure.py` generated the retained historical `results/end_to_end/integrated_results.pdf`; the current manuscript instead uses `paired_kernel_diagnostics.pdf`, copied from the new paired-TemporalMLP figure described below. The worst-case bound `epsilon = 15` is loose, cover traffic can impose real financial costs, and the simulator carries 1,750 split-order events beyond the decision horizon under artificial fixed-background conditions. No claim of profitable trading or optimal attacker robustness follows. Public trace samples and session-level data must not be confused: only the former describes the adversary input.

The 21 October rerun additionally exports `public_sequences_raw.npz` and `public_sequences_protected.npz` (and an aligned combined `public_sequences.npz`) in a common ordered `18 x 9` final-public-observation schema; score labels are isolated in `scoring_labels.csv`. The two conditions share a paired exogenous path and an identical observer schema, but not the same realized public sequence: raw is the direct-output baseline and protected is the randomized fixed-slot output. `robust_analysis/paired_temporal_mlp.py` fits a fixed-design order-sensitive `64,32` MLP after **training-only** standardization, with the same pair-disjoint 70/30 split in both conditions (140 train and 60 test sessions per mode/seed) and five fixed model initializations. Across the ten generation seeds, raw AUC is `0.969 ± 0.016` and protected AUC is `0.512 ± 0.071` (mean ± seed SD); the paired raw-minus-protected difference is `0.457 ± 0.066`, with a 10,000-resample generation-seed bootstrap interval `[0.417, 0.493]`. These are a stronger trained temporal diagnostic on the synthetic kernel, not evidence about an optimal attacker, a real venue, hardware, historical markets, or an LLM. `outputs/pairedseq_temporal_mlp_2026-10-21/pairedseq_integrated_results.pdf` is a new three-panel figure; it does not replace `results/end_to_end/integrated_results.pdf`.

## C. Independent fixed-slot accounting and full export

`experiments/revised_protocol_smoke.py` runs ten seeds × 80 sessions × 72 fixed slots. It generates raw `order`/`no-order` decisions from synthetic random values and then applies the status channel, quantity *projection counter*, a maximum of seven accepted actions, and per-slot budget accounting. Each disposition-available slot draws a latent RR candidate `r` and exports only `F(h,r)` as its final public status; an action-cap coarsening can therefore turn a latent candidate `order` into final `budget-exhausted` after charging the RR channel. Only a pre-draw disposition-channel cap yields a deterministic no-charge terminal token. Unlike the new paired LOB experiment, this smoke test does **not** generate the protected Laplace/Gaussian venue-facing order tuple or train an attacker. Genuine raw `reject` and `audit-failure` branches are not exercised: those labels can arise as randomized *public outputs* only. The two scripts must not be described as one runtime implementation.

The configured and maximum realized limits are `epsilon_max = 28.5` (`72 × 0.25 + 7 × 1.50`) and `delta_max = 7e-5`. The summary reports 800 sessions and 57,600 slots, 5,599 authorized releases, a raw no-order rate of 41.59%, and 12,773 intermediate **latent** randomized `order` candidates. Action-cap filtering occurs in 797/800 sessions (99.625%), whereas all 800 sessions contain a final `budget-exhausted` label, which can also arise natively from RR. There are 17,971 final labels: 7,174 action-filter coarsenings and 10,797 native RR labels; no pre-RR terminal slot occurs in this run. The 7,174 coarsened candidates are not previously published public orders. Quantity projection occurs in 3,150 of **5,599 authorized releases = 56.26%**. The earlier 24.66% value divided by all 12,773 intermediate candidates, including the 7,174 without an action, and should not be called an accepted-release clipping rate. The canonical reconciliation is in `outputs/budget_status_diagnostics_2026-10-21/`; frozen historical field names are retained and mapped there to their exact meanings.

Authorized-release counts, separately from cover counts or budget labels, are:

| Releases per session | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | Total sessions |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Paired protected kernel | 32 | 132 | 298 | 400 | 455 | 348 | 204 | 131 | 2,000 |
| Independent accounting test | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 799 | 800 |

Reaching the seven-release cap (799 accounting sessions) differs from later attempting an action that is filtered (797 sessions).

Every slot, including non-order and exhausted ones, now has a signed `ledger_full.jsonl` entry. `verify_export.py` verifies every Ed25519 signature with the supplied public key; replays SHA-256 linkage and compares the end head with `anchor_receipt.json`; checks each session's contiguous slots 0–71, all incremental/cumulative epsilon and delta values, configured bounds, accepted release count, and agreement with `disposition_events_public.jsonl`. `ledger_sample.jsonl` contains only the first 20 entries for inspection. **No per-slot raw-status file is exported**; only aggregate synthetic session counters remain. The local receipt and public key are produced by the same party: a dishonest holder can replace **both** and create a new valid local chain. Detection of a replaced or truncated export relative to an earlier state requires an independently registered key and an independently held trusted checkpoint. Signature validity alone does not verify the sensitivity certificate, the honesty of the raw status, venue submission, or key custody.

The 21 October rerun is preserved separately at `experiments/results/revised_protocol_rerun_2026-10-21/`; it fixes the summary denominator to `release_count` and passes `verify_export.py` for all 57,600 entries, 800 sessions, and 5,599 accepted releases. It does not overwrite or retroactively relabel the historical `results/revised_protocol/` ledger.

## D. Legacy accepted-order benchmark and derived analyses

`experiments/eti_lob_benchmark.py` is retained for comparability with the earlier five-seed results. It models a price-time-priority synthetic book, market background events, a hand-specified protected policy, feature/sequence attackers, and privacy-utility diagnostics. It calls the action-release routine **only if the private policy already decided to submit an order**. It has no fixed no-order disposition, hard session cap, pre-release session filter, or validated full venue lifecycle. `robust_analysis/regenerate_no_order.py` now reproduces `no_order_by_membership_summary.csv` from the current policy and paired 60-episode seeds: the raw no-order rates are **63.39% versus 42.64%** for membership 0 and 1. The earlier 63.07% versus 37.23% table did not reproduce from the supplied source and was replaced. Either way, raw absence is a visible side channel. The `full` configuration shares the accepted-order kernel with `eti_ledger` and is not a separate integrated executor. Its HMAC ledger has no public verification key; the revised export drops pre-noise projected fields but is still a keyed diagnostic rather than the Ed25519 slot ledger.

The tie-averaged AUROC function was repaired and the five-seed benchmark, privacy curve, and paired checks rerun. No Defense and ETI-Only ensemble AUCs remain `0.988 ± 0.018` and `0.723 ± 0.172`; the corresponding synthetic Sharpe-like values are approximately `−5.08` and `−16.85`. The four privacy-curve AUC means are approximately `0.817`, `0.813`, `0.801`, and `0.782` for calibration scales `0.35`, `0.50`, `1`, and `2`, with maximum realized epsilon `8.4`, `12`, `24`, and `48`. These are descriptive stress measurements, not a monotone utility-optimal operating point. The repaired `robust_analysis/paired_feature_check.py` uses paths *inside* this archive. Without the `ledger_entries` diagnostic, ETI-Only and ETI+Ledger have identical non-ledger features and the same five-seed LR AUC mean, `0.64068` (60 episodes/seed); this corrects the older unverified `0.73065` sentence. `robust_public/primary5/ledger_sample.jsonl` is a research-only HMAC debug sample, not the signed public slot ledger.

## E. Checkpoint, prompt surrogate, and local edge diagnostics

`experiments/augmented/llm_edge_experiment.py` implements `TinyPromptPolicy-hash32-v1` using UTF-8 prompt text, an eight-dimensional public observation, a four-dimensional private state, and structured JSON action. Fixed seed 17 makes its behavior reproducible. Its raw prompt/state membership AUC is `1.0`; after the legacy action release, tested variants range from approximately `0.574` to `0.606`. No pretrained LLM weights, inference engine, chain-of-thought, or learned financial policy are involved. Do not substitute these values for results about a specified real model.

The strengthening directory contains two pretrained-checkpoint interface experiments. The historical 384-call archive retains parser-normalized action rows but not raw completions. In addition, the completed three-condition Qwen2.5 audit made 960 unique model calls and retains 1,152 completion/action rows because public-only responses are cached across the two membership values. Public-only and explicit-state records were strictly valid in 384/384 cases each; hidden-state strict validity was 371/384, with 13 length-invalid completions. The server rejected the requested JSON-schema format, so the run used the explicitly recorded `json_object` fallback rather than schema-constrained decoding. The manifest records model, prompt, replay, server, and parser hashes/settings. Invalid rows are retained for auditability but use a documented sentinel only in parser-inclusive aggregates; hidden AUC from those rows is not treated as a clean model-behavior estimate. This is a checkpoint/interface test, not a claim about arbitrary LLMs or model-training privacy.

To audit how the protected state changes generated actions, `robust_analysis/llm_counterfactual_sensitivity.py` holds the public replay, seed, episode, and step fixed and pairs membership 0 and 1 only when both rows are strict-valid. It excludes invalid or incomplete pairs without sentinel or imputation and resamples complete `(seed, episode)` clusters for 5,000 bootstrap draws. In the explicit-user condition, the raw membership-1 minus membership-0 changes for quantity, urgency, and delay are `+0.0573`, `−0.0458`, and `+0.4065`, with intervals `[0.0294,0.0880]`, `[−0.0799,−0.0195]`, and `[0.2224,0.6145]`. In the hidden-system condition, 179 strict pairs were available and 19 complete episodes (152 pairs) were used for the estimate; the corresponding changes are `+0.0556`, `−0.1253`, and `+0.5517`, with intervals `[0.0247,0.0908]`, `[−0.1837,−0.0711]`, and `[0.2456,0.8994]`. Side differences remain zero. These values show measurable numeric conditioning of one checkpoint interface, not semantic policy correctness, privacy, or arbitrary-LLM generalization.

As a post-hoc nonlinear sensitivity check, `robust_analysis/paired_public_rf.py`
fits a fixed 35-tree `RandomForestLite` (depth 5, minimum leaf 5, no tuning) on
the protected public features `f0`--`f10` using the same pair-disjoint 70/30
split as the primary evaluation. Across the ten saved seeds, static RF AUC is
`0.5311 ± 0.0810` (mean ± seed SD). The per-seed CSV and manifest retain the
split and estimator settings. This is a descriptive static attacker check; it
does not establish temporal, adaptive, optimal, or distributionally robust
attacker resistance. The adjacent operational-burden CSV reports epsilon,
release, cover, projection, order-event, and late-event summaries for raw and
protected sessions; its P&L field is explicitly simulator-only.

For a future deployment study, the operator should preregister a utility gate
before inspecting held-out outcomes: maximum cover-release rate, maximum
late-event rate, maximum realized session $(\varepsilon,\delta)$ expenditure,
and a nonnegative held-out objective under a fixed risk limit. Any failed gate
should reject the configuration or route it to a private/manual path. The
present simulator does not choose thresholds from its negative P&L and
therefore does not claim that a deployment operating point passes this
protocol.

`lobster_replay.py` derives 240 public rows from the LOBSTER AAPL 10-level sample dated 2012-06-21 and retains the supplied event labels; this is the short replay used by the Qwen interface audit. Separately, `lifecycle_replay.py` summarizes 2,000 observable LOBSTER messages and their order-level transitions. Neither artifact reconstructs a live venue, queue position, agent acknowledgments, or external market-data validation. The raw vendor archive and model weights are intentionally not redistributed.

For session-level coverage, `strengthening/lobster_replay_full_day/` contains a
compressed derived replay package for all 400,390 messages in the same AAPL
session (09:30:00.004--15:59:59.913) and `lifecycle_full_day_metrics.json`.
The audit reports 191,015 submissions, 180,930 closed submitted orders
(94.7203%), 10,034 open (5.2530%), and 51 partial (0.0267%). Closed-order
lifetime median/p95/p99 are 0.328162/13.495941/41.369791 seconds; message
interarrival median/p95/p99 are 0.000638858/0.348237/0.997796 seconds. It finds
zero underflow clamps and two deletion-size mismatches, which remain explicit
data-quality findings. Hidden executions have order ID 0 and are excluded from
order-level inference. The full-session artifact is still an observable
market-message audit, not a matching engine, queue, ACK, venue-latency, or live
trading lifecycle.

The original edge diagnostic measures a local software path under artificially injected RTTs of `0.5`, `1`, `5`, and `20` ms. Edge-local message size is 416 bytes versus 716 bytes for the proxy path; edge p95 latency is approximately `0.268`, `0.291`, `0.684`, and `2.188` ms, versus proxy `0.699`, `1.200`, `5.187`, and `20.189` ms. Those rows are software-only and exclude physical-board, NIC, external-network, live-gateway, and exchange-acknowledgment effects. The separate physical-host run is recorded below; its timings use the same injected-delay interpretation and are not a production network measurement.

`experiments/strengthening/edge_fault/` adds a bounded local fault matrix with 2,300 fixed-slot events. It covers normal release, no-order, invalid proposal, reject, timeout, signing failure, and a deterministic four-release cap stop. Every event receives one local fixed-slot mock-heartbeat callback; signing and timeout faults suppress transport. Component and end-to-end p50/p95/p99 timings, CPU/RSS, and bytes are recorded. The transport and heartbeat are in-process mocks, so these files are software diagnostics rather than hardware, network, venue, or independent-audit evidence.

## F. Reproduction, provenance, and remaining validation

The primary entry-point commands, package inventory, and current checksums appear in `README_SUBMISSION_READY.md`, `EXPERIMENT_INVENTORY.md`, and `SHA256SUMS.txt`. The new paired experiment's `summary.json` includes its script and imported benchmark SHA-256 hashes, Python/NumPy/pandas versions, seeds, and pair count; the accounting `summary.json` reports the exported-log verifier result. A freshly generated Ed25519 key makes the ledger bytes nonidentical between reruns, even though deterministic aggregate counts match. Recompute `SHA256SUMS.txt` **after** changing any result or README.

A next-stage venue validation still needs a licensed/live market-data or testnet endpoint, full preprocessing and calibration records, economically feasible cover orders, downstream event reconciliation, and a separately registered audit key/checkpoint. The included historical replay and checkpoint run strengthen input realism and model-interface evidence but do not satisfy those systems premises. The archive records these proof, experiment, claim, reference, publication-policy, and AI-use boundaries explicitly; it does not claim validation beyond the supplied evidence.

## G. Physical Jetson Edge-platform run

The archive `experiments/physical_edge/TNSE_Edge_Board_Results_20261017T190612Z.zip`
records the 17 October 2026 run on a physical NVIDIA Jetson Orin-class ARM
host. The read-only probe reports `aarch64`, Linux `5.15.148-tegra`, 12
Cortex-A78AE CPUs, approximately 61 GiB RAM, and `nvidia-smi` output
`Orin (nvgpu)` with driver `540.4.0`. Readable thermal zones were approximately
43.4--48.2 degrees Celsius at probe time. `tegrastats --count` was unsupported
on this image, so sustained utilization, power, and throughput are not claimed.

Every validation/experiment step that records a status returned code 0, and the
packaging command produced the complete result archive. The deterministic local lifecycle replay
processed 2,000 rows and emitted 1,740 local ACKs (1,681 accepted and 59
rejected), 708 cancels, 119 fills, 31 modifies, and 913 resting events; 942
checked orders had zero quantity-conservation mismatches, and all five
deterministic FIFO/cancel/replace/reject scenarios passed. The offline
structured surrogate measured local p95 latency of approximately `0.127`,
`0.172`, `0.569`, and `2.072` ms at injected RTTs of `0.5`, `1`, `5`, and `20`
ms, respectively, with zero local deadline misses under the configured 5-ms
deadline. The `edge_fault_stdlib` matrix covered 2,000 normal events, five
200-repeat fault branches (`audit-signing-failure`, `invalid-proposal`,
`no-order`, `reject`, and `timeout`), and eight budget-exhaustion samples,
3,008 branch samples in total. Every fault branch suppressed sends and
fail-closed/fixed-slot heartbeat invariants passed. Its SHA-256 test token is
not Ed25519 evidence. Release validation used 10,000 samples per status scale
and 24 session-invariant runs.

This board run is platform and software-harness evidence only. The local ACK,
fill, cancel, and modify events are emulator events rather than historical
venue records; the injected RTT is not a network trace; and no queue position,
venue protocol, live/testnet endpoint, NIC performance, third-party anchor, or
external Ed25519 evidence is established. `pretrained_llm_SKIPPED.txt` is
included explicitly: the optional pretrained-LLM runner did not execute on the
board. The separate Qwen checkpoint/interface studies remain independently
scoped and are not merged with this hardware run.


## Final 21 October release clarifications

The additional 18x9 attacker arrays represent the declared scheduled-release interface: five final-status indicators plus bounded signed total quantity, reservation-time offset, submission delay and independent split count. Reservation fields are treated as observable in this instrumented interface; the arrays are not reconstructed venue due-time traces. Membership, raw proposals and private accounting remain excluded from model inputs. The new same-kernel observable burden is in `outputs/pairedseq_temporal_mlp_2026-10-21/new_kernel_operational_burden.csv`; cover/projection labels are internal research diagnostics and post-horizon events are artificial-continuation submissions, not measured network deadline misses.

The generator source used for the fresh arrays is preserved under `experiments/results/pairedseq_temporal_mlp_rerun_2026-10-21/source_at_generation/`; the active entry point clarifies the internal RR candidate and checks disposition-budget availability before querying the raw policy. All 4,000 default-run sessions and public arrays were compared against that snapshot in the same environment and remain exactly equal. The generation manifest source hash identifies the preserved generation snapshot, not the current entry point. Inventory excludes itself and SHA256SUMS to avoid circular hashes; the final SHA256SUMS includes both inventory files.

### Common checkpoint parsing and source records

Both checkpoint runners now import the same integer-side strict parser. Reclassification of the retained raw completions changes no Qwen2.5 classification and no bounded action from either checkpoint. For Qwen3, public-only strict/normalized counts are 178/206 out of 384 (46.35%/53.65%); explicit and hidden conditions are each 384/384 strict. The 96 reclassified public records used floating-point `side: 1.0`. Historical summaries retain the original parser's 71.35% result and are explicitly identified as historical, not the current comparison. Canonical row-level classifications, aggregate results, raw hashes and parser hashes are under each checkpoint's `canonical_reanalysis_2026-10-21/` directory.

The checkpoint runs use the same AAPL sample source but different 240-row and 2,000-row prefixes. Qwen2.5 latency includes the local HTTP request and fallback retry; Qwen3 latency covers `model.generate` only, excluding tokenization and decoding. No cross-host speed ranking is inferred. Source and execution records are retained with each checkpoint; recovered records are distinguished from fields absent from the original archive.
