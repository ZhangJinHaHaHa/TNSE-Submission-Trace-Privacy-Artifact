# TNSE public experimental artifact — 2026-10-21

This is a **public subset**, not the complete submission supplement and not a new
experimental run. The original submission ZIP is unchanged. Its SHA-256 and size
are recorded in `SOURCE_ARCHIVE.json`.

Public repository: <https://github.com/ZhangJinHaHaHa/TNSE-Submission-Trace-Privacy-Artifact>.
No Zenodo DOI has been assigned in this package.

## Start here

- `PUBLIC_FILE_INVENTORY.csv` describes the files actually in this public tree.
- `SHA256SUMS.txt` verifies every public file except itself; it also verifies the
  inventory. Run `python3 public_release_tools/verify_public_release.py .` after
  extracting the ZIP. The verifier also checks the two rebuilt nested archives.
- `PUBLIC_CHANGELOG.json` lists every excluded, modified, relocated, or added
  item without reproducing excluded event values or model prompts.
- `PUBLIC_REBUILD_INSTRUCTIONS.md` explains separately acquired inputs and what
  can and cannot be reproduced from this public subset.

## Deliberately absent

LOBSTER message/order-book replay CSVs, historical per-event lifecycle traces,
and raw-event mismatch examples are not distributed here. Both nested archives
are explicitly renamed public subsets; their safe summaries and metadata remain.
Qwen2.5 `raw_completions.jsonl` and `raw_completion_samples.jsonl` are absent:
their input prompts contain historical observations, and some malformed model
responses repeat those observations. Removing prompts alone would not suffice.
Qwen2.5's `action_rows.csv` is also absent because some numeric actions coincide
with observation components. Its canonical `parse_records.jsonl` is a clearly
marked public derivative: `canonical_action` values are removed, while row-level
parse decisions, source-line hashes and the unchanged aggregate analysis remain.
No model weights, tokenizer assets, or model configuration files are included.

The retained public-derivative Qwen2.5 parse records, summaries and source
hashes document the previous analysis, but **cannot replace the withheld raw
completions or enable independent raw-text re-parsing**. Qwen3 raw completions
remain because the retained records contain numeric model outputs and metadata,
not the historical input prompts; the Qwen3 cache provenance limitations remain.
Re-running either model is a new run, not recovery of the frozen raw evidence.

## Preserved evidence and limits

Author source code, synthetic experiments, aggregate results, canonical analyses,
safe physical-board records and the operator photo are retained. Existing
experimental results have not been recomputed, and no LLM, GPU or board run was
performed to make this package. Aggregate mismatch counts remain unchanged even
though their event examples are omitted. Ordinary machine metadata and hashes
are not presented as secret data or as proof of redistribution permission.

All pre-existing experiment manifests, provenance records, audit reports and
submission documents describe the **historical source experiments/submission**.
Their paths and hashes may refer to inputs or payloads deliberately absent here.
They are not the inventory of this public release, and do not assert that missing
files can be fetched publicly. `HISTORICAL_METADATA_INDEX.csv` identifies these
records, including the renamed source inventories under
`historical_submission_manifests/`. In rebuilt nested ZIPs, the corresponding
`PUBLIC_FILE_INVENTORY.csv` and `SHA256SUMS.txt` are the current member lists;
old manifests remain explicitly historical. A checksum mismatch against an old
manifest is not resolved by pretending that a public subset is the frozen ZIP.

Existing rights are retained; the artifact is made available for public download
without adding an MIT, CC BY, or other open-source/data license. Third-party
materials remain subject to their applicable terms; source links and hashes are
not a grant of permission. See the acquisition notes before obtaining inputs or
redistributing locally reconstructed data. This release makes no legal warranty.

The title, experiment scope and findings are not changed by selective public
distribution. This archive is intentionally named a public experimental artifact,
not an unconditionally complete or final reproduction package.
