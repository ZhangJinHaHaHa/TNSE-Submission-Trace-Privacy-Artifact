> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# TNSE revised experiment supplement — reproducibility archive

**Manuscript:** *Auditable Submission-Trace Privacy for Stateful Trading Agents*  
**Previous manuscript ID:** TNSE-2026-07-2191  
**Revision baseline:** 4 October 2026; physical-edge addendum: 17 October 2026; reproducibility amendment: 21 October 2026

This archive documents the revised experiments and their evidence boundaries. It is not a claim that a real execution gateway has been validated. The manuscript and response letter distinguish the experiments below instead of combining their capabilities. The archive is provided to support reproducibility and to prevent legacy labels from being mistaken for a full ETI implementation.

## Evidence map

| Layer | Script and output | What it supports | What it does not support |
| --- | --- | --- | --- |
| Legacy accepted-order LOB benchmark | `experiments/eti_lob_benchmark.py`; `experiments/robust_public/primary5/` | Five-seed descriptive attack, privacy-utility, and local simulation measurements | No fixed no-order schedule, hard session cap, complete public trace, or publicly verifiable HMAC log. The historical `full` configuration is not a fully integrated executor. |
| Paired-state scheduled synthetic LOB kernel | `experiments/end_to_end_trace_eval.py`; frozen `experiments/results/end_to_end/`; fresh `experiments/results/pairedseq_temporal_mlp_rerun_2026-10-21/`; `experiments/robust_analysis/paired_public_rf.py` | Ten seeds, 100 matched public-path pairs/seed; RR, noisy time/quantity/delay, bounded cover orders, fixed slots, two logistic attackers, a post-hoc fixed static RF check, and session accounting in **one synthetic kernel**. The fresh rerun additionally preserves aligned public raw/protected arrays. | No signed gateway shared with the separate audit test, no real venue-visible no-op channel, no full exchange fill/cancel/modify lifecycle, no trustworthy utility replay, and no claim of an optimal attacker. |
| Paired fixed-slot TemporalMLP rerun | `experiments/robust_analysis/paired_temporal_mlp.py`; `outputs/pairedseq_temporal_mlp_2026-10-21/` | Fixed-design order-sensitive `64,32` MLP on the regenerated public `18x9` sequence schema, training-only scaling, identical pair-disjoint 70/30 raw/protected splits, five fixed initializations, seed bootstrap, and a separate three-panel diagnostic figure. | Synthetic kernel only; not an optimal attacker, real venue, hardware, historical-market, or LLM result. Raw and protected traces share paired exogenous paths and schema but are not identical sequence realizations. |
| Blocked temporal attacker audit | `experiments/robust_analysis/temporal_attacker_audit.py`; `experiments/robust_analysis/temporal_attacker_audit/` | Episode-blocked order-sensitive Temporal-MLP (five model seeds), bootstrap intervals, and label-permutation tests; AUC `0.6632 ± 0.0166` with mean permutation `p=0.0183` | Not a passed privacy result: the residual signal is reported as an attacker diagnostic, not evidence against adaptive, optimal, or distributionally robust attackers. |
| Signed-slot accounting and export test | `experiments/revised_protocol_smoke.py`, `experiments/verify_export.py`; `experiments/results/revised_protocol/` | 800 sessions × 72 slots; 57,600 Ed25519-signed slot records; 5,599 authorized releases; signature/hash/slot/budget checks of the full export | No noisy venue-facing timing/quantity/delay release in this test; no independent trusted public-key registration, timestamp or external checkpoint. |
| Checkpoint/replay and bounded fault diagnostics | `experiments/strengthening/` | Two local pretrained checkpoints (Qwen2.5-3B-Instruct and Qwen3-1.7B) on 240-row/2,000-row LOBSTER replays; strict-valid counterfactual field sensitivity with clustered intervals; a separate 400,390-message eight-window blocked lifecycle audit; bounded-kernel invariants; 2,300-event fail-closed local fault matrix | No arbitrary-LLM generalization, live venue, matching-engine/queue reconstruction, agent ACK lifecycle, edge board/NIC, external anchor, or independent audit. |
| Deterministic exchange-lifecycle emulator | `experiments/strengthening/exchange_lifecycle/`; `matching_engine_replay.py`, `deterministic_scenarios.py` | Single-threaded price--time FIFO software emulator with local ACK/reject, fill, cancel, modify, queue-order invariants, 2,000-row replay, and five deterministic scenario checks | Not a historical venue record, venue-protocol conformance test, network/venue latency measurement, physical Edge deployment, or live-exchange validation. |
| Prompt surrogate and edge diagnostics | `experiments/augmented/` | Structured offline prompt/state interface and local injected-RTT software timing | No pretrained-checkpoint generalization, edge board/NIC, testnet, or live exchange. |
| Physical Edge-platform run | `experiments/physical_edge/README_PHYSICAL_EDGE_RUN.md`; `TNSE_Edge_Board_Results_20261017T190612Z.zip`; `operator_photo/` | Read-only system probe; deterministic local lifecycle replay and five scenario checks; stdlib fail-closed/release checks; offline surrogate timing on the physical host; all validation/experiment steps recorded code 0 and archive packaging completed; operator-provided terminal photo retained as a visual run record only | The system probe is runtime inventory, not independent third-party certification. No model/capacity label is used as a hardware result; no sustained board throughput/power benchmark (`tegrastats --count` was unsupported), no live/testnet venue, queue/venue ACK truth, NIC/network measurement, third-party anchor, Ed25519 evidence, or pretrained-LLM run (explicitly skipped). |

The original public-market generator does not read the protected membership bit, but the legacy decision interval and order absence remain private-dependent. We removed `projected_*` pre-noise fields from the legacy HMAC diagnostic export; it now contains post-noise fields, but the HMAC log remains **non-publicly-verifiable**. In the newer scheduled experiment, feature attacks use statuses and synthetic submitted-order summaries; the flattened sequence additionally uses the declared released reservation fields described below, not a reconstructed venue-time trace. `session_metrics.csv` contains protected labels **only to score this synthetic research experiment**, so it must never be a deployment telemetry schema. `public_trace_sample.jsonl` omits labels and private accounting metadata.

## Reproduction

Install the exact non-model runtime tested for the 21 October amendment with `python3 -m pip install -r requirements-core.txt` (Python 3.12.3 in the recorded rerun). The optional model template is deliberately not a standalone Qwen3 reproduction environment: `requirements-model-template.txt` records that the archive lacks an authorized Qwen3 URI, revision, tokenizer revision, and redistribution permission, and does not guess them. From the archive root, first run `sha256sum -c SHA256SUMS.txt`; then enter `experiments/` to run the scripts below. Ten seeds and 100 pairs each generate 2,000 protected and 2,000 raw sessions; the revised five-seed legacy benchmark and derived analyses may take longer than the smoke tests.

```bash
# Check the packaged bytes BEFORE any rerun changes the signed ledger.
sha256sum -c SHA256SUMS.txt
cd experiments
python3 -m py_compile eti_lob_benchmark.py end_to_end_trace_eval.py \
  revised_protocol_smoke.py verify_export.py \
  augmented/llm_edge_experiment.py \
  robust_analysis/extended_analysis_revised.py \
  robust_analysis/paired_feature_check.py \
  robust_analysis/regenerate_no_order.py \
  robust_analysis/make_integrated_figure.py \
  robust_analysis/paired_public_rf.py
python3 eti_lob_benchmark.py --seeds 0 1 2 3 4 --episodes 50 --steps 72 \
  --out robust_public/primary5
python3 robust_analysis/extended_analysis_revised.py --out robust_public
python3 robust_analysis/paired_feature_check.py
python3 robust_analysis/regenerate_no_order.py
python3 end_to_end_trace_eval.py --seeds 0 1 2 3 4 5 6 7 8 9 \
  --pairs 100 --out results/pairedseq_temporal_mlp_rerun_2026-10-21
python3 robust_analysis/paired_temporal_mlp.py \
  --input results/pairedseq_temporal_mlp_rerun_2026-10-21 \
  --out ../outputs/pairedseq_temporal_mlp_2026-10-21
python3 robust_analysis/make_pairedseq_integrated_figure.py \
  --input results/pairedseq_temporal_mlp_rerun_2026-10-21 \
  --attack ../outputs/pairedseq_temporal_mlp_2026-10-21 \
  --out ../outputs/pairedseq_temporal_mlp_2026-10-21
# `results/end_to_end/integrated_results.pdf` is a frozen historical figure;
# do not rerun robust_analysis/make_integrated_figure.py into that directory.
python3 robust_analysis/paired_public_rf.py --out robust_analysis/paired_public_rf
python3 revised_protocol_smoke.py --out results/revised_protocol_rerun_2026-10-21
python3 verify_export.py results/revised_protocol_rerun_2026-10-21
python3 augmented/llm_edge_experiment.py --out augmented/results
python3 strengthening/validate_release.py --out strengthening/results/release_validation_projection_repair_2026-10-21
python3 strengthening/edge_fault_benchmark.py --out strengthening/results/edge_fault_rerun
python3 strengthening/exchange_lifecycle/matching_engine_replay.py \
  --replay strengthening/lobster_replay_2000/lobster_replay_2000.csv \
  --out strengthening/exchange_lifecycle/results/rerun
python3 strengthening/exchange_lifecycle/deterministic_scenarios.py \
  --out strengthening/exchange_lifecycle/results/scenarios_rerun
```

The physical-board evidence is retained under `experiments/physical_edge/`.
`TNSE_Edge_Board_Results_20261017T190612Z.zip` is the complete operator-run
archive; `key_outputs/` provides the board probe, lifecycle summary, scenario
checks, surrogate latency table, fault summary, release summary, and the
explicit `pretrained_llm_SKIPPED.txt` marker. The run was on an NVIDIA Jetson
Orin-class ARM host (`aarch64`, Linux `5.15.148-tegra`) and every packaged step
returned code 0. It therefore strengthens platform and software-harness
reproducibility, but it is not a hardware-throughput, live-exchange, network,
third-party-attestation, or pretrained-LLM result. See
`experiments/physical_edge/README_PHYSICAL_EDGE_RUN.md` for the complete
evidence boundary.

The strengthening archive also records the exact command-line identity for the
Qwen checkpoint run. Start a local OpenAI-compatible `llama.cpp` server and
run `strengthening/llm_pretrained_runner.py --model qwen2.5-3b-instruct-q4_k_m.gguf --model-path /path/to/qwen2.5-3b-instruct-q4_k_m.gguf`
against `strengthening/lobster_replay/lobster_replay.csv`; the recorded manifest gives
the model, prompt, replay hashes, server settings, and parser outcomes. The
archive contains a completed 960-unique-call, three-condition audit with 1,152
retained completion/action rows; public-only responses are cached across the
two membership values. Public-only and explicit-state records were strictly
valid in 384/384 cases each; hidden-state strict validity was 371/384, with 13
length-invalid completions. The raw model and LOBSTER vendor archive are not
redistributed. See `experiments/strengthening/real_llm_lobster/RERUN_AUDIT.md`
for the invalid-row policy and the reason hidden parser-inclusive AUC is not
used as a clean model estimate.

The Qwen 240-row replay is intentionally separate from the full-session
observable lifecycle audit in `experiments/strengthening/lobster_replay_full_day/`.
The latter covers 400,390 messages from the same AAPL session and reports
submission closure rates, lifetime/interarrival quantiles, left-censoring, and
two deletion-size mismatches. It remains a market-message audit; it does not
reconstruct a venue matching engine, queue position, agent ACKs, or live
execution.

The separate `strengthening/exchange_lifecycle/` directory contains an
in-house deterministic single-threaded price--time-priority emulator. On the
2,000-row replay it emits local ACK/fill/cancel/modify events and labels
synthetic stress orders; the five scenario checks exercise FIFO, partial fill,
cancel idempotence, replace, and reject paths. These are software-internal
events and invariants, not historical exchange records or physical Edge/
network-latency measurements.

The Ed25519 signing key is freshly generated on each accounting run, so the signatures and final head change while session counts and aggregate accounting statistics remain fixed. The local receipt is generated by the same operator; `verify_export.py` checks consistency **against the supplied receipt**, not external timestamping or operator honesty. Dynamic wall-clock edge diagnostics can vary by host. Only aggregate raw-status counters are retained for synthetic diagnostics: `disposition_events_public.jsonl` and the signed ledger **omit raw status**, and no raw per-slot status file or signing key is packaged.

The separate supplementary paper, `Auditable_Execution_Trace_Privacy_Supplementary.md`, records formulas, denominators, reproducibility notes, and limits. `EXPERIMENT_INVENTORY.md` / `.csv` and `SHA256SUMS.txt` enumerate the **current archive contents**; a checksum mismatch means the package or this README was edited after manifest generation. Regenerate checksums after all intentional edits, but do not imply a locally created checksum file is a third-party trust anchor.


## Final 21 October release clarifications

The additional 18x9 attacker arrays represent the declared scheduled-release interface: five final-status indicators plus bounded signed total quantity, reservation-time offset, submission delay and independent split count. Reservation fields are treated as observable in this instrumented interface; the arrays are not reconstructed venue due-time traces. Membership, raw proposals and private accounting remain excluded from model inputs. The new same-kernel observable burden is in `outputs/pairedseq_temporal_mlp_2026-10-21/new_kernel_operational_burden.csv`; cover/projection labels are internal research diagnostics and post-horizon events are artificial-continuation submissions, not measured network deadline misses.

The generator source used for the fresh arrays is preserved under `experiments/results/pairedseq_temporal_mlp_rerun_2026-10-21/source_at_generation/`. The active entry point clarifies the internal RR candidate and checks disposition-budget availability before querying the raw policy. A same-environment comparison against that snapshot preserves all 4,000 default-run sessions and public arrays exactly. The generation manifest source hash identifies the preserved snapshot, not the current entry point. Inventory excludes itself and SHA256SUMS to avoid circular hashes; the final SHA256SUMS includes both inventory files.

To reproduce the new manuscript burden table from the fresh rerun, after entering `experiments/`, use:

```bash
python3 robust_analysis/paired_operational_burden.py --input results/pairedseq_temporal_mlp_rerun_2026-10-21/session_metrics.csv --out ../outputs/pairedseq_temporal_mlp_2026-10-21
```

## Final consistency repair

The reported conclusions use the following canonical diagnostics. Frozen raw
completions, historical summaries, generated arrays and the Jetson result ZIP
remain unchanged; archived labels must not be substituted for the corrected
definitions below.

- `outputs/budget_status_diagnostics_2026-10-21/`: 797 accounting sessions
  undergo action-cap filtering, 799 reach seven releases, and all 800 contain
  a final exhausted label. Full authorized-release distributions are included
  separately for the 800 accounting and 2,000 protected paired sessions.
- `experiments/strengthening/*/canonical_reanalysis_2026-10-21/`: both
  checkpoints use one integer-side strict parser. Qwen3 public-only strict
  validity is 178/384 (46.35%); 206/384 (53.65%) require normalization.
  Reclassification changes no retained bounded action. Qwen2.5 classifications
  are unchanged. The old Qwen3 71.35% summary is preserved as historical.
- `experiments/strengthening/results/release_validation_projection_repair_2026-10-21/`:
  pre-noise projection diameters now enforce `(4,4,3)`, separately from output
  clipping. Regression and ordered-pair tests accompany the calibration data.
- `experiments/physical_edge/`: the locally retained compatible source snapshot
  is restored alongside the frozen outputs, with current file hashes and an
  independent audit of retained event rows. Two scripts and the replay input
  are also bound to hashes recorded for the historical run; the other six
  executed entry points lack historical source hashes. Local reproduction is
  not a new board measurement.

After entering `experiments/`, the first two data reconciliations can be run
without a model or GPU:

```bash
python3 robust_analysis/budget_status_diagnostics.py
python3 strengthening/reanalyze_checkpoint_parsing.py
python3 -m unittest discover -s strengthening -p test_bounded_release.py
```

The checkpoint-local provenance recovery record distinguishes recovered
execution arguments and historical file identities from upstream revision
and tokenizer hashes that were not recorded. No missing provenance is inferred
from the checkpoint name. The manuscript title, scope and AI disclosure are
unchanged by this consistency repair.
