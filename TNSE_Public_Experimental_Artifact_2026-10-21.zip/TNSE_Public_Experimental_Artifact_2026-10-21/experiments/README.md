> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Reproducible experiments

This supplement supports *Auditable Submission-Trace Privacy for Stateful Trading Agents*. It has a primary inference run, a separate protocol audit, a narrow real-checkpoint replay, and a bounded fault matrix. Install the tested non-model environment from `../requirements-core.txt`; `../requirements-model-template.txt` is intentionally not an independent Qwen3 rerun specification because no authorized Qwen3 URI/revision is supplied or guessed. Run from this directory with the recorded Python runtime.

```bash
python3 -m py_compile eti_lob_benchmark.py revised_protocol_smoke.py augmented/llm_edge_experiment.py robust_analysis/extended_analysis_revised.py
python3 eti_lob_benchmark.py --seeds 0 1 2 3 4 --episodes 50 --steps 72 --out robust_public/primary5
python3 revised_protocol_smoke.py --out results/revised_protocol_rerun_2026-10-21
python3 verify_export.py results/revised_protocol_rerun_2026-10-21
python3 end_to_end_trace_eval.py --seeds 0 1 2 3 4 5 6 7 8 9 --pairs 100 \
  --out results/pairedseq_temporal_mlp_rerun_2026-10-21
python3 robust_analysis/paired_temporal_mlp.py \
  --input results/pairedseq_temporal_mlp_rerun_2026-10-21 \
  --out ../outputs/pairedseq_temporal_mlp_2026-10-21
python3 robust_analysis/make_pairedseq_integrated_figure.py \
  --input results/pairedseq_temporal_mlp_rerun_2026-10-21 \
  --attack ../outputs/pairedseq_temporal_mlp_2026-10-21 \
  --out ../outputs/pairedseq_temporal_mlp_2026-10-21
# The legacy results/end_to_end/integrated_results.pdf is frozen; do not rerun
# robust_analysis/make_integrated_figure.py into its historical output folder.
python3 augmented/llm_edge_experiment.py --out augmented/results
python3 strengthening/lobster_replay.py --archive /path/to/LOBSTER_SampleFile_AAPL_2012-06-21_10.zip --out strengthening/lobster_replay
python3 strengthening/llm_pretrained_runner.py \\
  --model qwen2.5-3b-instruct-q4_k_m.gguf \\
  --model-path /path/to/qwen2.5-3b-instruct-q4_k_m.gguf \\
  --replay strengthening/lobster_replay/lobster_replay.csv \\
  --out strengthening/real_llm_lobster

python3 robust_analysis/paired_public_rf.py --out robust_analysis/paired_public_rf
python3 strengthening/validate_release.py --out strengthening/results/release_validation_rerun
python3 strengthening/edge_fault_benchmark.py --out strengthening/results/edge_fault_rerun
```

The `physical_edge/` directory contains the completed 17 October 2026 Jetson
Orin-class ARM board run: read-only platform probe, deterministic lifecycle and
scenario checks, standard-library fail-closed/release checks, offline surrogate
timing, and the explicit pretrained-LLM skip marker. It is a physical-host
reproducibility record, not a live venue, NIC/network, power/throughput, or
hardware-accelerator benchmark.

The LOB run uses NumPy/Pandas; the trained paired TemporalMLP additionally uses
scikit-learn; and the protocol smoke test additionally uses `cryptography` for
Ed25519. The primary kernel is intentionally retained as an accepted-order
stress test and reports realized privacy expenditure; the event-complete smoke
test enforces the disposition channel and hard session caps. The new paired
TemporalMLP rerun writes raw/protected public arrays in a common `18x9` schema;
they share paired exogenous paths and a pair-disjoint 70/30 split, but are not
the same realized public sequences. The `bounded_release.py` analytic-Gaussian
change is a 21 October release-validation strengthening only: it does not alter
the historical end-to-end generator (`EPS_Q=0.70`) or claim to regenerate
Qwen/Jetson/historical results. The strengthening scripts use two locally
served pretrained checkpoints only when an operator supplies authorized inputs;
Qwen3 cannot be independently rerun from this package because no source URI or
revision is available to disclose or guess. The packaged results are local,
narrow diagnostics rather than live-venue or arbitrary-model claims. The board
run's local ACK/fill events and injected RTTs are not venue acknowledgments or
network traces.
