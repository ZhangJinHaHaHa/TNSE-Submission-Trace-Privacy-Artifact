> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Offline LLM-proxy and edge validation artifact

This folder adds the two experiments requested by the TNSE reviews:

* **Prompt/model-state influence.** `llm_edge_experiment.py` runs the same
  public market observations through five prompt variants and two private
  model-state profiles. It records action disagreement, raw versus ETI
  released state-membership AUC, projection clipping, and the session privacy
  budget.
* **Edge path validation.** The script measures local policy, release, JSON
  serialization, and hash-chain work, then injects deterministic network RTTs
  (`0.5, 1, 5, 20 ms`) for an edge-local path and a cloud-proxy baseline. It
  reports p50/p95 end-to-end latency, communication bytes, throughput, RSS,
  and deadline-miss rate.

## Model disclosure

No pretrained LLM weights or network service are available in the offline
artifact environment. The policy is therefore explicitly named
`TinyPromptPolicy-hash32-v1 (offline deterministic surrogate)`. It has a
stable character 3-gram prompt embedding, a private four-dimensional state,
fixed seeded dense layers, and a structured JSON-like action decoder. It is an
executable LLM-like policy surrogate, not evidence about a particular GPT,
Llama, or proprietary model. Replacing the `TinyPromptPolicy.predict` method
with a locally available model preserves the output schema and experiment
design.

## Reproduction

From the archive root:

```bash
python3 experiments/augmented/llm_edge_experiment.py \
  --out experiments/augmented/results \
  --seeds 0 1 2 --episodes 40 --steps 32 --edge-events 120 \
  --rtts 0.5 1 5 20 --deadline-ms 5
```

Only Python 3.9+, NumPy, and pandas are needed. The script writes:

* `prompt_state_metrics.csv`: one row per seed and prompt; `raw_state_auc`
  and `eti_state_auc` use a balanced episode split. `action_*_vs_base` uses
  matched public observations. `max_session_epsilon` and
  `max_session_delta` are the predetermined worst-case accounting bounds for
  32 accepted releases (48 and 0.00032 here; the per-action epsilon is 1.5).
  The `state_raw_*_delta` and
  `state_eti_*_delta` columns directly quantify how switching only the
  protected model state changes aggregate generated actions before and after
  release.
* `prompt_state_action_samples.csv`: auditable first-two-episode action rows
  for each seed/prompt/state, before and after release.
* `edge_event_metrics.csv`: per-event measurements and injected network delay.
* `edge_latency_summary.csv`: grouped p50/p95 latency, communication,
  throughput, RSS, and deadline misses.
* `manifest.json`: seeds, dimensions, release certificate, runtime, and model
  disclosure.

## Interpretation and limits

The ETI state-AUC reduction is an empirical stress test of public action
inference, not a proof beyond the declared sensitivity certificate. Prompt
perturbations intentionally include wording changes and an irrelevant
instruction; the case/whitespace variant is canonicalized and therefore
should produce zero action disagreement. The edge experiment injects network
delay instead of contacting a live exchange or cloud; it demonstrates the
measurement protocol and communication/latency trade-off, not production QoS.
Wall-clock compute values can vary across hosts, while the injected network
component, seeds, dimensions, and byte accounting are fixed. RSS is a
process-level diagnostic rather than a container memory limit.

In the generated run, raw state membership is perfectly separable for this
small surrogate (AUC 1.0) and ETI lowers it to roughly 0.57--0.61 depending
on the prompt. The edge path sends 416 bytes/event versus 716 bytes/event for
the cloud proxy and stays under a 5 ms deadline at the tested RTTs; the cloud
proxy misses that deadline once the injected RTT reaches 5 ms. These numbers
are artifact-level evidence only and should be labeled as a surrogate and
simulated network study in the manuscript.
