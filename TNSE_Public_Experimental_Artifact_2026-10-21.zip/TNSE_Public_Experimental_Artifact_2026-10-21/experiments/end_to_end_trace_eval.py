#!/usr/bin/env python3
"""Synthetic, end-to-end scheduled-trace evaluation, not exchange validation.

All observations given to the attacker are public mechanism outputs: a fixed-slot
five-way disposition token and, only on an authorized order token, order fields
obtained from privatized timing, signed total quantity and delay. A no-order raw
proposal maps to the public cell centre and may produce a *real synthetic cover
order* after randomized response; this is costly and not a live-venue feature.
Paired membership states share exogenous market inputs, never private labels.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
from pathlib import Path

import numpy as np
import pandas as pd
from eti_lob_benchmark import (
    BinaryLogistic, LimitOrderBook, auc_score, execute_event,
    public_center, public_series, raw_policy, standardize,
)

EPS_O, EPS_T, EPS_Q, EPS_D, DELTA = 0.25, 0.45, 0.70, 0.35, 1e-5
DT, DQ, DD = 4.0, 4.0, 3.0
STEPS, INTERVAL, MAX_ORDERS = 72, 4, 7
SLOTS = STEPS // INTERVAL
EPS_MAX, DELTA_MAX = SLOTS * EPS_O + MAX_ORDERS * (EPS_T + EPS_Q + EPS_D), MAX_ORDERS * DELTA
LABELS = ('order', 'no-order', 'reject', 'budget-exhausted', 'audit-failure')
STATUS_INDEX = {name: i for i, name in enumerate(LABELS)}


def random_status(raw: str, rng: np.random.Generator) -> str:
    p = np.ones(len(LABELS), dtype=float) / (math.exp(EPS_O) + len(LABELS) - 1)
    p[STATUS_INDEX[raw]] *= math.exp(EPS_O)
    return LABELS[int(rng.choice(len(LABELS), p=p))]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def episode(seed: int, pair: int, membership: int, mode: str) -> tuple[dict, np.ndarray, dict]:
    # Pair-shared public history and non-protected policy inputs; randomness
    # used for public data is independent of the protected membership bit.
    rng_public = np.random.default_rng(seed * 100000 + pair * 37 + 501)
    momentum, sentiment, vol = public_series(rng_public, STEPS, 0)
    risk = int(rng_public.integers(0, 3))
    theta = float(rng_public.normal())
    book = LimitOrderBook(np.random.default_rng(seed * 100000 + pair * 37 + 777))
    release_rng = np.random.default_rng(seed * 100000 + pair * 37 + membership * 1009 + 9001)
    pending: dict[int, list[dict]] = {}
    observed = []
    tokens = []
    eps = delta = 0.0
    release_count = cover_count = projected = 0
    raw_no_order = 0
    flat = np.zeros((SLOTS, 9), dtype=float)
    cash = inventory = 0.0
    late_events = 0
    cover_submitted = set()

    def record_trade(event: dict, when: int) -> None:
        nonlocal cash, inventory, late_events
        rec = execute_event(book, event, when)
        if rec:
            observed.append(rec)
            if event.get('cover_id') is not None:
                cover_submitted.add(event['cover_id'])
            late_events += int(when >= STEPS)
            inventory += rec['side'] * rec['filled']
            cash -= rec['side'] * rec['filled'] * rec['avg_price']

    for ts in range(STEPS):
        book.background_step(ts, drift=.18 * momentum[ts] + .08 * sentiment[ts], vol=vol[ts])
        if ts % INTERVAL == 0:
            slot = ts // INTERVAL
            disposition_available = mode == 'raw' or eps + EPS_O <= EPS_MAX + 1e-9
            if disposition_available:
                raw = raw_policy(ts, momentum, sentiment, vol, membership, risk, theta)
                raw_no_order += int(raw is None)
            if mode == 'raw':
                if raw is not None:
                    t, q, _, _ = raw
                    flat[slot, STATUS_INDEX['order']] = 1.0
                    flat[slot, 5:] = [float(np.clip(q, -2, 2)) / 2,
                                       (t - ts) / 72, 0.0, 1 / 3]
                    pending.setdefault(max(ts, int(round(t))), []).append({
                        'signed_qty': q, 'delay': 0.0, 'split_n': 1,
                        'eps_after': 0.0,
                    })
                else:
                    # With a known public schedule, absence is observable.
                    flat[slot, STATUS_INDEX['no-order']] = 1.0
            else:
                centre_t, _, baseline_d = public_center(ts, momentum, vol)
                if not disposition_available:
                    final = 'budget-exhausted'
                else:
                    eps += EPS_O
                    public = random_status('order' if raw is not None else 'no-order', release_rng)
                    final = public
                    if public == 'order':
                        # `public` is an INTERNAL RR candidate, not yet published.
                        # The public-prefix action cap coarsens it to final status.
                        # This charged RR draw is distinct from pre-draw RR exhaustion.
                        if (release_count >= MAX_ORDERS or
                            eps + EPS_T + EPS_Q + EPS_D > EPS_MAX + 1e-9 or
                            delta + DELTA > DELTA_MAX + 1e-12):
                            final = 'budget-exhausted'
                        else:
                            if raw is None:
                                t, q, raw_d = centre_t, 0.0, baseline_d
                                cover_count += 1
                            else:
                                t, q, raw_d, _ = raw
                            t0 = float(np.clip(t, centre_t - DT / 2, centre_t + DT / 2))
                            q0 = float(np.clip(q, -DQ / 2, DQ / 2))
                            u0 = float(np.clip(raw_d - baseline_d, -DD / 2, DD / 2))
                            projected += int((t0 != t) or (q0 != q) or (u0 != raw_d - baseline_d))
                            released_t = t0 + float(release_rng.laplace(0, DT / EPS_T))
                            sigma = DQ * math.sqrt(2 * math.log(1.25 / DELTA)) / EPS_Q
                            released_q = float(release_rng.normal(q0, sigma))
                            released_d = max(0.0, baseline_d + u0 + float(release_rng.laplace(0, DD / EPS_D)))
                            # Exchange lot and max-size constraints are *only* a
                            # deterministic function of the privatized total.
                            # At least one child of at most three splits must
                            # meet the 0.05-lot threshold after postprocessing.
                            bounded_q = float(np.sign(released_q) * min(2.0, max(.15, abs(released_q))))
                            n = int(release_rng.integers(1, 4))
                            weights = release_rng.dirichlet(np.ones(n))
                            for j, weight in enumerate(weights):
                                due = max(ts, int(round(released_t + released_d + j)))
                                pending.setdefault(due, []).append({
                                    'signed_qty': bounded_q * float(weight),
                                    'delay': released_d, 'split_n': n,
                                    'eps_after': eps + EPS_T + EPS_Q + EPS_D,
                                    'cover_id': slot if raw is None else None,
                                })
                            flat[slot, 5:] = [bounded_q / 2, (released_t - ts) / 72,
                                               released_d / 72, n / 3]
                            eps += EPS_T + EPS_Q + EPS_D
                            delta += DELTA
                            release_count += 1
                tokens.append(final)
                flat[slot, STATUS_INDEX[final]] = 1.0
        for event in pending.pop(ts, []):
            record_trade(event, ts)

    # The original accepted-order kernel silently dropped pending releases at
    # the episode horizon. Complete the already privatized submission schedule
    # instead; beyond the decision window, the synthetic book has no new
    # strategy decisions and only a fixed public background step.
    for ts in range(STEPS, max(pending, default=STEPS-1) + 1):
        book.background_step(ts, drift=0.0, vol=1.0)
        for event in pending.pop(ts, []):
            record_trade(event, ts)
    assert not pending
    assert len(cover_submitted) == cover_count, 'an authorized cover release had no executable order'

    qty = np.array([x['signed_qty'] for x in observed], dtype=float)
    times = np.array([x['time'] for x in observed], dtype=float)
    pnl = cash + inventory * book.mid_tick() * book.tick_size
    features = [float(len(observed)), float(qty.sum()) if len(qty) else 0.,
                float(np.mean(qty > 0)) if len(qty) else 0.,
                float(np.mean(np.abs(qty))) if len(qty) else 0.,
                float(np.mean(times)) if len(times) else 0.,
                float(np.std(times)) if len(times) else 0.]
    features += [float(tokens.count(label)) for label in LABELS]
    row = {'seed': seed, 'pair': pair, 'membership': membership, 'mode': mode,
           'eps': eps, 'delta': delta, 'releases': release_count,
           'cover_release_count': cover_count, 'projected_count': projected,
           'cover_submitted_count': len(cover_submitted),
           'raw_no_order': raw_no_order, 'order_events': len(observed),
           'late_order_events': late_events,
           'pnl': pnl, **{f'f{i}': f for i, f in enumerate(features)}}
    # The sample output intentionally omits membership, raw decisions,
    # accounting metadata and pre-noise coordinates. It is not a venue log.
    safe_fields = ('time', 'signed_qty', 'side', 'price_rel', 'delay',
                   'split_n', 'filled', 'avg_price', 'slippage', 'aggressive')
    public_view = {'slot_statuses': tokens if mode == 'protected' else None,
                   'submitted_orders': [{k: rec[k] for k in safe_fields} for rec in observed]}
    return row, flat.ravel(), public_view


def evaluate(rows: pd.DataFrame, sequences: np.ndarray, seed: int, mode: str) -> dict:
    mask = rows['mode'].to_numpy() == mode
    data = rows.loc[mask].reset_index(drop=True)
    seq = sequences[mask]
    # Pair-level split: both states on the same public path stay together.
    perm = np.random.default_rng(seed + 24031).permutation(data['pair'].nunique())
    split = int(len(perm) * .7)
    train = data['pair'].isin(perm[:split]).to_numpy()
    test = ~train
    y = data['membership'].to_numpy(dtype=int)
    cols = [f'f{i}' for i in range(11)]
    feature_tr, feature_te, _, _ = standardize(data.loc[train, cols].to_numpy(dtype=float),
                                                 data.loc[test, cols].to_numpy(dtype=float))
    seq_tr, seq_te, _, _ = standardize(seq[train], seq[test])
    feature_model = BinaryLogistic(lr=.05, epochs=350, l2=.02).fit(feature_tr, y[train])
    sequence_model = BinaryLogistic(lr=.03, epochs=350, l2=.08).fit(seq_tr, y[train])
    return {'seed': seed, 'mode': mode, 'n_train': int(train.sum()), 'n_test': int(test.sum()),
            'feature_auc': auc_score(y[test], feature_model.predict_proba(feature_te)),
            'sequence_auc': auc_score(y[test], sequence_model.predict_proba(seq_te)),
            'eps_mean': data['eps'].mean(), 'eps_max': data['eps'].max(),
            'delta_max': data['delta'].max(), 'pnl_mean': data['pnl'].mean(),
            'cover_count': int(data['cover_release_count'].sum()),
            'projected_count': int(data['projected_count'].sum()),
            'exhausted_sessions': int((data['releases'] == MAX_ORDERS).sum())}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--seeds', nargs='+', type=int, default=list(range(5)))
    parser.add_argument('--pairs', type=int, default=60)
    parser.add_argument('--out', type=Path, default=Path(__file__).parent / 'results' / 'end_to_end')
    parser.add_argument('--save-public-arrays', action=argparse.BooleanOptionalAction, default=True,
                        help='save public fixed-slot arrays plus a separate score-only label file')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    seqs = []
    public_samples = []
    for seed in args.seeds:
        for pair in range(args.pairs):
            for membership in (0, 1):
                for mode in ('raw', 'protected'):
                    record, seq, view = episode(seed, pair, membership, mode)
                    rows.append(record)
                    seqs.append(seq)
                    if seed == args.seeds[0] and pair == 0 and mode == 'protected':
                        public_samples.append(dict(sample_id=len(public_samples), **view))
        print(f'completed seed {seed}', flush=True)
    frame = pd.DataFrame(rows)
    sequences = np.vstack(seqs)
    frame.to_csv(args.out / 'session_metrics.csv', index=False)
    if args.save_public_arrays:
        # These arrays contain only the fixed-slot public observation channels:
        # five final statuses and four released order fields.  Labels and
        # private/session-accounting diagnostics are intentionally excluded.
        public_arrays = sequences.reshape(len(sequences), SLOTS, 9)
        np.savez_compressed(args.out / 'public_sequences.npz', sequences=public_arrays)
        # Keep condition-specific files as well as the aligned combined archive.
        # Raw/protected traces share paired exogenous paths and the identical
        # public 18x9 schema, but are not identical public realizations.
        for mode in ('raw', 'protected'):
            mode_mask = frame['mode'].to_numpy() == mode
            np.savez_compressed(args.out / f'public_sequences_{mode}.npz',
                                sequences=public_arrays[mode_mask])
        public_index = frame.loc[:, ['seed', 'pair', 'mode']].copy()
        public_index.insert(0, 'row_index', np.arange(len(frame), dtype=int))
        public_index.to_csv(args.out / 'public_sequence_index.csv', index=False)
        score_labels = frame.loc[:, ['membership']].copy()
        score_labels.insert(0, 'row_index', np.arange(len(frame), dtype=int))
        score_labels.to_csv(args.out / 'scoring_labels.csv', index=False)
    with (args.out / 'public_trace_sample.jsonl').open('w') as f:
        for sample in public_samples:
            f.write(json.dumps(sample, sort_keys=True) + '\n')
    metrics = []
    for seed in args.seeds:
        sub = frame['seed'].to_numpy() == seed
        for mode in ('raw', 'protected'):
            metrics.append(evaluate(frame.loc[sub], sequences[sub], seed, mode))
    out = pd.DataFrame(metrics)
    out.to_csv(args.out / 'run_metrics.csv', index=False)
    summary = {'protocol': 'fixed-slot K=5 RR + Laplace time/delay + Gaussian signed quantity + deterministic postprocessing',
               'scope': 'synthetic LOB with public exogenous paths; no venue, hardware, or historical market',
               'seeds': args.seeds, 'pairs_per_seed': args.pairs, 'steps': STEPS, 'slots': SLOTS,
               'epsilon_max': EPS_MAX, 'delta_max': DELTA_MAX,
               'n_sessions_per_mode': len(args.seeds)*args.pairs*2,
               'metrics': {}}
    for mode in ('raw', 'protected'):
        o = out[out['mode'] == mode]
        summary['metrics'][mode] = {name: {'mean': float(o[name].mean()), 'sd': float(o[name].std(ddof=1))}
                                    for name in ('feature_auc','sequence_auc','eps_mean','eps_max','pnl_mean')}
        summary['metrics'][mode].update(cover_count=int(o['cover_count'].sum()),
                                        exhausted_sessions=int(o['exhausted_sessions'].sum()))
    summary['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    summary['benchmark_dependency_sha256'] = hashlib.sha256(
        (Path(__file__).parent / 'eti_lob_benchmark.py').read_bytes()).hexdigest()
    summary['versions'] = {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__}
    (args.out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    manifest = {
        'analysis_scope': 'synthetic paired fixed-slot generator; not a venue, hardware, historical-market, or LLM run',
        'public_array_contract': (
            'public_sequences.npz holds only 18x9 final public observation arrays; '
            'membership labels are isolated in scoring_labels.csv and are not mechanism/attacker features.'
        ),
        'runtime': summary['versions'],
        'hyperparameters': {
            'seeds': args.seeds, 'pairs_per_seed': args.pairs, 'steps': STEPS,
            'slots': SLOTS, 'channels': 9, 'eps_order': EPS_O, 'eps_time': EPS_T,
            'eps_qty': EPS_Q, 'eps_delay': EPS_D, 'delta': DELTA,
            'max_orders': MAX_ORDERS,
        },
        'source_sha256': {
            'end_to_end_trace_eval.py': summary['script_sha256'],
            'eti_lob_benchmark.py': summary['benchmark_dependency_sha256'],
        },
        'files_sha256': {
            name: sha256_file(args.out / name)
            for name in ['session_metrics.csv', 'run_metrics.csv', 'summary.json', 'public_trace_sample.jsonl']
        },
    }
    if args.save_public_arrays:
        manifest['files_sha256'].update({
            name: sha256_file(args.out / name)
            for name in ['public_sequences.npz', 'public_sequences_raw.npz', 'public_sequences_protected.npz',
                         'public_sequence_index.csv', 'scoring_labels.csv']
        })
    (args.out / 'generation_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
