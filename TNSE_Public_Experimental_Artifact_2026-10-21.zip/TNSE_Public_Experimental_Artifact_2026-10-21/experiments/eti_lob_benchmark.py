#!/usr/bin/env python3
"""Runnable ETI limit-order-book benchmark.

The code deliberately depends only on numpy and pandas so it can run in the
bundled Codex runtime. It is a B-layer artifact: a real executable benchmark
for the mechanism and attackers, not a replacement for C1 historical-data or
C2 testnet validation.
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import math
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


CONFIGS = ["no_defense", "random_delay", "eti_only", "eti_ledger", "full"]
FEATURE_NAMES = [
    "event_count",
    "buy_ratio",
    "net_signed_qty",
    "abs_qty_mean",
    "abs_qty_std",
    "max_abs_qty",
    "interarrival_mean",
    "interarrival_std",
    "split_mean",
    "fill_ratio_mean",
    "price_rel_mean",
    "price_rel_std",
    "delay_mean",
    "delay_std",
    "aggressive_ratio",
    "duration",
    "ledger_entries",
    "eps_spent",
]
SEQ_LEN = 48
SEQ_DIM = 6


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -35.0, 35.0)))


def softmax(x: np.ndarray) -> np.ndarray:
    z = x - x.max(axis=1, keepdims=True)
    ez = np.exp(z)
    return ez / ez.sum(axis=1, keepdims=True)


def standardize(train: np.ndarray, test: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    mean = train.mean(axis=0)
    std = train.std(axis=0)
    std[std < 1e-8] = 1.0
    return (train - mean) / std, (test - mean) / std, mean, std


def auc_score(y_true: np.ndarray, y_score: np.ndarray) -> float:
    y_true = y_true.astype(int)
    pos = y_true == 1
    neg = ~pos
    n_pos = int(pos.sum())
    n_neg = int(neg.sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    # Average tied ranks. The earlier sequential ranking made AUC depend on
    # the input order when a model (notably RF) produced equal scores.
    order = np.argsort(y_score, kind="stable")
    ranks = np.empty_like(order, dtype=float)
    sorted_scores = np.asarray(y_score)[order]
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and sorted_scores[j] == sorted_scores[i]:
            j += 1
        ranks[order[i:j]] = (i + 1 + j) / 2.0
        i = j
    return float((ranks[pos].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


@dataclass
class Order:
    order_id: int
    owner: str
    side: int
    price_tick: int
    qty: float
    ts: int


class LimitOrderBook:
    def __init__(self, rng: np.random.Generator, start_tick: int = 80_000, tick_size: float = 0.5):
        self.rng = rng
        self.tick_size = tick_size
        self.order_id = 0
        self.bids: Dict[int, deque[Order]] = {}
        self.asks: Dict[int, deque[Order]] = {}
        self.last_trade_tick = start_tick
        self._seed_book(start_tick)

    def _seed_book(self, mid: int) -> None:
        for level in range(1, 9):
            for _ in range(4):
                self.add_resting(+1, mid - level, float(self.rng.uniform(1.0, 5.0)), "bg", 0)
                self.add_resting(-1, mid + level, float(self.rng.uniform(1.0, 5.0)), "bg", 0)

    def _next_id(self) -> int:
        self.order_id += 1
        return self.order_id

    def add_resting(self, side: int, price_tick: int, qty: float, owner: str, ts: int) -> None:
        if qty <= 1e-9:
            return
        book = self.bids if side > 0 else self.asks
        book.setdefault(price_tick, deque()).append(Order(self._next_id(), owner, side, price_tick, qty, ts))

    @staticmethod
    def _clean(book: Dict[int, deque[Order]]) -> None:
        dead = [p for p, q in book.items() if not q]
        for p in dead:
            del book[p]

    def best_bid(self) -> int:
        self._clean(self.bids)
        return max(self.bids) if self.bids else self.last_trade_tick - 1

    def best_ask(self) -> int:
        self._clean(self.asks)
        return min(self.asks) if self.asks else self.last_trade_tick + 1

    def mid_tick(self) -> float:
        return 0.5 * (self.best_bid() + self.best_ask())

    def spread_ticks(self) -> int:
        return max(1, self.best_ask() - self.best_bid())

    def depth_imbalance(self, levels: int = 5) -> float:
        bid0, ask0 = self.best_bid(), self.best_ask()
        bid_depth = 0.0
        ask_depth = 0.0
        for p in range(bid0, bid0 - levels, -1):
            bid_depth += sum(o.qty for o in self.bids.get(p, ()))
        for p in range(ask0, ask0 + levels):
            ask_depth += sum(o.qty for o in self.asks.get(p, ()))
        denom = bid_depth + ask_depth
        return 0.0 if denom <= 0 else (bid_depth - ask_depth) / denom

    def market_order(self, side: int, qty: float, owner: str, ts: int) -> Tuple[float, float]:
        book = self.asks if side > 0 else self.bids
        total = 0.0
        notional = 0.0
        while qty > 1e-9 and book:
            price = min(book) if side > 0 else max(book)
            queue = book[price]
            while qty > 1e-9 and queue:
                top = queue[0]
                fill = min(qty, top.qty)
                qty -= fill
                top.qty -= fill
                total += fill
                notional += fill * price * self.tick_size
                self.last_trade_tick = price
                if top.qty <= 1e-9:
                    queue.popleft()
            if not queue:
                del book[price]
        return total, notional

    def submit_limit(self, side: int, price_tick: int, qty: float, owner: str, ts: int) -> Tuple[float, float, float]:
        start_mid = self.mid_tick() * self.tick_size
        filled = 0.0
        notional = 0.0
        if side > 0 and price_tick >= self.best_ask():
            filled, notional = self.market_order(side, qty, owner, ts)
        elif side < 0 and price_tick <= self.best_bid():
            filled, notional = self.market_order(side, qty, owner, ts)
        residual = max(0.0, qty - filled)
        if residual > 1e-9:
            self.add_resting(side, price_tick, residual, owner, ts)
        avg_price = notional / filled if filled > 1e-9 else price_tick * self.tick_size
        slippage = side * (avg_price - start_mid) if filled > 1e-9 else 0.0
        return filled, avg_price, slippage

    def cancel_random(self, prob: float = 0.08) -> None:
        for book in (self.bids, self.asks):
            if not book or self.rng.random() > prob:
                continue
            price = int(self.rng.choice(list(book.keys())))
            queue = book.get(price)
            if queue:
                idx = int(self.rng.integers(0, len(queue)))
                try:
                    del queue[idx]
                except IndexError:
                    pass
                if not queue:
                    del book[price]

    def background_step(self, ts: int, drift: float, vol: float) -> None:
        mid = int(round(self.mid_tick() + drift + self.rng.normal(0.0, vol)))
        for side in (+1, -1):
            n = int(self.rng.poisson(2.4))
            for _ in range(n):
                level = int(self.rng.integers(1, 7))
                price = mid - level if side > 0 else mid + level
                qty = float(self.rng.gamma(2.0, 1.2))
                self.add_resting(side, price, qty, "bg", ts)
        if self.rng.random() < 0.42:
            side = +1 if self.rng.random() < 0.5 + 0.08 * np.tanh(drift) else -1
            qty = float(self.rng.gamma(1.4, 1.7))
            self.market_order(side, qty, "bg", ts)
        self.cancel_random(prob=0.12)


@dataclass
class Certificate:
    delta_t: float = 4.0
    delta_q: float = 4.0
    delta_d: float = 3.0
    eps_t: float = 0.45
    eps_q: float = 0.70
    eps_d: float = 0.35
    delta: float = 1e-5
    max_qty: float = 5.0


class PrivacyLedger:
    def __init__(self, key: bytes):
        self.key = key
        self.prev_hash = "0" * 64
        self.entries: List[dict] = []

    def append(self, record: dict) -> None:
        payload = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
        sig = hmac.new(self.key, payload, hashlib.sha256).hexdigest()
        head = hashlib.sha256((self.prev_hash + sig).encode() + payload).hexdigest()
        entry = dict(record)
        entry["prev_hash"] = self.prev_hash
        entry["signature"] = sig
        entry["entry_hash"] = head
        self.prev_hash = head
        self.entries.append(entry)


class ETIRelease:
    def __init__(self, cert: Certificate, rng: np.random.Generator, with_ledger: bool):
        self.cert = cert
        self.rng = rng
        self.eps_spent = 0.0
        self.delta_spent = 0.0
        key = hashlib.sha256(str(rng.bit_generator.state).encode()).digest()
        self.ledger = PrivacyLedger(key) if with_ledger else None

    def project(self, raw_time: float, raw_qty: float, raw_delay: float, public_center: Tuple[float, float, float]) -> Tuple[float, float, float]:
        ct, cq, cd = public_center
        c = self.cert
        t = float(np.clip(raw_time, ct - c.delta_t / 2.0, ct + c.delta_t / 2.0))
        q = float(np.clip(raw_qty, cq - c.delta_q / 2.0, cq + c.delta_q / 2.0))
        d = float(np.clip(raw_delay, cd - c.delta_d / 2.0, cd + c.delta_d / 2.0))
        q = float(np.clip(q, -c.max_qty, c.max_qty))
        return t, q, max(0.0, d)

    def release(self, raw_time: float, raw_qty: float, raw_delay: float, public_center: Tuple[float, float, float], ts: int, config: str) -> List[dict]:
        c = self.cert
        t, q, d = self.project(raw_time, raw_qty, raw_delay, public_center)
        rt = t + float(self.rng.laplace(0.0, c.delta_t / c.eps_t))
        sigma_q = c.delta_q * math.sqrt(2.0 * math.log(1.25 / c.delta)) / c.eps_q
        rq = q + float(self.rng.normal(0.0, sigma_q))
        rd = max(0.0, d + float(self.rng.laplace(0.0, c.delta_d / c.eps_d)))
        rq = float(np.clip(rq, -c.max_qty, c.max_qty))
        split_n = int(self.rng.integers(1, 4))
        weights = self.rng.dirichlet(np.ones(split_n))
        self.eps_spent += c.eps_t + c.eps_q + c.eps_d
        self.delta_spent += c.delta
        events = []
        for k, w in enumerate(weights):
            events.append(
                {
                    "submit_time": max(ts, int(round(rt + rd + k))),
                    "signed_qty": float(rq * w),
                    "delay": float(rd),
                    "split_n": split_n,
                    "projected_qty": q,
                    "eps_after": self.eps_spent,
                }
            )
        if self.ledger is not None:
            self.ledger.append(
                {
                    "ts": ts,
                    "config": config,
                    "eps_t": c.eps_t,
                    "eps_q": c.eps_q,
                    "eps_d": c.eps_d,
                    "delta": c.delta,
                    # Never serialize pre-noise projected values into a
                    # purportedly public sample, even in a synthetic test.
                    "privatized_time": round(rt, 6),
                    "privatized_qty": round(rq, 6),
                    "privatized_delay": round(rd, 6),
                    "eps_after": round(self.eps_spent, 6),
                }
            )
        return events


def public_series(rng: np.random.Generator, steps: int, membership: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    shocks = rng.normal(0.0, 1.0, steps)
    momentum = np.zeros(steps)
    sentiment = rng.normal(0.0, 0.7, steps)
    event = np.zeros(steps)
    event_times = rng.choice(np.arange(8, steps - 8), size=max(2, steps // 24), replace=False)
    for t in event_times:
        event[t : min(steps, t + 5)] += rng.normal(0.4, 0.25)  # public market process is independent of protected membership
    for t in range(1, steps):
        momentum[t] = 0.84 * momentum[t - 1] + 0.16 * shocks[t] + 0.08 * event[t]
    sentiment += 0.65 * event
    vol = np.maximum(0.6, np.abs(shocks) * 0.55 + 0.25)
    return momentum, sentiment, vol


def raw_policy(ts: int, momentum: np.ndarray, sentiment: np.ndarray, vol: np.ndarray, membership: int, risk: int, theta: float) -> Optional[Tuple[float, float, float, int]]:
    risk_aversion = [0.75, 1.0, 1.35][risk]
    threshold = 0.32 + 0.17 * risk_aversion + 0.05 * theta
    alpha = 0.78 * momentum[ts] + 0.65 * sentiment[ts] + 0.55 * membership - 0.12 * risk_aversion * vol[ts] + 0.08 * theta
    if abs(alpha) < threshold:
        return None
    side = +1 if alpha > 0 else -1
    urgency = min(3.0, abs(alpha))
    raw_time = ts + max(0.0, 3.0 - urgency)
    raw_qty = side * (0.8 + 1.9 * urgency) / risk_aversion
    raw_delay = max(0.0, 2.8 - urgency)
    return raw_time, raw_qty, raw_delay, side


def public_center(ts: int, momentum: np.ndarray, vol: np.ndarray) -> Tuple[float, float, float]:
    urgency = min(2.0, abs(momentum[ts]) + 0.2 * vol[ts])
    return ts + 2.0 - 0.4 * urgency, 0.0, 1.6


def execute_event(book: LimitOrderBook, event: dict, ts: int) -> dict:
    signed_qty = float(event["signed_qty"])
    side = +1 if signed_qty >= 0 else -1
    qty = abs(signed_qty)
    if qty < 0.05:
        return {}
    bid, ask = book.best_bid(), book.best_ask()
    aggressive = qty > 1.8 or event.get("delay", 0.0) < 1.0
    if side > 0:
        price = ask if aggressive else bid
    else:
        price = bid if aggressive else ask
    filled, avg_price, slippage = book.submit_limit(side, price, qty, "agent", ts)
    return {
        "time": ts,
        "signed_qty": signed_qty,
        "side": side,
        "price_rel": (price - book.mid_tick()) / max(1.0, book.spread_ticks()),
        "delay": float(event.get("delay", 0.0)),
        "split_n": int(event.get("split_n", 1)),
        "filled": filled,
        "avg_price": avg_price,
        "slippage": slippage,
        "aggressive": 1.0 if aggressive else 0.0,
        "eps_after": float(event.get("eps_after", 0.0)),
    }


def simulate_episode(base_seed: int, config: str, steps: int) -> Tuple[dict, np.ndarray, List[dict]]:
    label_rng = np.random.default_rng(base_seed + 11)
    market_rng = np.random.default_rng(base_seed + 23)
    defense_rng = np.random.default_rng(base_seed + 37 + 1009 * CONFIGS.index(config))
    membership = int(label_rng.integers(0, 2))
    risk = int(label_rng.integers(0, 3))
    theta = float(label_rng.normal(0.0, 1.0))
    momentum, sentiment, vol = public_series(label_rng, steps, membership)
    book = LimitOrderBook(market_rng)
    cert = Certificate()
    with_ledger = config in {"eti_ledger", "full"}
    release = ETIRelease(cert, defense_rng, with_ledger)
    pending: Dict[int, List[dict]] = {}
    trace: List[dict] = []
    cash = 0.0
    inventory = 0.0
    decision_interval = 4 if risk == 0 else 5 if risk == 1 else 6

    for ts in range(steps):
        drift = 0.18 * momentum[ts] + 0.08 * sentiment[ts]
        book.background_step(ts, drift=drift, vol=vol[ts])
        if ts % decision_interval == 0:
            raw = raw_policy(ts, momentum, sentiment, vol, membership, risk, theta)
            if raw is not None:
                raw_time, raw_qty, raw_delay, _side = raw
                if config == "no_defense":
                    events = [{"submit_time": int(round(raw_time)), "signed_qty": raw_qty, "delay": 0.0, "split_n": 1, "eps_after": 0.0}]
                elif config == "random_delay":
                    rd = float(defense_rng.uniform(0.0, 6.0))
                    events = [{"submit_time": int(round(raw_time + rd)), "signed_qty": raw_qty, "delay": rd, "split_n": 1, "eps_after": 0.0}]
                else:
                    events = release.release(raw_time, raw_qty, raw_delay, public_center(ts, momentum, vol), ts, config)
                for ev in events:
                    pending.setdefault(int(ev["submit_time"]), []).append(ev)
        for ev in pending.pop(ts, []):
            rec = execute_event(book, ev, ts)
            if rec:
                fill = rec["filled"]
                side = rec["side"]
                inventory += side * fill
                cash -= side * fill * rec["avg_price"]
                trace.append(rec)
    final_mid = book.mid_tick() * book.tick_size
    pnl = cash + inventory * final_mid
    features = extract_features(trace, release, steps)
    seq = extract_sequence(trace, steps)
    row = {
        "membership": membership,
        "risk": risk,
        "theta": theta,
        "pnl": pnl,
        "inventory": inventory,
        "config": config,
        **features,
    }
    ledger_entries = release.ledger.entries[:5] if release.ledger is not None else []
    return row, seq, ledger_entries


def extract_features(trace: List[dict], release: ETIRelease, steps: int) -> dict:
    if not trace:
        return {name: 0.0 for name in FEATURE_NAMES}
    times = np.array([r["time"] for r in trace], dtype=float)
    qty = np.array([r["signed_qty"] for r in trace], dtype=float)
    absq = np.abs(qty)
    fills = np.array([r["filled"] for r in trace], dtype=float)
    split = np.array([r["split_n"] for r in trace], dtype=float)
    price_rel = np.array([r["price_rel"] for r in trace], dtype=float)
    delay = np.array([r["delay"] for r in trace], dtype=float)
    aggressive = np.array([r["aggressive"] for r in trace], dtype=float)
    inter = np.diff(times) if len(times) > 1 else np.array([steps], dtype=float)
    fill_ratio = fills / np.maximum(absq, 1e-8)
    values = {
        "event_count": float(len(trace)),
        "buy_ratio": float((qty > 0).mean()),
        "net_signed_qty": float(qty.sum()),
        "abs_qty_mean": float(absq.mean()),
        "abs_qty_std": float(absq.std()),
        "max_abs_qty": float(absq.max()),
        "interarrival_mean": float(inter.mean()),
        "interarrival_std": float(inter.std()),
        "split_mean": float(split.mean()),
        "fill_ratio_mean": float(fill_ratio.mean()),
        "price_rel_mean": float(price_rel.mean()),
        "price_rel_std": float(price_rel.std()),
        "delay_mean": float(delay.mean()),
        "delay_std": float(delay.std()),
        "aggressive_ratio": float(aggressive.mean()),
        "duration": float(times.max() - times.min() + 1.0),
        "ledger_entries": float(len(release.ledger.entries) if release.ledger is not None else 0),
        "eps_spent": float(release.eps_spent),
    }
    return values


def extract_sequence(trace: List[dict], steps: int) -> np.ndarray:
    seq = np.zeros((SEQ_LEN, SEQ_DIM), dtype=float)
    for i, r in enumerate(trace[:SEQ_LEN]):
        seq[i] = [
            r["time"] / max(1, steps),
            r["signed_qty"] / 5.0,
            r["side"],
            r["price_rel"],
            r["delay"] / 10.0,
            r["filled"] / max(abs(r["signed_qty"]), 1e-8),
        ]
    return seq


class BinaryLogistic:
    def __init__(self, lr: float = 0.08, epochs: int = 240, l2: float = 1e-3):
        self.lr, self.epochs, self.l2 = lr, epochs, l2

    def fit(self, X: np.ndarray, y: np.ndarray) -> "BinaryLogistic":
        Xb = np.c_[np.ones(len(X)), X]
        self.w = np.zeros(Xb.shape[1])
        for _ in range(self.epochs):
            p = sigmoid(Xb @ self.w)
            grad = Xb.T @ (p - y) / len(y) + self.l2 * np.r_[0.0, self.w[1:]]
            self.w -= self.lr * grad
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        return sigmoid(np.c_[np.ones(len(X)), X] @ self.w)


class RidgeRegressor:
    def __init__(self, l2: float = 1e-2):
        self.l2 = l2

    def fit(self, X: np.ndarray, y: np.ndarray) -> "RidgeRegressor":
        Xb = np.c_[np.ones(len(X)), X]
        reg = self.l2 * np.eye(Xb.shape[1])
        reg[0, 0] = 0.0
        self.w = np.linalg.pinv(Xb.T @ Xb + reg) @ Xb.T @ y
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.c_[np.ones(len(X)), X] @ self.w


class MLPBinary:
    def __init__(self, hidden: int = 32, lr: float = 0.03, epochs: int = 180, seed: int = 0):
        self.hidden, self.lr, self.epochs, self.seed = hidden, lr, epochs, seed

    def fit(self, X: np.ndarray, y: np.ndarray) -> "MLPBinary":
        rng = np.random.default_rng(self.seed)
        n, d = X.shape
        self.W1 = rng.normal(0, 0.18, (d, self.hidden))
        self.b1 = np.zeros(self.hidden)
        self.W2 = rng.normal(0, 0.18, self.hidden)
        self.b2 = 0.0
        for _ in range(self.epochs):
            Hpre = X @ self.W1 + self.b1
            H = np.maximum(Hpre, 0)
            p = sigmoid(H @ self.W2 + self.b2)
            dz = (p - y) / n
            gW2 = H.T @ dz
            gb2 = dz.sum()
            dH = dz[:, None] * self.W2
            dH[Hpre <= 0] = 0
            gW1 = X.T @ dH
            gb1 = dH.sum(axis=0)
            self.W2 -= self.lr * gW2
            self.b2 -= self.lr * gb2
            self.W1 -= self.lr * gW1
            self.b1 -= self.lr * gb1
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        H = np.maximum(X @ self.W1 + self.b1, 0)
        return sigmoid(H @ self.W2 + self.b2)


class MLPRegressor:
    def __init__(self, hidden: int = 32, lr: float = 0.02, epochs: int = 220, seed: int = 0):
        self.hidden, self.lr, self.epochs, self.seed = hidden, lr, epochs, seed

    def fit(self, X: np.ndarray, y: np.ndarray) -> "MLPRegressor":
        rng = np.random.default_rng(self.seed)
        n, d = X.shape
        self.y_mean = float(y.mean())
        self.y_std = float(y.std() if y.std() > 1e-8 else 1.0)
        yt = (y - self.y_mean) / self.y_std
        self.W1 = rng.normal(0, 0.16, (d, self.hidden))
        self.b1 = np.zeros(self.hidden)
        self.W2 = rng.normal(0, 0.16, self.hidden)
        self.b2 = 0.0
        for _ in range(self.epochs):
            Hpre = X @ self.W1 + self.b1
            H = np.maximum(Hpre, 0)
            pred = H @ self.W2 + self.b2
            dz = 2.0 * (pred - yt) / n
            gW2 = H.T @ dz
            gb2 = dz.sum()
            dH = dz[:, None] * self.W2
            dH[Hpre <= 0] = 0
            self.W2 -= self.lr * gW2
            self.b2 -= self.lr * gb2
            self.W1 -= self.lr * (X.T @ dH)
            self.b1 -= self.lr * dH.sum(axis=0)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        H = np.maximum(X @ self.W1 + self.b1, 0)
        return (H @ self.W2 + self.b2) * self.y_std + self.y_mean


class RandomTree:
    def __init__(self, max_depth: int = 5, min_leaf: int = 6, task: str = "binary", seed: int = 0, n_classes: Optional[int] = None):
        self.max_depth, self.min_leaf, self.task, self.seed = max_depth, min_leaf, task, seed
        self.fixed_n_classes = n_classes

    def fit(self, X: np.ndarray, y: np.ndarray) -> "RandomTree":
        self.rng = np.random.default_rng(self.seed)
        self.n_classes = self.fixed_n_classes or (int(np.max(y) + 1) if self.task == "multiclass" else 2)
        self.root = self._build(X, y, 0)
        return self

    def _leaf(self, y: np.ndarray) -> dict:
        if self.task == "regression":
            return {"leaf": True, "value": float(np.mean(y))}
        if self.task == "multiclass":
            counts = np.bincount(y.astype(int), minlength=self.n_classes) + 1.0
            return {"leaf": True, "value": counts / counts.sum()}
        return {"leaf": True, "value": float((y.sum() + 1.0) / (len(y) + 2.0))}

    def _impurity(self, y: np.ndarray) -> float:
        if len(y) == 0:
            return 0.0
        if self.task == "regression":
            return float(np.var(y))
        counts = np.bincount(y.astype(int), minlength=self.n_classes if self.task == "multiclass" else 2)
        p = counts / max(1, counts.sum())
        return float(1.0 - np.sum(p * p))

    def _build(self, X: np.ndarray, y: np.ndarray, depth: int) -> dict:
        if depth >= self.max_depth or len(y) < 2 * self.min_leaf or self._impurity(y) < 1e-8:
            return self._leaf(y)
        n, d = X.shape
        best = None
        base = self._impurity(y)
        trials = max(8, int(math.sqrt(d)) * 8)
        for _ in range(trials):
            j = int(self.rng.integers(0, d))
            col = X[:, j]
            lo, hi = float(np.percentile(col, 10)), float(np.percentile(col, 90))
            if abs(hi - lo) < 1e-9:
                continue
            thr = float(self.rng.uniform(lo, hi))
            left = col <= thr
            if left.sum() < self.min_leaf or (~left).sum() < self.min_leaf:
                continue
            gain = base - (left.mean() * self._impurity(y[left]) + (~left).mean() * self._impurity(y[~left]))
            if best is None or gain > best[0]:
                best = (gain, j, thr, left)
        if best is None or best[0] <= 1e-9:
            return self._leaf(y)
        _, j, thr, left = best
        return {
            "leaf": False,
            "feature": j,
            "threshold": thr,
            "left": self._build(X[left], y[left], depth + 1),
            "right": self._build(X[~left], y[~left], depth + 1),
        }

    def _predict_one(self, x: np.ndarray, node: dict):
        while not node["leaf"]:
            node = node["left"] if x[node["feature"]] <= node["threshold"] else node["right"]
        return node["value"]

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.array([self._predict_one(x, self.root) for x in X])


class RandomForestLite:
    def __init__(self, n_trees: int = 35, task: str = "binary", seed: int = 0):
        self.n_trees, self.task, self.seed = n_trees, task, seed

    def fit(self, X: np.ndarray, y: np.ndarray) -> "RandomForestLite":
        rng = np.random.default_rng(self.seed)
        self.trees = []
        n = len(y)
        n_classes = int(np.max(y) + 1) if self.task == "multiclass" else None
        for i in range(self.n_trees):
            idx = rng.integers(0, n, n)
            tree = RandomTree(max_depth=5, min_leaf=5, task=self.task, seed=self.seed + i * 17, n_classes=n_classes)
            tree.fit(X[idx], y[idx])
            self.trees.append(tree)
        return self

    def predict_value(self, X: np.ndarray) -> np.ndarray:
        preds = np.array([t.predict(X) for t in self.trees])
        if self.task == "multiclass":
            return preds.mean(axis=0)
        return preds.mean(axis=0)


class OneVsRest:
    def __init__(self, model_factory, classes: Sequence[int]):
        self.model_factory = model_factory
        self.classes = list(classes)

    def fit(self, X: np.ndarray, y: np.ndarray) -> "OneVsRest":
        self.models = []
        for c in self.classes:
            m = self.model_factory()
            m.fit(X, (y == c).astype(float))
            self.models.append(m)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        probs = np.vstack([m.predict_proba(X) for m in self.models]).T
        return np.array(self.classes)[np.argmax(probs, axis=1)]


class LSTMReservoir:
    """LSTM-cell sequence baseline with fixed recurrent weights and trained readout."""

    def __init__(self, hidden: int = 24, seed: int = 0):
        self.hidden, self.seed = hidden, seed

    def _features(self, S: np.ndarray) -> np.ndarray:
        rng = np.random.default_rng(self.seed)
        d = S.shape[-1]
        if not hasattr(self, "Wx"):
            scale = 1.0 / math.sqrt(d + self.hidden)
            self.Wx = rng.normal(0, scale, (d, 4 * self.hidden))
            self.Wh = rng.normal(0, scale, (self.hidden, 4 * self.hidden))
            self.b = np.zeros(4 * self.hidden)
        feats = []
        for seq in S:
            h = np.zeros(self.hidden)
            c = np.zeros(self.hidden)
            for x in seq:
                z = x @ self.Wx + h @ self.Wh + self.b
                i = sigmoid(z[: self.hidden])
                f = sigmoid(z[self.hidden : 2 * self.hidden])
                o = sigmoid(z[2 * self.hidden : 3 * self.hidden])
                g = np.tanh(z[3 * self.hidden :])
                c = f * c + i * g
                h = o * np.tanh(c)
            feats.append(h)
        return np.asarray(feats)

    def fit(self, S: np.ndarray, y: np.ndarray) -> "LSTMReservoir":
        H = self._features(S)
        self.readout = BinaryLogistic(lr=0.08, epochs=220, l2=1e-3).fit(H, y)
        return self

    def predict_proba(self, S: np.ndarray) -> np.ndarray:
        return self.readout.predict_proba(self._features(S))


def fit_attackers(X_train: np.ndarray, X_test: np.ndarray, seq_train: np.ndarray, seq_test: np.ndarray, y_train: dict, y_test: dict, seed: int) -> List[dict]:
    results = []
    classes = [0, 1, 2]
    models = {
        "LR": (
            BinaryLogistic(lr=0.07, epochs=260),
            RidgeRegressor(l2=2e-2),
            OneVsRest(lambda: BinaryLogistic(lr=0.07, epochs=220), classes),
        ),
        "NN": (
            MLPBinary(seed=seed + 1),
            MLPRegressor(seed=seed + 2),
            OneVsRest(lambda: MLPBinary(seed=seed + 3), classes),
        ),
        "RF": (
            RandomForestLite(task="binary", seed=seed + 4),
            RandomForestLite(task="regression", seed=seed + 5),
            RandomForestLite(task="multiclass", seed=seed + 6),
        ),
    }
    cached = {}
    for name, (clf, reg, risk_model) in models.items():
        clf.fit(X_train, y_train["membership"])
        reg.fit(X_train, y_train["theta"])
        risk_model.fit(X_train, y_train["risk"])
        if name == "RF":
            p = clf.predict_value(X_test)
            pred_theta = reg.predict_value(X_test)
            pred_risk = np.argmax(risk_model.predict_value(X_test), axis=1)
        else:
            p = clf.predict_proba(X_test)
            pred_theta = reg.predict(X_test)
            pred_risk = risk_model.predict(X_test)
        cached[name] = (p, pred_theta, pred_risk)
        results.append(metric_row(name, y_test, p, pred_theta, pred_risk))
    ens_p = np.mean([cached[k][0] for k in ("LR", "NN", "RF")], axis=0)
    ens_theta = np.mean([cached[k][1] for k in ("LR", "NN", "RF")], axis=0)
    risk_votes = np.vstack([cached[k][2] for k in ("LR", "NN", "RF")]).T
    ens_risk = np.array([np.bincount(row.astype(int), minlength=3).argmax() for row in risk_votes])
    results.append(metric_row("Ensemble", y_test, ens_p, ens_theta, ens_risk))
    lstm = LSTMReservoir(seed=seed + 7).fit(seq_train, y_train["membership"])
    lstm_p = lstm.predict_proba(seq_test)
    results.append(
        {
            "attacker": "LSTM-reservoir",
            "membership_auc": auc_score(y_test["membership"], lstm_p),
            "reconstruction_rmse": float("nan"),
            "risk_accuracy": float("nan"),
        }
    )
    return results


def metric_row(name: str, y_test: dict, p: np.ndarray, pred_theta: np.ndarray, pred_risk: np.ndarray) -> dict:
    return {
        "attacker": name,
        "membership_auc": auc_score(y_test["membership"], p),
        "reconstruction_rmse": float(np.sqrt(np.mean((pred_theta - y_test["theta"]) ** 2))),
        "risk_accuracy": float(np.mean(pred_risk == y_test["risk"])),
    }


def run_seed(seed: int, episodes: int, steps: int, out_dir: Path) -> Tuple[List[dict], pd.DataFrame, np.ndarray, List[dict]]:
    rows = []
    seqs = []
    ledger_sample: List[dict] = []
    for i in range(episodes):
        base_seed = seed * 100_000 + i * 997
        for config in CONFIGS:
            row, seq, ledger = simulate_episode(base_seed, config, steps)
            row.update({"seed": seed, "episode": i})
            rows.append(row)
            seqs.append(seq)
            if config == "full" and i == 0 and ledger:
                ledger_sample.extend(ledger)
    df = pd.DataFrame(rows)
    seq_arr = np.asarray(seqs)
    metrics = []
    for config in CONFIGS:
        mask = df["config"].values == config
        cdf = df.loc[mask].reset_index(drop=True)
        cseq = seq_arr[mask]
        split = int(0.7 * len(cdf))
        X = cdf[FEATURE_NAMES].to_numpy(dtype=float)
        X_train, X_test, _, _ = standardize(X[:split], X[split:])
        seq_train = cseq[:split]
        seq_test = cseq[split:]
        y_train = {
            "membership": cdf["membership"].to_numpy(dtype=float)[:split],
            "theta": cdf["theta"].to_numpy(dtype=float)[:split],
            "risk": cdf["risk"].to_numpy(dtype=int)[:split],
        }
        y_test = {
            "membership": cdf["membership"].to_numpy(dtype=int)[split:],
            "theta": cdf["theta"].to_numpy(dtype=float)[split:],
            "risk": cdf["risk"].to_numpy(dtype=int)[split:],
        }
        pnl = cdf["pnl"].to_numpy(dtype=float)
        sharpe = float(np.mean(pnl) / (np.std(pnl) + 1e-8) * math.sqrt(252.0))
        eps_mean = float(cdf["eps_spent"].mean())
        for m in fit_attackers(X_train, X_test, seq_train, seq_test, y_train, y_test, seed + CONFIGS.index(config) * 101):
            m.update({"seed": seed, "config": config, "sharpe_like": sharpe, "eps_spent_mean": eps_mean, "episodes": episodes, "steps": steps})
            metrics.append(m)
    return metrics, df, seq_arr, ledger_sample


def write_manifest(out_dir: Path, args: argparse.Namespace, elapsed: float) -> None:
    script = Path(__file__)
    digest = hashlib.sha256(script.read_bytes()).hexdigest()
    manifest = {
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "script": str(script),
        "script_sha256": digest,
        "seeds": args.seeds,
        "episodes_per_seed": args.episodes,
        "steps_per_episode": args.steps,
        "configs": CONFIGS,
        "feature_names": FEATURE_NAMES,
        "sequence_shape": [SEQ_LEN, SEQ_DIM],
        "data_source": "synthetic price-time-priority LOB generated by experiments/eti_lob_benchmark.py",
        "not_claimed": [
            "C1 historical Binance BTC/USDT calibration",
            "C2 Binance Spot Testnet latency measurement",
            "live trading or paper trading evidence",
        ],
        "dependencies": {"numpy": np.__version__, "pandas": pd.__version__},
        "elapsed_seconds": round(elapsed, 3),
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    parser.add_argument("--episodes", type=int, default=120)
    parser.add_argument("--steps", type=int, default=72)
    parser.add_argument("--out", type=Path, default=Path("experiments/results"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    start = time.time()
    all_metrics = []
    all_features = []
    all_ledgers = []
    for seed in args.seeds:
        metrics, features, seq_arr, ledger_sample = run_seed(seed, args.episodes, args.steps, args.out)
        all_metrics.extend(metrics)
        all_features.append(features)
        all_ledgers.extend({"seed": seed, **e} for e in ledger_sample)
        np.savez_compressed(args.out / f"sequences_seed{seed}.npz", sequences=seq_arr)
    metrics_df = pd.DataFrame(all_metrics)
    features_df = pd.concat(all_features, ignore_index=True)
    metrics_df.to_csv(args.out / "run_level_metrics.csv", index=False)
    features_df.to_csv(args.out / "trace_features.csv", index=False)
    summary = (
        metrics_df.groupby(["config", "attacker"], dropna=False)
        .agg(
            membership_auc_mean=("membership_auc", "mean"),
            membership_auc_std=("membership_auc", "std"),
            reconstruction_rmse_mean=("reconstruction_rmse", "mean"),
            reconstruction_rmse_std=("reconstruction_rmse", "std"),
            risk_accuracy_mean=("risk_accuracy", "mean"),
            risk_accuracy_std=("risk_accuracy", "std"),
            sharpe_like_mean=("sharpe_like", "mean"),
            eps_spent_mean=("eps_spent_mean", "mean"),
        )
        .reset_index()
    )
    summary.to_csv(args.out / "summary_metrics.csv", index=False)
    with (args.out / "ledger_sample.jsonl").open("w") as f:
        for e in all_ledgers[:40]:
            f.write(json.dumps(e, sort_keys=True) + "\n")
    write_manifest(args.out, args, time.time() - start)
    print(f"Wrote {args.out / 'run_level_metrics.csv'}")
    print(f"Wrote {args.out / 'summary_metrics.csv'}")
    print(f"Wrote {args.out / 'manifest.json'}")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
