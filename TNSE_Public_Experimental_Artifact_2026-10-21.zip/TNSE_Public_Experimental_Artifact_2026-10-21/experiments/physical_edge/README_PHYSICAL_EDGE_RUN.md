> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Physical Edge-platform run (17 October 2026)

This directory records the completed run on a physical NVIDIA Jetson Orin-class
ARM edge platform. It is included as a **platform and software-harness
validation**, not as a live-exchange, edge-NIC, or pretrained-LLM deployment
claim. The complete operator-produced archive is
`TNSE_Edge_Board_Results_20261017T190612Z.zip`; `key_outputs/` contains the
small files needed for a quick audit without unpacking that archive.

## Run identity

- UTC run identifier: `20261017T190612Z`.
- Platform probe: `aarch64`, Linux `5.15.148-tegra`, 12 Cortex-A78AE CPUs,
  approximately 61 GiB RAM, and `nvidia-smi` reporting `Orin (nvgpu)` with
  driver `540.4.0`.
- Thermal sysfs values were readable at probe time (approximately 43.4--48.2
  degrees Celsius). The board's `tegrastats` command rejected the requested
  `--count` option, so no sustained power, utilization, or throughput claim is
  made.
- An operator-provided terminal photo is stored under
  `operator_photo/jetson_edge_run_terminal_photo.jpg`. It is retained only as
  a visual record of the completed run; no model or memory-capacity label is
  used as a hardware result. The read-only system probe remains the
  authoritative runtime inventory for this run, while serving as runtime
  inventory rather than independent third-party certification.
- All validation/experiment steps that record a status returned code 0, as
  listed in `key_outputs/STATUS.txt`; the final packaging command produced the
  complete result archive.

## Evidence added by this run

1. **Board probe.** Read-only inventory and thermal diagnostics establish the
   ARM/Orin execution host. The probe does not measure a production edge
   service or hardware accelerator performance.
2. **Deterministic lifecycle replay.** A local single-threaded price--time FIFO
   emulator processed 2,000 replay rows. It emitted 1,740 local ACKs (1,681
   accepted and 59 rejected), 708 cancels, 119 fills, 31 modifies, and 913
   resting events; 942 checked orders had zero quantity-conservation mismatches.
   Trace monotonicity and all five deterministic scenario checks passed. Source
   observations and synthetic stress commands are explicitly labelled in the
   manifest.
3. **Offline edge timing.** A deterministic structured prompt/state surrogate
   measured a local software path at injected RTTs of 0.5, 1, 5, and 20 ms.
   Local p95 latency was approximately 0.127, 0.172, 0.569, and 2.072 ms,
   with zero local deadline misses under the configured 5-ms deadline. The
   5- and 20-ms proxy rows are injected-delay simulations, not network traces.
4. **Fail-closed and release checks.** The `edge_fault_stdlib` compatibility
   harness tested 2,000 normal events plus five 200-repeat fault branches
   (`audit-signing-failure`, `invalid-proposal`, `no-order`, `reject`, and
   `timeout`) and eight `budget-exhaustion` samples: 3,008 branch samples in
   total. Independent inspection of the frozen CSV confirms that all 1,008
   fault rows record zero send bytes and all 3,008 rows record a heartbeat
   flag and 17 heartbeat bytes. These are local branch-record checks; the CSV
   does not establish actual transport or periodic heartbeat scheduling. The
   harness uses a SHA-256 test token for compatibility; this is **not** Ed25519
   evidence. Release validation exercised 10,000
   samples per status scale and 24 session-invariant runs.

## Explicit non-claims

- `pretrained_llm_SKIPPED.txt` is part of the archive: this board run did not
  execute a pretrained LLM. The separate Qwen checkpoint/interface results in
  `experiments/strengthening/real_llm_*` remain independently scoped and are
  not silently merged with this board run.
- The local ACK/fill/cancel/modify events are emulator events, not exchange
  acknowledgments, order-queue positions, or venue records. No live exchange,
  testnet, complete matching-engine conformance, or network/venue latency was
  measured.
- No independent third-party timestamp, public-key registration, external
  checkpoint, or Ed25519 evidence is established here. The standard-library
  fault run uses a SHA-256 test token; it is not a cryptographic signature
  result.
- The run does not establish arbitrary-LLM generalization, profitable trading,
  deployment-level privacy, or production hardware throughput. These limits are
  carried into the manuscript, response letter, and cover letter.

## Reproducibility

The complete archive contains command lines, stdout/stderr, selected source
hashes, key JSON/CSV outputs, and `results_manifest.json`; it does not contain
the source files. The 24-file locally retained board-run package has now been
restored without content changes under `source_package/`. Start with
`source_package/README_RESTORED.md` for dependencies, fixed standard-library
commands, the local smoke checks, and the limits of historical source binding.
`source_package/SOURCE_PROVENANCE.json` records every restored file's current
hash and its historical evidence, if any.

`source_package/FROZEN_EVENT_AUDIT.json` independently recomputes the frozen
3,008 fault-row counts, send suppression, and heartbeat fields, plus the
surrogate summary from all 2,880 timing rows. It does not rely on the old
summary's constant invariant booleans. The audit also records what the rows
cannot prove: real timeout execution, periodic heartbeat timing, or token
verification. This was a read-only audit, not a new board experiment.

The frozen archive's recorded source hashes match the restored matching-engine
and deterministic-scenario scripts, and its recorded input hash matches the
2,000-row replay. Six other executed Python entry points, including the three
standard-library compatibility harnesses, have no recorded historical source
hash. Their restoration supplies runnable retained code, but does not prove
that these files were byte-identical at the original run. The archive and
`key_outputs/` remain unchanged. Local checksums are for reproducibility and
are not an external trust anchor.
