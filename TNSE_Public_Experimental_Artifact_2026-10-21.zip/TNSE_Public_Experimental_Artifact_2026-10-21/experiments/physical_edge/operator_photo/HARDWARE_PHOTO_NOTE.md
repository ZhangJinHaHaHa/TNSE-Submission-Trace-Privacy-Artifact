> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Operator-provided hardware photo

`jetson_edge_run_terminal_photo.jpg` is a photo supplied by the operator on 18
October 2026. It shows the terminal on the edge host after the run, including
the generated result archive and the displayed return-code checks.

No model or memory-capacity label is used as a hardware result. The
authoritative runtime evidence is the read-only system probe in
`key_outputs/board_probe.json`, which records the observed `aarch64` platform,
Orin GPU driver, CPU, memory, kernel, and thermal values. The probe is a
runtime inventory, not an independent third-party certification. The photo
does not establish sustained throughput, power, NIC/network latency, live
exchange connectivity, or pretrained-LLM execution.
