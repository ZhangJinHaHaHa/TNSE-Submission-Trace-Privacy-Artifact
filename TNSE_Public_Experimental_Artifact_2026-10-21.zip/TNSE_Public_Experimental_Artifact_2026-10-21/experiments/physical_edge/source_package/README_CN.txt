> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

TNSE 物理 Edge 板卡离线运行包
================================

目的
----
这个包用于在无法公网 SSH 的物理 Edge 电脑上运行可复现的本地实验，并自动把结果整理为 ZIP。它不需要连接交易所，也不会修改网络、驱动或系统服务。

最简单的运行方式
------------------
1. 把整个文件夹复制到板卡，例如放到 ~/work2/TNSE_Edge_Board_Run_Package。
2. 打开终端，进入该文件夹。
3. 执行：

   bash run_edge.sh

如果 ToDesk 粘贴失效，只需要用屏幕键盘输入这一个命令。脚本会自己执行全部步骤；不要手动逐条输入长命令。

输出
----
运行完成后，文件夹内会出现：

* results_时间戳/：全部原始输出、硬件探针、运行日志和哈希清单。
* TNSE_Edge_Board_Results_时间戳.zip：需要回传给作者的唯一结果包。

请把这个 ZIP 通过 ToDesk 文件传输或其他方式回传，不要只发截图。

默认步骤
----------
* board_probe：读取系统、CPU、内存、磁盘、温度和可用 GPU 信息。
* edge_fault：本地 release/sign/verify/timeout/fail-closed 故障矩阵。
* release_validation：固定释放核的随机化和不变量检查。
* lifecycle_scenarios：本地撮合引擎 ACK、FIFO、撤单、修改和拒绝路径。
* lifecycle_replay：对随包提供的 2,000 行历史 LOBSTER 派生回放做可观察事件审计。
* surrogate_edge：离线确定性代理和注入 RTT 的 Edge 路径测量；它不是预训练 LLM。

可选真实预训练模型步骤
------------------------
默认不运行真实 LLM，避免把代理结果误报为真实模型。如果板卡上已经启动本机 OpenAI-compatible llama.cpp 服务，并且有本地模型文件，可在运行前设置：

   export TNSE_LLM_BASE_URL=http://127.0.0.1:8765/v1
   export TNSE_LLM_MODEL_PATH=/实际/模型文件路径
   bash run_edge.sh

只有这两个变量都设置时，才会运行 llm_pretrained_runner.py。结果中必须保留模型路径、模型哈希、服务地址和解析统计，才能作为真实预训练 checkpoint/interface test 的证据。

依赖
----
board_probe、撮合场景和结果打包只需要 Python 3。只有在 `cryptography` 和 `numpy` **同时可导入**时，故障矩阵才会运行 `edge_fault_benchmark.py`（该脚本依赖 `bounded_release.py` 的 NumPy 实现，并提供 Ed25519 签名/验证测量）。只要任一依赖缺失，脚本就会明确运行 `edge_fault_stdlib.py`；该模式使用 SHA-256 测试令牌，不是 Ed25519 证据。如果板卡缺少 numpy，释放验证会自动改用 `validate_release_stdlib.py`；如果缺少 numpy/pandas，Edge 代理会自动改用 `surrogate_edge_stdlib.py`。兼容模式都会在 `STATUS.txt` 和结果清单中明确标注，不会自动联网安装软件。

解释边界
--------
这些结果可以证明板卡上的硬件/软件测量和本地协议路径，不等于真实交易所部署、完整交易所队列/ACK 语义、第三方独立锚定、任意 LLM 泛化或硬件上的差分隐私证明。若真实 LLM 步骤被跳过，必须保留 SKIPPED 文件，不能把离线代理结果写成真实 LLM 结果。
