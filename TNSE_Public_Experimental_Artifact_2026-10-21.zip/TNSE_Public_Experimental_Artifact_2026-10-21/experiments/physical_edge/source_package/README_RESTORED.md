> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Retained board-run source package: restoration record

Restored on 21 October 2026 from the local directory
`outputs/TNSE_Edge_Board_Run_Package_2026-10-18`. All 24 original files,
including the 2,000-row replay input, are preserved byte-for-byte. This README,
`SOURCE_PROVENANCE.json`, and `FROZEN_EVENT_AUDIT.json` are new restoration and
audit records. The source snapshot is separate from the immutable operator
output archive one directory above.

## What can be verified historically

The frozen run identifier is `20261017T190612Z`, as recorded in
`../key_outputs/STATUS.txt`. The folder's 18 October label is retained from the
local package name; it is not a second execution date or a source commit ID.

The frozen ZIP has 44 members. All 43 files listed in its
`results_manifest.json` match their recorded SHA-256 and byte count; the
manifest itself is not self-listed. It includes no `.py` or `.sh` source files.
The current ZIP SHA-256 is
`7428f6933e1f785964d58036be9261ccf36732c3342f9317a6fe29d9d4d451da`.

Only these restored contents have hashes recorded inside the frozen results:

| Restored relative path | Historical evidence inside the frozen ZIP |
| --- | --- |
| `strengthening/exchange_lifecycle/matching_engine_replay.py` | `lifecycle_replay/exchange_lifecycle_manifest.json`, `script_sha256` |
| `strengthening/exchange_lifecycle/deterministic_scenarios.py` | `lifecycle_scenarios/scenario_manifest.json`, `script_sha256` |
| `strengthening/lobster_replay_2000/lobster_replay_2000.csv` | `lifecycle_replay/exchange_lifecycle_manifest.json` and `lifecycle_manifest.json`, `replay_sha256` |

All three hashes match. There is no historical source hash for the other six
executed Python entry points: `board_probe.py`, `package_results.py`,
`validate_release_stdlib.py`, `strengthening/edge_fault_stdlib.py`,
`strengthening/lifecycle_replay.py`, and
`strengthening/augmented/surrogate_edge_stdlib.py`. Their names and command
arguments are documented by `STATUS.txt`, but this does not establish their
historical bytes. `run_edge.sh`, optional sources, environment files, and the
original documentation also have no historical file-hash binding. Newly
computed hashes in `SOURCE_PROVENANCE.json` identify the retained snapshot;
they do not retroactively authenticate the original execution.

The source package's `strengthening/lobster_replay_2000/lifecycle_manifest.json`
is an earlier input-side record, not a byte-identical copy of the frozen
output-side `lifecycle_manifest.json`. It names `lobster_2000.csv` and Python
3.12.0, whereas the frozen output names `lobster_replay_2000.csv` and Python
3.13.11. Both record the same replay-content hash. The upstream LOBSTER ZIP
hash in `lobster_replay_manifest.json` is retained provenance; that upstream
ZIP is not included here and was not independently revalidated during this
restoration. No download is needed to use the supplied replay.

## Dependencies and execution scope

The recorded run used Python 3.13.11 (Anaconda) on Linux aarch64. Its actual
workload commands below use only the Python standard library and local files.
Use Python 3.10 or newer on Linux or macOS; the surrogate imports the Unix
`resource` module. No third-party installation, model, network endpoint,
exchange account, GPU, or accelerator is required for these software checks.

`environment.yml` is the original optional dependency specification, not a
lockfile or the captured board environment. Installing it would add NumPy,
pandas, and cryptography, which would cause the original `run_edge.sh` to select
different implementations. The original runner also executes `board_probe.py`
and can call a pretrained-model endpoint when both `TNSE_LLM_BASE_URL` and
`TNSE_LLM_MODEL_PATH` are set. For the recorded stdlib path, use the explicit
commands below instead of the original runner. Optional NumPy/Ed25519/LLM
sources are retained for context and were not the workload recorded for this
board run.

## Re-run the recorded software workloads

From this `source_package` directory, run the following in Bash or Zsh. It
creates a fresh temporary output directory, exits on failure, disables
site-package imports and bytecode writes, and executes the same six workload
entry points and numerical arguments recorded in `STATUS.txt`. Only output
paths and the interpreter flags differ. It does not run the board probe or
pretrained LLM and does not modify the frozen ZIP or `key_outputs/`.

```sh
set -eu
TNSE_REPLAY_OUT=$(mktemp -d "${TMPDIR:-/tmp}/tnse-recorded-stdlib.XXXXXX")
python3 -B -S -c 'import sys; assert sys.version_info >= (3, 10)'
python3 -B -S strengthening/edge_fault_stdlib.py --out "$TNSE_REPLAY_OUT/edge_fault" --normal-repeats 2000 --fault-repeats 200 --warmup 50
python3 -B -S validate_release_stdlib.py --out "$TNSE_REPLAY_OUT/release_validation" --samples 10000
python3 -B -S strengthening/exchange_lifecycle/deterministic_scenarios.py --out "$TNSE_REPLAY_OUT/lifecycle_scenarios"
python3 -B -S strengthening/exchange_lifecycle/matching_engine_replay.py --replay strengthening/lobster_replay_2000/lobster_replay_2000.csv --out "$TNSE_REPLAY_OUT/lifecycle_replay"
python3 -B -S strengthening/lifecycle_replay.py --replay strengthening/lobster_replay_2000/lobster_replay_2000.csv --out "$TNSE_REPLAY_OUT/observable_lifecycle.csv"
python3 -B -S strengthening/augmented/surrogate_edge_stdlib.py --out "$TNSE_REPLAY_OUT/surrogate_edge" --seeds 0 1 2 --episodes 40 --steps 32 --edge-events 120 --rtts 0.5 1 5 20 --deadline-ms 5
python3 -B -S package_results.py --results "$TNSE_REPLAY_OUT" --archive "${TNSE_REPLAY_OUT}.zip"
printf 'New local output: %s\nNew local archive: %s.zip\n' "$TNSE_REPLAY_OUT" "$TNSE_REPLAY_OUT"
```

These commands create a new local software run, not another Jetson measurement
or a replacement for the archived evidence. The historical read-only probe
command is retained in `STATUS.txt` and its source is supplied; it was not
executed during restoration. Timings, RSS, platform identifiers, Python
versions, and output paths depend on the new host and must not be substituted
into the historical results. The packaging script hashes output files, not
the source tree; retain `SOURCE_PROVENANCE.json` alongside any new results.

## Compatibility limits visible in the retained source

- `edge_fault_stdlib.py` constructs local branch records and SHA-256 test
  tokens. It does not perform real transport or Ed25519 signing. The timeout
  branch is a labelled suppression branch with no attempted network send.
  `--warmup` is accepted but unused in this version. Its summary invariant
  booleans are assigned constants; validate the generated event rows when
  checking those properties.
- `validate_release_stdlib.py` checks randomized-status and fixed-slot budget,
  schema, and halt invariants. Its quantity perturbation uses a fixed Gaussian
  standard deviation of 0.05. It is not the current analytic-Gaussian bounded
  release implementation or evidence of its calibration. The compatibility
  summary already states that it is not a byte-for-byte NumPy replacement.
- `surrogate_edge_stdlib.py` uses a deterministic local policy. Reported
  end-to-end latency adds a simulated delay to measured software computation:
  0.1 times the configured RTT for `edge_local`, and one RTT for `cloud_proxy`.
  Its privacy and byte-count fields are configured surrogate values, not a
  calibrated release proof or measured network traffic. It is not a
  pretrained-model benchmark.

These behaviours are preserved for inspection; no historical source file was
edited to strengthen the apparent evidence.

## Independent audit of the frozen event rows

`FROZEN_EVENT_AUDIT.json` reports read-only checks of all archived fault and
surrogate timing rows. The 3,008 fault rows contain 2,000 normal records, five
200-record fault groups, and eight budget-exhaustion records. All 2,000 normal
rows report positive send bytes; all 1,008 fault rows report zero. Recorded
authorization/signing/transport fields satisfy the checked implications, and
all 3,008 rows report `heartbeat_emitted=True` and `heartbeat_bytes=17`. These
conclusions are computed from the CSV rather than copied from the summary's
constant invariant booleans.

All 200 timeout rows record `transport_attempted=False`. There are no heartbeat
timestamps or packet captures, so the rows cannot establish a real transport
timeout, periodic fixed-slot scheduling, or actual heartbeat transmission.
The 12 `edge_fault_signed_sample.jsonl` records contain no payload, token,
signature, or public-key material. Thus the historical ledger's `verified=true`
flag is not independent token or signature verification. These limits remain
even though the branch-record checks pass.

The same audit recomputes counts, means, p50/p95, compute and injected-delay
means, and deadline-miss rates for all eight deployment/RTT groups (360 events
each; 2,880 total rows). They match the frozen summary within 1e-12 relative or
absolute tolerance. Every row follows the documented injected-delay formula;
this confirms the reported arithmetic, not a measured network advantage.

## Restoration checks completed

On the local Python 3.12.0 host, all 14 restored Python files compiled with
bytecode directed to a temporary directory. Seven stdlib-only commands
completed: the six workload scripts plus result packaging. The smoke sizes
were 20 normal and four repeats per fault branch (48 total rows), 100 release
samples per status/scale, and a one-seed/two-episode/three-step surrogate with
four events at each of two RTTs (16 timing rows). The 24 release sessions and
all five deterministic lifecycle scenarios completed successfully. Raw fault
rows were independently checked for send suppression and heartbeat fields,
release rows for budget caps, and timing rows for the injected-delay formula.

The complete 2,000-row replay was also run locally. Five deterministic outputs
were byte-identical to the frozen ZIP: `scenario_metrics.json`,
`scenario_events.jsonl`, `exchange_lifecycle_summary.json`,
`exchange_lifecycle_events.csv`, and `observable_lifecycle.csv` in their
respective output directories. Matching outputs support reproducibility but
do not supply missing historical source hashes. The new smoke archive's file
hashes passed verification. Neither a hardware probe nor an LLM was executed;
the frozen result archive retained its original SHA-256.
