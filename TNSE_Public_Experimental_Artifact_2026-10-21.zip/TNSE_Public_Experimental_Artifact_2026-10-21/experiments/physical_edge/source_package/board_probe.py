#!/usr/bin/env python3
"""Collect non-destructive hardware and runtime diagnostics for the board."""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path


def command_text(command: list[str], timeout: float = 15.0) -> dict[str, object]:
    executable = shutil.which(command[0])
    if executable is None:
        return {"available": False, "command": command, "stdout": "", "stderr": "not found", "returncode": None}
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except Exception as error:
        return {"available": True, "command": command, "stdout": "", "stderr": repr(error), "returncode": None}
    return {
        "available": True,
        "command": command,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "returncode": completed.returncode,
    }


def read_text(path: Path) -> str | None:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
    try:
        descriptor = os.open(os.fspath(path), flags)
    except (OSError, TypeError, ValueError):
        return None
    try:
        chunks: list[bytes] = []
        while True:
            chunk = os.read(descriptor, 65536)
            if not chunk:
                break
            chunks.append(chunk)
        return b"".join(chunks).decode("utf-8", errors="replace")
    except (OSError, TypeError, UnicodeError):
        return None
    finally:
        try:
            os.close(descriptor)
        except OSError:
            pass


def collect(out: Path) -> dict[str, object]:
    out.mkdir(parents=True, exist_ok=True)
    commands = {
        "uname": ["uname", "-a"],
        "lscpu": ["lscpu"],
        "free": ["free", "-h"],
        "df": ["df", "-h"],
        "nvidia_smi": [
            "nvidia-smi",
            "--query-gpu=index,name,memory.total,driver_version,temperature.gpu",
            "--format=csv,noheader",
        ],
        "tegrastats": ["tegrastats", "--interval", "1000", "--count", "1"],
    }
    command_results = {name: command_text(command) for name, command in commands.items()}
    thermal: dict[str, str] = {}
    thermal_root = Path("/sys/class/thermal")
    if thermal_root.exists():
        for temp_path in sorted(thermal_root.glob("thermal_zone*/temp")):
            value = read_text(temp_path)
            if value is not None:
                thermal[str(temp_path)] = value.strip()
    identity = {
        "hostname": platform.node(),
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python": sys.version,
        "pid": os.getpid(),
    }
    result = {
        "schema": "tnse-edge-board-probe-v1",
        "utc_epoch": time.time(),
        "identity": identity,
        "commands": command_results,
        "thermal_zone_values": thermal,
        "notes": [
            "The probe is read-only and does not change network, drivers, power, or services.",
            "No passwords, private keys, MAC addresses, or full network configuration are collected.",
            "nvidia-smi and tegrastats are optional and may be unavailable on non-NVIDIA boards.",
        ],
    }
    (out / "board_probe.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    lines = ["TNSE EDGE BOARD PROBE", "", json.dumps(identity, indent=2, sort_keys=True)]
    for name, value in command_results.items():
        lines.extend(["", f"===== {name} =====", str(value.get("stdout", "")), str(value.get("stderr", ""))])
    lines.extend(["", "===== thermal zones =====", json.dumps(thermal, indent=2, sort_keys=True)])
    (out / "board_probe.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(collect(args.out), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
