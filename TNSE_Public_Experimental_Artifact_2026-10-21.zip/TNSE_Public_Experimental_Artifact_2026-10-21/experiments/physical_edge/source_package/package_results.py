#!/usr/bin/env python3
"""Create a portable archive of one completed board run."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import zipfile
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    files = sorted(path for path in args.results.rglob("*") if path.is_file() and path != args.archive)
    manifest = {
        "schema": "tnse-edge-board-results-v1",
        "python": sys.version,
        "platform": platform.platform(),
        "results_directory": args.results.name,
        "files": [{"path": str(path.relative_to(args.results)), "sha256": sha256(path), "bytes": path.stat().st_size} for path in files],
        "interpretation": "Board diagnostics and local/software benchmark outputs. A pretrained-LLM result is valid only when the optional local runner records its model and endpoint provenance.",
    }
    (args.results / "results_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    files.append(args.results / "results_manifest.json")
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.archive, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(args.results))
    print(args.archive)


if __name__ == "__main__":
    main()
