#!/usr/bin/env bash
set +e

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
OUT="$ROOT/results_$STAMP"
mkdir -p "$OUT"

PYTHON_BIN=${PYTHON_BIN:-$(command -v python3 || command -v python || true)}
if [ -z "$PYTHON_BIN" ]; then
  printf '%s\n' 'No Python interpreter was found.' > "$OUT/STATUS.txt"
  exit 2
fi

printf 'TNSE physical-edge run\nUTC: %s\nPython: %s\n' "$STAMP" "$PYTHON_BIN" > "$OUT/STATUS.txt"

run_step() {
  name=$1
  shift
  printf '\n[%s] %s\n' "$name" "$*" | tee -a "$OUT/STATUS.txt"
  "$@" > "$OUT/$name.stdout.txt" 2> "$OUT/$name.stderr.txt"
  rc=$?
  printf '%s return_code=%s\n' "$name" "$rc" | tee -a "$OUT/STATUS.txt"
  return 0
}

run_step board_probe "$PYTHON_BIN" "$ROOT/board_probe.py" --out "$OUT/board_probe"
if "$PYTHON_BIN" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
  run_step compile_check "$PYTHON_BIN" -m py_compile "$ROOT/board_probe.py" "$ROOT/package_results.py" "$ROOT/validate_release_stdlib.py" "$ROOT/strengthening/edge_fault_stdlib.py" "$ROOT/strengthening/lifecycle_replay.py" "$ROOT/strengthening/augmented/surrogate_edge_stdlib.py" "$ROOT/strengthening/exchange_lifecycle/matching_engine_replay.py" "$ROOT/strengthening/exchange_lifecycle/deterministic_scenarios.py"
else
  printf '%s\n' 'compile_check skipped: Python version is older than 3.10.' > "$OUT/compile_check.stdout.txt"
  printf '%s\n' 'return_code=0' | tee -a "$OUT/STATUS.txt"
fi
if "$PYTHON_BIN" -c 'import cryptography, numpy' >/dev/null 2>&1; then
  run_step edge_fault "$PYTHON_BIN" "$ROOT/strengthening/edge_fault_benchmark.py" --out "$OUT/edge_fault" --normal-repeats 2000 --fault-repeats 200 --warmup 50
else
  run_step edge_fault_stdlib "$PYTHON_BIN" "$ROOT/strengthening/edge_fault_stdlib.py" --out "$OUT/edge_fault" --normal-repeats 2000 --fault-repeats 200 --warmup 50
fi
if "$PYTHON_BIN" -c 'import numpy' >/dev/null 2>&1; then
  run_step release_validation "$PYTHON_BIN" "$ROOT/strengthening/validate_release.py" --out "$OUT/release_validation" --samples 10000
else
  run_step release_validation_stdlib "$PYTHON_BIN" "$ROOT/validate_release_stdlib.py" --out "$OUT/release_validation" --samples 10000
fi
run_step lifecycle_scenarios "$PYTHON_BIN" "$ROOT/strengthening/exchange_lifecycle/deterministic_scenarios.py" --out "$OUT/lifecycle_scenarios"
run_step lifecycle_replay "$PYTHON_BIN" "$ROOT/strengthening/exchange_lifecycle/matching_engine_replay.py" --replay "$ROOT/strengthening/lobster_replay_2000/lobster_replay_2000.csv" --out "$OUT/lifecycle_replay"
run_step observable_lifecycle "$PYTHON_BIN" "$ROOT/strengthening/lifecycle_replay.py" --replay "$ROOT/strengthening/lobster_replay_2000/lobster_replay_2000.csv" --out "$OUT/observable_lifecycle.csv"
if "$PYTHON_BIN" -c 'import numpy, pandas' >/dev/null 2>&1; then
  run_step surrogate_edge "$PYTHON_BIN" "$ROOT/strengthening/augmented/llm_edge_experiment.py" --out "$OUT/surrogate_edge" --seeds 0 1 2 --episodes 40 --steps 32 --edge-events 120 --rtts 0.5 1 5 20 --deadline-ms 5
else
  run_step surrogate_edge_stdlib "$PYTHON_BIN" "$ROOT/strengthening/augmented/surrogate_edge_stdlib.py" --out "$OUT/surrogate_edge" --seeds 0 1 2 --episodes 40 --steps 32 --edge-events 120 --rtts 0.5 1 5 20 --deadline-ms 5
fi

if [ -n "${TNSE_LLM_BASE_URL:-}" ] && [ -n "${TNSE_LLM_MODEL_PATH:-}" ]; then
  run_step pretrained_llm "$PYTHON_BIN" "$ROOT/strengthening/llm_pretrained_runner.py" --base-url "$TNSE_LLM_BASE_URL" --model-path "$TNSE_LLM_MODEL_PATH" --model "${TNSE_LLM_MODEL:-local-pretrained-model}" --replay "$ROOT/strengthening/lobster_replay_2000/lobster_replay_2000.csv" --out "$OUT/pretrained_llm" --seeds 0 1 2 --episodes 8 --steps 8
else
  printf '%s\n' 'pretrained_llm: SKIPPED; set TNSE_LLM_BASE_URL and TNSE_LLM_MODEL_PATH only when a local model and local OpenAI-compatible server are available.' > "$OUT/pretrained_llm_SKIPPED.txt"
fi

run_step package_results "$PYTHON_BIN" "$ROOT/package_results.py" --results "$OUT" --archive "$ROOT/TNSE_Edge_Board_Results_$STAMP.zip"
printf '\nRESULT_ARCHIVE=%s\n' "$ROOT/TNSE_Edge_Board_Results_$STAMP.zip" | tee -a "$OUT/STATUS.txt"
