> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Targeted strengthening experiments included in the board package

This directory contains narrow, reproducible checks added for the resubmission.
They support interface and fault-handling claims, not live exchange deployment
or a new privacy proof.

The real-model runners are interface tests for two local pretrained checkpoints
(Qwen2.5-3B-Instruct and Qwen3-1.7B), not a claim about a generally capable
trading agent or arbitrary-LLM generalization. The replay outputs summarize
observable market-message lifecycles only; they do not reconstruct queue
position, agent acknowledgements, venue latency, or a complete exchange.

## Contents in this package

- `llm_pretrained_runner.py`: calls a local OpenAI-compatible `llama.cpp`
  server using a public Qwen2.5-3B-Instruct GGUF checkpoint, a fixed prompt,
  structured JSON actions, and a historical replay. The archived run retains
  parser-normalized rows rather than raw completions; new reruns retain all
  raw completion records and strict-versus-normalized parse status.
- `lobster_replay.py` and `lobster_replay_2000/`: parse or replay the bundled
  2,000-row LOBSTER-derived event sample.
- `lifecycle_replay.py`: audits observable submission, cancellation, deletion,
  and execution transitions without inferring an agent/venue lifecycle.
- `bounded_release.py` and `validate_release.py`: fixed-slot bounded release
  kernel and invariant/closed-form randomized-response checks.
- `edge_fault_benchmark.py`: local release/sign/verify/transport fault matrix
  with fail-closed send assertions and a separate fixed-slot mock heartbeat.
- `exchange_lifecycle/`: deterministic single-threaded price--time-priority
  software exchange emulator with local ACK/reject, fill, cancel, modify, and
  five invariant scenarios. Synthetic stress commands are labelled and are not
  historical venue events.
- `augmented/llm_edge_experiment.py`: deterministic offline surrogate and
  injected-RTT Edge-path experiment; it is not a pretrained LLM.
- `llm_pretrained_runner.py`: optional runner for a local OpenAI-compatible
  llama.cpp server and a user-supplied checkpoint; it is not run by default.

## Reproduction

```bash
python3 lobster_replay.py \
  --zip /path/to/lobster_AAPL10.zip --rows 240 \
  --out /tmp/lobster_replay

python3 llm_pretrained_runner.py \
  --base-url http://127.0.0.1:8767/v1 \
  --model qwen2.5-3b-instruct-q4_k_m.gguf \
  --model-path /path/to/qwen2.5-3b-instruct-q4_k_m.gguf \
  --replay /tmp/lobster_replay/lobster_replay.csv \
  --out /tmp/real_llm_lobster --seeds 0 1 2 \
  --episodes 8 --steps 8 \
  --conditions public_only explicit_user_state hidden_system_state \
  --allow-json-object-fallback --llama-cpp-version 0.3.18 \
  --context-size 2048 --backend Metal

python3 lobster_replay.py --zip /path/to/lobster_AAPL10.zip --rows 2000 \
  --out /tmp/lobster_replay_2000/lobster_replay_2000.csv
python3 lifecycle_replay.py \
  --replay /tmp/lobster_replay_2000/lobster_replay_2000.csv \
  --out /tmp/lobster_replay_2000/lifecycle_events.csv

python3 validate_release.py --out /tmp/release_validation
python3 edge_fault_benchmark.py --out /tmp/edge_fault
```

The archived results record the exact model, prompt, replay, and source
hashes. The raw LOBSTER archive and model weights are not redistributed. The
recorded `/private/tmp` paths are local-run provenance only; reproduction uses
the public URLs and SHA-256 values in `SOURCE_NOTES.md`.

## Scope

The archived Qwen2.5 run and the Qwen3 three-condition rerun are kept
separately: the historical 384-call archive retains parser-normalized rows
without raw completions, while the completed Qwen2.5 audit retains 960 model
calls and 1,152 action rows with the full raw-completion log. The Qwen3 audit
retains 1,152 calls (384 per condition) and its strict/normalized parser
status. With
`llama-cpp-python` 0.3.18 the server accepts `json_object` but rejects the
requested `json_schema`; the explicit fallback and its status are recorded in
the manifest, so the rerun must not be described as JSON-Schema-constrained.
The package also contains a 2,000-row LOBSTER message replay and its
observable-event lifecycle summary, plus a separate 400,390-message
eight-window blocked replay audit. LOBSTER is an historical sample replay, not
a live venue or matching-engine evaluation. The separate exchange-lifecycle
emulator is software-only: its ACKs and fills are local events, not venue
records, and it does not measure network/venue latency or physical Edge.
Latency is measured on the local host and excludes network, exchange, and
hardware deployment effects. The edge benchmark is software-only and does
not establish differential privacy beyond the bounded-kernel checks included
in the archive.
