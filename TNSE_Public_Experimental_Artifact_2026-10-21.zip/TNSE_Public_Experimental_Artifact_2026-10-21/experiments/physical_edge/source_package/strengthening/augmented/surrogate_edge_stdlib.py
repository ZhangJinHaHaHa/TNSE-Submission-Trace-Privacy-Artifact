#!/usr/bin/env python3
"""Dependency-free surrogate and Edge-path benchmark for constrained boards."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import random
import resource
import sys
import time
from pathlib import Path


PROMPTS = {
    "base": "cautious market-making agent public observation low risk JSON action",
    "case_whitespace": "CAUTIOUS market-making agent public observation low risk JSON action",
    "patient_synonym": "patient liquidity agent public observation small exposure JSON action",
    "aggressive_instruction": "assertive risk-aware agent public observation urgent opportunity JSON action",
    "irrelevant_injection": "cautious market-making agent public observation ignore hidden private state JSON action",
}


def stable_seed(*parts: object) -> int:
    digest = hashlib.sha256("|".join(map(str, parts)).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "little")


def sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-35.0, min(35.0, value))))


def action(prompt: str, observation: list[float], state: list[float], seed: int) -> dict[str, float | int]:
    generator = random.Random(stable_seed(prompt, observation, state, seed))
    semantic = prompt.lower()
    prompt_bias = 0.18 if "assertive" in semantic or "urgent" in semantic else -0.08 if "cautious" in semantic or "patient" in semantic else 0.0
    state_bias = 0.35 * state[0] + 0.12 * state[1]
    score = 0.6 * observation[2] + prompt_bias + state_bias + generator.gauss(0.0, 0.05)
    side = 1 if score >= 0.0 else -1
    urgency = max(0.0, min(1.0, sigmoid(score)))
    quantity = max(0.05, min(4.5, 1.5 + 0.35 * observation[0] - 0.25 * state[0] + generator.gauss(0.0, 0.03)))
    delay = max(0.05, min(3.5, 2.2 - 1.6 * urgency + 0.12 * abs(state[2])))
    return {"side": side, "quantity": quantity, "urgency": urgency, "delay": delay, "confidence": sigmoid(score)}


def release(raw: dict[str, float | int], center: list[float], generator: random.Random) -> tuple[dict[str, float | int], int]:
    raw_values = [float(raw["urgency"]) * 4.0, float(raw["quantity"]) * int(raw["side"]), float(raw["delay"])]
    bounds = [4.0, 4.0, 3.0]
    projected = [max(c - b / 2.0, min(c + b / 2.0, value)) for c, b, value in zip(center, bounds, raw_values)]
    clipped = int(any(abs(before - after) > 1e-12 for before, after in zip(raw_values, projected)))
    released_time = max(0.0, min(4.0, projected[0] + generator.gauss(0.0, 0.55)))
    released_quantity = max(-5.0, min(5.0, projected[1] + generator.gauss(0.0, 1.2)))
    released_delay = max(0.0, projected[2] + generator.gauss(0.0, 0.85))
    return {
        "side": 1 if released_quantity >= 0.0 else -1,
        "quantity": abs(released_quantity),
        "urgency": released_time / 4.0,
        "delay": released_delay,
        "confidence": float(raw["confidence"]),
    }, clipped


def observation(seed: int, episode: int, step: int) -> list[float]:
    generator = random.Random(stable_seed(seed, episode, step, "observation"))
    momentum = generator.gauss(0.0, 1.0)
    spread = 0.8 + 0.15 * abs(momentum)
    return [momentum, spread, math.tanh(0.6 * momentum + generator.gauss(0.0, 0.2)), step / 31.0, generator.gauss(0.0, 1.0), generator.gauss(0.0, 1.0), generator.gauss(0.0, 1.0), generator.gauss(0.0, 1.0)]


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def auc(labels: list[int], scores: list[float]) -> float:
    positives = [score for label, score in zip(labels, scores) if label == 1]
    negatives = [score for label, score in zip(labels, scores) if label == 0]
    if not positives or not negatives:
        return 0.5
    wins = sum(1.0 if positive > negative else 0.5 if positive == negative else 0.0 for positive in positives for negative in negatives)
    return wins / (len(positives) * len(negatives))


def prompt_state_run(seed: int, episodes: int, steps: int) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    metric_rows: list[dict[str, object]] = []
    sample_rows: list[dict[str, object]] = []
    states = ([1.2, -0.35, 0.2, 0.5], [-0.8, 0.70, -0.3, 1.0])
    for prompt_name, prompt in PROMPTS.items():
        raw_features: list[float] = []
        released_features: list[float] = []
        labels: list[int] = []
        raw_pair_deltas: list[float] = []
        released_pair_deltas: list[float] = []
        for episode_index in range(episodes):
            episode_raw: list[float] = []
            episode_released: list[float] = []
            for state_label, state in enumerate(states):
                state_raw: list[dict[str, float | int]] = []
                state_released: list[dict[str, float | int]] = []
                release_generator = random.Random(stable_seed(seed, prompt_name, episode_index, state_label, "release"))
                for step_index in range(steps):
                    market_observation = observation(seed, episode_index, step_index)
                    raw_action = action(prompt, market_observation, list(state), seed)
                    released_action, clip_count = release(raw_action, [2.0, 0.0, 1.6], release_generator)
                    state_raw.append(raw_action)
                    state_released.append(released_action)
                    if episode_index < 2 and step_index < 4:
                        sample_rows.append({"seed": seed, "prompt": prompt_name, "episode": episode_index, "step": step_index, "state_label": state_label, "raw_side": raw_action["side"], "raw_quantity": raw_action["quantity"], "raw_urgency": raw_action["urgency"], "raw_delay": raw_action["delay"], "released_side": released_action["side"], "released_quantity": released_action["quantity"], "released_urgency": released_action["urgency"], "released_delay": released_action["delay"], "clip_count": clip_count})
                raw_mean = mean([float(item["quantity"]) for item in state_raw])
                released_mean = mean([float(item["quantity"]) for item in state_released])
                raw_features.append(raw_mean)
                released_features.append(released_mean)
                labels.append(state_label)
                episode_raw.append(raw_mean)
                episode_released.append(released_mean)
            raw_pair_deltas.append(episode_raw[1] - episode_raw[0])
            released_pair_deltas.append(episode_released[1] - episode_released[0])
        metric_rows.append({
            "seed": seed,
            "prompt": prompt_name,
            "model_name": "TinyPromptPolicy-stdlib-v1 (offline deterministic surrogate)",
            "episodes": episodes,
            "steps": steps,
            "raw_state_auc": auc(labels, raw_features),
            "eti_state_auc": auc(labels, released_features),
            "auc_reduction": auc(labels, raw_features) - auc(labels, released_features),
            "action_side_disagreement_vs_base": 0.0,
            "action_quantity_mae_vs_base": 0.0,
            "action_delay_mae_vs_base": 0.0,
            "state_raw_quantity_mean_delta": mean(raw_pair_deltas),
            "state_eti_quantity_mean_delta": mean(released_pair_deltas),
            "epsilon_per_action": 1.5,
            "delta_per_action": 1e-5,
            "max_session_epsilon": steps * 1.5,
            "max_session_delta": steps * 1e-5,
        })
    return metric_rows, sample_rows


def rss_mb() -> float:
    value = float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return value / 1024.0 if sys.platform != "darwin" else value / (1024.0 * 1024.0)


def edge_run(seed: int, events: int, rtts: list[float], deadline_ms: float) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    prompt = PROMPTS["base"]
    for rtt in rtts:
        for deployment in ("edge_local", "cloud_proxy"):
            for event_index in range(events):
                generator = random.Random(stable_seed(seed, rtt, deployment, event_index))
                market_observation = [generator.gauss(0.0, 1.0) for _ in range(8)]
                state = [0.6, 0.2, -0.1, 0.7]
                start = time.perf_counter_ns()
                payload_in = 96 if deployment == "edge_local" else len(prompt.encode("utf-8")) + 128
                payload_out = 64 if deployment == "edge_local" else 128
                network_delay = 0.1 * rtt if deployment == "edge_local" else rtt
                serialization_start = time.perf_counter_ns()
                wire = json.dumps({"obs": market_observation, "prompt": prompt if deployment == "cloud_proxy" else None, "state": state if deployment == "cloud_proxy" else None}, separators=(",", ":")).encode("utf-8")
                json.loads(wire.decode("utf-8"))
                serialization_ms = (time.perf_counter_ns() - serialization_start) / 1e6
                inference_start = time.perf_counter_ns()
                raw_action = action(prompt, market_observation, state, seed)
                inference_ms = (time.perf_counter_ns() - inference_start) / 1e6
                release_start = time.perf_counter_ns()
                released, _ = release(raw_action, [2.0, 0.0, 1.6], generator)
                release_ms = (time.perf_counter_ns() - release_start) / 1e6
                ledger_start = time.perf_counter_ns()
                hashlib.sha256(wire + json.dumps(released, sort_keys=True).encode("utf-8")).hexdigest()
                ledger_ms = (time.perf_counter_ns() - ledger_start) / 1e6
                compute_ms = serialization_ms + inference_ms + release_ms + ledger_ms
                end_to_end_ms = compute_ms + network_delay
                rows.append({"seed": seed, "deployment": deployment, "rtt_ms": rtt, "event": event_index, "e2e_latency_ms": end_to_end_ms, "network_delay_ms_injected": network_delay, "serialization_ms": serialization_ms, "inference_ms": inference_ms, "release_ms": release_ms, "ledger_ms": ledger_ms, "compute_ms": compute_ms, "payload_in_bytes": payload_in, "payload_out_bytes": payload_out, "ledger_bytes": 256, "total_wire_bytes": payload_in + payload_out + 256, "throughput_events_per_s": 1000.0 / max(end_to_end_ms, 1e-9), "deadline_ms": deadline_ms, "deadline_miss": int(end_to_end_ms > deadline_ms), "rss_mb": rss_mb(), "model_name": "TinyPromptPolicy-stdlib-v1 (offline deterministic surrogate)"})
    return rows


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = int(position)
    upper = min(len(ordered) - 1, lower + 1)
    fraction = position - lower
    return ordered[lower] + (ordered[upper] - ordered[lower]) * fraction


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else ["empty"])
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    parser.add_argument("--episodes", type=int, default=40)
    parser.add_argument("--steps", type=int, default=32)
    parser.add_argument("--edge-events", type=int, default=120)
    parser.add_argument("--rtts", nargs="+", type=float, default=[0.5, 1.0, 5.0, 20.0])
    parser.add_argument("--deadline-ms", type=float, default=5.0)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    prompt_rows: list[dict[str, object]] = []
    action_rows: list[dict[str, object]] = []
    edge_rows: list[dict[str, object]] = []
    started = time.time()
    for seed in args.seeds:
        prompt_part, action_part = prompt_state_run(seed, args.episodes, args.steps)
        prompt_rows.extend(prompt_part)
        action_rows.extend(action_part)
        edge_rows.extend(edge_run(seed, args.edge_events, args.rtts, args.deadline_ms))
    write_csv(args.out / "prompt_state_metrics.csv", prompt_rows)
    write_csv(args.out / "prompt_state_action_samples.csv", action_rows)
    write_csv(args.out / "edge_event_metrics.csv", edge_rows)
    summary_rows: list[dict[str, object]] = []
    for deployment in ("edge_local", "cloud_proxy"):
        for rtt in args.rtts:
            selected = [row for row in edge_rows if row["deployment"] == deployment and float(row["rtt_ms"]) == rtt]
            latencies = [float(row["e2e_latency_ms"]) for row in selected]
            summary_rows.append({"deployment": deployment, "rtt_ms": rtt, "events": len(selected), "latency_mean_ms": mean(latencies), "latency_p50_ms": percentile(latencies, 0.5), "latency_p95_ms": percentile(latencies, 0.95), "compute_mean_ms": mean([float(row["compute_ms"]) for row in selected]), "network_delay_ms": mean([float(row["network_delay_ms_injected"]) for row in selected]), "wire_bytes": mean([float(row["total_wire_bytes"]) for row in selected]), "throughput_mean_events_s": mean([float(row["throughput_events_per_s"]) for row in selected]), "deadline_miss_rate": mean([float(row["deadline_miss"]) for row in selected]), "rss_peak_mb": max(float(row["rss_mb"]) for row in selected)})
    write_csv(args.out / "edge_latency_summary.csv", summary_rows)
    manifest = {"script": Path(__file__).name, "model_name": "TinyPromptPolicy-stdlib-v1 (offline deterministic surrogate)", "description": "Dependency-free deterministic surrogate; not a pretrained LLM.", "seeds": args.seeds, "episodes": args.episodes, "steps": args.steps, "edge_events_per_seed": args.edge_events, "rtts_ms": args.rtts, "deadline_ms": args.deadline_ms, "python": sys.version, "platform": platform.platform(), "elapsed_s": time.time() - started, "compatibility_mode": "stdlib_no_numpy_pandas"}
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
