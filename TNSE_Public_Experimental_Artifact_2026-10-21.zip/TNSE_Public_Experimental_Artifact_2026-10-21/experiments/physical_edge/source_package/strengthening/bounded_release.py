#!/usr/bin/env python3
"""A small fixed-slot, bounded release kernel for the strengthening archive.

This module deliberately exposes only the mechanism output from ``step``.  The
raw disposition, clipping decisions, and cover count stay in diagnostics so
they cannot accidentally become part of the public trace.  A real gateway
failure is handled by :meth:`Session.halt_from_public_signal`, which is a
public exogenous halt and never submits a synthetic order.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Mapping

import numpy as np


LABELS = ("order", "no-order", "reject", "budget-exhausted", "audit-failure")
PUBLIC_FIELDS = (
    "status",
    "signed_qty",
    "timing_offset",
    "delay",
    "eps_after",
    "delta_after",
    "release_count",
)


class PublicHaltActive(RuntimeError):
    """Raised after an externally observable gateway halt has been latched."""


@dataclass(frozen=True)
class Config:
    """Mechanism parameters.

    ``eps_scale`` is intentionally explicit because the validation archive
    reports the three requested settings (0.5, 1.0, and 2.0).  The privacy
    accounting is calculated from the scale rather than from observed output.
    """

    slots: int = 8
    max_orders: int = 4
    eps_scale: float = 1.0
    delta: float = 1e-5
    delta_t: float = 4.0
    delta_q: float = 4.0
    delta_d: float = 3.0
    qty_cap: float = 2.0
    qty_floor: float = 0.15
    time_cap: float = 10.0

    def __post_init__(self) -> None:
        if self.slots <= 0 or self.max_orders < 0:
            raise ValueError("slots must be positive and max_orders non-negative")
        if not math.isfinite(self.eps_scale) or self.eps_scale <= 0:
            raise ValueError("eps_scale must be a positive finite number")
        for name in ("delta", "delta_t", "delta_q", "delta_d", "qty_cap", "qty_floor", "time_cap"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be positive and finite")
        if self.qty_floor > self.qty_cap:
            raise ValueError("qty_floor cannot exceed qty_cap")

    @property
    def eps_order(self) -> float:
        return 0.25 * self.eps_scale

    @property
    def eps_time(self) -> float:
        return 0.45 * self.eps_scale

    @property
    def eps_qty(self) -> float:
        return 0.70 * self.eps_scale

    @property
    def eps_delay(self) -> float:
        return 0.35 * self.eps_scale

    @property
    def eps_coordinate_sum(self) -> float:
        return self.eps_time + self.eps_qty + self.eps_delay

    @property
    def epsilon_cap(self) -> float:
        return self.slots * self.eps_order + self.max_orders * self.eps_coordinate_sum

    @property
    def delta_cap(self) -> float:
        return self.max_orders * self.delta


def randomized_response_probabilities(status: str, epsilon: float) -> dict[str, float]:
    """Return the exact five-way probability vector for one true status."""

    if status not in LABELS:
        raise ValueError(f"unknown status: {status!r}")
    exp_eps = math.exp(float(epsilon))
    denominator = exp_eps + len(LABELS) - 1.0
    probabilities = {label: 1.0 / denominator for label in LABELS}
    probabilities[status] = exp_eps / denominator
    return probabilities


def randomized_response(status: str, rng: np.random.Generator, epsilon: float) -> str:
    """Sample the five-way randomized response channel.

    The true/other probability ratio is exactly ``exp(epsilon)`` before
    sampling.  A caller may pass a status from any of the five public cells;
    no private label is included in the returned value.
    """

    probabilities = randomized_response_probabilities(status, epsilon)
    return LABELS[int(rng.choice(len(LABELS), p=[probabilities[label] for label in LABELS]))]


def _number(action: Mapping[str, Any], key: str) -> float:
    value = action.get(key)
    if isinstance(value, bool) or value is None:
        raise ValueError(f"raw_action[{key!r}] must be a finite number")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"raw_action[{key!r}] must be a finite number")
    return result


class Session:
    """Stateful scheduled release mechanism with a public fixed-slot schema."""

    def __init__(self, config: Config | None = None, seed: int = 0):
        self.config = config or Config()
        self.seed = int(seed)
        self.rng = np.random.default_rng(self.seed)
        self._next_slot = 0
        self._eps = 0.0
        self._delta = 0.0
        self._releases = 0
        self._halted = False
        self._halt_receipt: dict[str, Any] | None = None
        self._cover_releases = 0
        self._projected_releases = 0
        self._records: list[dict[str, Any]] = []

    @property
    def diagnostics(self) -> dict[str, Any]:
        """Private audit counters; never included in ``step`` output."""

        return {
            "cover_release_count": self._cover_releases,
            "projected_release_count": self._projected_releases,
            "release_count": self._releases,
            "eps_after": self._eps,
            "delta_after": self._delta,
            "halted": self._halted,
            "next_slot": self._next_slot,
        }

    @property
    def halt_receipt(self) -> dict[str, Any] | None:
        return None if self._halt_receipt is None else dict(self._halt_receipt)

    def halt_from_public_signal(self, slot: int, reason: str = "gateway-unavailable") -> dict[str, Any]:
        """Latch a halt driven by a public, exogenous gateway signal.

        The method does not inspect the raw disposition or spend privacy
        budget.  It returns a public halt receipt and subsequent ``step`` calls
        raise ``PublicHaltActive``.  This path cannot be used to manufacture a
        cover order when the gateway is unavailable.
        """

        slot = int(slot)
        if slot < 0:
            raise ValueError("halt slot must be non-negative")
        if not isinstance(reason, str) or not reason:
            raise ValueError("halt reason must be a non-empty public string")
        if self._halted:
            return dict(self._halt_receipt or {})
        self._halted = True
        self._halt_receipt = {
            "event": "public-halt",
            "slot": slot,
            "reason": reason,
            "orders_submitted": 0,
        }
        return dict(self._halt_receipt)

    # Alias makes the intended boundary obvious to callers integrating a
    # gateway adapter while keeping one implementation and one receipt type.
    public_halt = halt_from_public_signal

    def _empty_public(self, status: str) -> dict[str, Any]:
        return {
            "status": status,
            "signed_qty": 0.0,
            "timing_offset": 0.0,
            "delay": 0.0,
            "eps_after": float(self._eps),
            "delta_after": float(self._delta),
            "release_count": int(self._releases),
        }

    def step(
        self,
        raw_status: str,
        raw_action: Mapping[str, Any] | None = None,
        slot: int | None = None,
    ) -> dict[str, Any]:
        """Release one scheduled slot and return only public mechanism fields."""

        if self._halted:
            raise PublicHaltActive("public gateway halt is active; no release is emitted")
        if raw_status not in LABELS:
            raise ValueError(f"unknown raw_status: {raw_status!r}")
        expected_slot = self._next_slot
        actual_slot = expected_slot if slot is None else int(slot)
        if actual_slot != expected_slot:
            raise ValueError(f"slot must be the next fixed slot {expected_slot}, got {actual_slot}")
        if raw_status == "order" and raw_action is None:
            raise ValueError("raw_action is required for raw_status='order'")
        if raw_status != "order" and raw_action is not None:
            raise ValueError("raw_action must be omitted for a non-order raw status")

        cfg = self.config
        # The fixed schedule always charges the disposition channel.  Since
        # this is the exact slot cap, a normal session cannot exceed it.
        if self._eps + cfg.eps_order > cfg.epsilon_cap + 1e-12:
            self._next_slot += 1
            self._records.append({"raw_status": raw_status, "public_status": "budget-exhausted", "cover": False})
            return self._empty_public("budget-exhausted")
        self._eps += cfg.eps_order
        public_status = randomized_response(raw_status, self.rng, cfg.eps_order)
        final_status = public_status
        cover = False
        projected = False

        if public_status == "order":
            # The release channel is only opened by the already-public order
            # token.  Any non-order raw status uses the cell centre as a cover.
            cover = raw_status != "order"
            if self._releases >= cfg.max_orders:
                final_status = "budget-exhausted"
            elif self._eps + cfg.eps_coordinate_sum > cfg.epsilon_cap + 1e-12:
                final_status = "budget-exhausted"
            elif self._delta + cfg.delta > cfg.delta_cap + 1e-12:
                final_status = "budget-exhausted"
            else:
                if cover:
                    raw_qty = raw_time = raw_delay = 0.0
                else:
                    assert raw_action is not None
                    raw_qty = _number(raw_action, "signed_qty")
                    raw_time = _number(raw_action, "timing_offset")
                    raw_delay = _number(raw_action, "delay")

                bounded_qty = float(np.clip(raw_qty, -cfg.qty_cap, cfg.qty_cap))
                bounded_time = float(np.clip(raw_time, 0.0, cfg.time_cap))
                bounded_delay = float(np.clip(raw_delay, 0.0, cfg.time_cap))
                projected = any(
                    not math.isclose(before, after, rel_tol=0.0, abs_tol=1e-12)
                    for before, after in (
                        (raw_qty, bounded_qty),
                        (raw_time, bounded_time),
                        (raw_delay, bounded_delay),
                    )
                )
                released_time = float(np.clip(
                    bounded_time + self.rng.laplace(0.0, cfg.delta_t / cfg.eps_time),
                    0.0,
                    cfg.time_cap,
                ))
                sigma = cfg.delta_q * math.sqrt(2.0 * math.log(1.25 / cfg.delta)) / cfg.eps_qty
                released_qty = float(self.rng.normal(bounded_qty, sigma))
                released_qty = float(np.clip(released_qty, -cfg.qty_cap, cfg.qty_cap))
                if abs(released_qty) < cfg.qty_floor:
                    released_qty = cfg.qty_floor if released_qty >= 0.0 else -cfg.qty_floor
                released_delay = float(np.clip(
                    bounded_delay + self.rng.laplace(0.0, cfg.delta_d / cfg.eps_delay),
                    0.0,
                    cfg.time_cap,
                ))
                self._eps += cfg.eps_coordinate_sum
                self._delta += cfg.delta
                self._releases += 1
                self._cover_releases += int(cover)
                self._projected_releases += int(projected)
                self._next_slot += 1
                self._records.append({
                    "raw_status": raw_status,
                    "public_status": "order",
                    "cover": cover,
                    "projected": projected,
                })
                return {
                    "status": "order",
                    "signed_qty": released_qty,
                    "timing_offset": released_time,
                    "delay": released_delay,
                    "eps_after": float(self._eps),
                    "delta_after": float(self._delta),
                    "release_count": int(self._releases),
                }

        self._next_slot += 1
        self._records.append({
            "raw_status": raw_status,
            "public_status": final_status,
            "cover": False,
            "projected": False,
        })
        return self._empty_public(final_status)


__all__ = [
    "Config",
    "LABELS",
    "PUBLIC_FIELDS",
    "PublicHaltActive",
    "Session",
    "randomized_response",
    "randomized_response_probabilities",
]
