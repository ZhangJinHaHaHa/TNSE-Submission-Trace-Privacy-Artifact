#!/usr/bin/env python3
"""Local benchmark and fault harness for the bounded release kernel.

The benchmark measures only work performed in this process: kernel release,
canonical JSON serialization, Ed25519 signing and verification, and a mocked
transport.  It does not model venue, network, cloud, or hardware latency.
Public rows contain released values and coarse fault enums; raw actions and
exception text are deliberately never exported.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import resource
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)


MODULE_DIR = Path(__file__).resolve().parent
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

try:
    from bounded_release import Config, Session
except ImportError as error:  # pragma: no cover - gives a useful CLI error
    raise SystemExit("bounded_release.py must be beside edge_fault_benchmark.py") from error


SCENARIOS = (
    "normal",
    "no-order",
    "invalid-proposal",
    "reject",
    "timeout",
    "audit-signing-failure",
    "budget-exhaustion",
)
VALID_ACTION = {"signed_qty": 1.25, "timing_offset": 0.20, "delay": 0.50}
HEARTBEAT_BYTES = b"edge-heartbeat-v1"


def _field(value: Any, name: str) -> Any:
    if isinstance(value, Mapping):
        return value[name]
    return getattr(value, name)


def _result_fields(value: Any) -> Dict[str, Any]:
    names = (
        "status",
        "signed_qty",
        "timing_offset",
        "delay",
        "eps_after",
        "delta_after",
        "release_count",
    )
    return {name: _field(value, name) for name in names}


def _canonical(value: Mapping[str, Any]) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def _rss_bytes() -> int:
    maximum = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    if sys.platform == "darwin":
        return maximum
    return maximum * 1024


def _percentiles(values: Iterable[Optional[float]]) -> Dict[str, Optional[float]]:
    finite = sorted(float(value) for value in values if value is not None and math.isfinite(float(value)))
    if not finite:
        return {"p50": None, "p95": None, "p99": None}

    def quantile(probability: float) -> float:
        position = (len(finite) - 1) * probability
        lower = int(math.floor(position))
        upper = int(math.ceil(position))
        if lower == upper:
            return finite[lower]
        fraction = position - lower
        return finite[lower] + (finite[upper] - finite[lower]) * fraction

    return {key: quantile(probability) for key, probability in (("p50", 0.50), ("p95", 0.95), ("p99", 0.99))}


class AuditSigner:
    """Ephemeral Ed25519 signer with an explicit pre-send verification step."""

    def __init__(self, fail: bool = False) -> None:
        self._key = Ed25519PrivateKey.generate()
        self.fail = fail
        self.public_key = self._key.public_key().public_bytes(
            serialization.Encoding.Raw,
            serialization.PublicFormat.Raw,
        )
        self.key_id = hashlib.sha256(self.public_key).hexdigest()[:16]

    def sign_and_verify(self, payload: bytes) -> tuple[bytes, int]:
        if self.fail:
            raise RuntimeError("injected audit signer failure")
        signature = self._key.sign(payload)
        started = time.perf_counter_ns()
        Ed25519PublicKey.from_public_bytes(self.public_key).verify(signature, payload)
        return signature, time.perf_counter_ns() - started


class MockTransport:
    """A local fault injector; it never sleeps or simulates network RTT."""

    def __init__(self, timeout: bool = False) -> None:
        self.timeout = timeout
        self.send_attempts = 0
        self.sent = 0

    def send(self, payload: bytes) -> int:
        self.send_attempts += 1
        if self.timeout:
            raise TimeoutError("injected local transport timeout")
        self.sent += 1
        return len(payload)


class MockHeartbeatChannel:
    """Independent fixed-slot channel used even when action transport fails."""

    def __init__(self) -> None:
        self.emitted = 0
        self.last_slot = -1

    def emit(self, slot: int) -> int:
        if int(slot) != self.last_slot + 1:
            raise AssertionError("heartbeat slots must be strictly sequential")
        self.last_slot = int(slot)
        self.emitted += 1
        return len(HEARTBEAT_BYTES)


@dataclass
class Event:
    scenario: str
    slot: int
    status: str
    release_authorized: bool
    sign_attempted: bool
    sign_ok: bool
    transport_attempted: bool
    transport_ok: bool
    send_suppressed_reason: str
    heartbeat_emitted: bool
    send_bytes: int
    heartbeat_bytes: int
    release_ns: Optional[int]
    serialize_ns: Optional[int]
    sign_ns: Optional[int]
    verify_ns: Optional[int]
    transport_ns: Optional[int]
    heartbeat_ns: int
    e2e_ns: int
    cpu_ns: int
    released: Dict[str, Any]
    budget_cap: bool

    def public_record(self) -> Dict[str, Any]:
        record = {
            "scenario": self.scenario,
            "slot": self.slot,
            "status": self.status,
            "release_authorized": self.release_authorized,
            "sign_attempted": self.sign_attempted,
            "sign_ok": self.sign_ok,
            "transport_attempted": self.transport_attempted,
            "transport_ok": self.transport_ok,
            "send_suppressed_reason": self.send_suppressed_reason,
            "heartbeat_emitted": self.heartbeat_emitted,
            "send_bytes": self.send_bytes,
            "heartbeat_bytes": self.heartbeat_bytes,
        }
        if self.release_authorized:
            record["released"] = self.released
        return record


def _session(seed: int = 17) -> Session:
    return Session(Config(slots=8, max_orders=4, eps_scale=1.0), seed=seed)


def _make_event(
    scenario: str,
    slot: int,
    raw_status: str,
    raw_action: Optional[Mapping[str, Any]],
    signer: AuditSigner,
    transport: MockTransport,
    seed: int,
    session: Optional[Session] = None,
    heartbeat_channel: Optional[MockHeartbeatChannel] = None,
) -> Event:
    active_session = session or Session(Config(slots=8, max_orders=4, eps_scale=1.0), seed=seed)
    active_heartbeat = heartbeat_channel or MockHeartbeatChannel()
    started = time.perf_counter_ns()
    cpu_started = time.process_time_ns()
    release_started = time.perf_counter_ns()
    result: Optional[Dict[str, Any]] = None
    release_ns: Optional[int] = None
    serialize_ns: Optional[int] = None
    sign_ns: Optional[int] = None
    verify_ns: Optional[int] = None
    transport_ns: Optional[int] = None
    sign_attempted = False
    transport_attempted = False
    budget_cap = False
    sign_ok = False
    transport_ok = False
    send_bytes = 0
    suppressed = ""

    try:
        result = _result_fields(active_session.step(raw_status, raw_action, slot))
    except ValueError:
        # Invalid proposals are rejected before signing; do not mask other
        # implementation failures as a protocol-level rejection.
        result = None
    release_ns = time.perf_counter_ns() - release_started

    if result is None:
        status = "audit-failure" if scenario == "audit-signing-failure" else "reject"
        authorized = False
        suppressed = "invalid_proposal" if scenario == "invalid-proposal" else "release_error"
        released: Dict[str, Any] = {}
    else:
        status = str(result["status"])
        budget_cap = status == "budget-exhausted" and (
            int(result["release_count"]) >= 4
            or float(result["eps_after"]) >= 8.0 - 1e-12
            or float(result["delta_after"]) >= 4e-5 - 1e-12
        )
        authorized = status == "order"
        released = {
            "signed_qty": float(result["signed_qty"]),
            "timing_offset": float(result["timing_offset"]),
            "delay": float(result["delay"]),
        }
        if scenario == "budget-exhaustion" and budget_cap:
            suppressed = "budget_exhausted"
            authorized = False
        elif not authorized:
            suppressed = "status_not_order"
        else:
            public = {
                "certificate": "edge-release-v1",
                "scenario": scenario,
                "slot": slot,
                "status": status,
                "released": released,
                "eps_after": float(result["eps_after"]),
                "delta_after": float(result["delta_after"]),
                "release_count": int(result["release_count"]),
                "key_id": signer.key_id,
            }
            try:
                serialize_started = time.perf_counter_ns()
                payload = _canonical(public)
                unsigned_wire_ns = time.perf_counter_ns() - serialize_started
                serialize_ns = unsigned_wire_ns
                sign_started = time.perf_counter_ns()
                sign_attempted = True
                signature, verify_ns = signer.sign_and_verify(payload)
                sign_ns = time.perf_counter_ns() - sign_started - verify_ns
                signed = dict(public, signature=signature.hex(), signature_alg="Ed25519")
                wire_started = time.perf_counter_ns()
                wire = _canonical(signed)
                serialize_ns += time.perf_counter_ns() - wire_started
                sign_ok = True
                transport_started = time.perf_counter_ns()
                transport_attempted = True
                send_bytes = transport.send(wire)
                transport_ns = time.perf_counter_ns() - transport_started
                transport_ok = True
            except TimeoutError:
                transport_ns = time.perf_counter_ns() - transport_started
                suppressed = "transport_timeout"
            except RuntimeError:
                suppressed = "audit_signing_failure"
    heartbeat_started = time.perf_counter_ns()
    heartbeat_bytes = active_heartbeat.emit(slot)
    heartbeat_ns = time.perf_counter_ns() - heartbeat_started
    if not suppressed and authorized and sign_ok and transport_ok:
        suppressed = ""
    elif not suppressed:
        suppressed = "send_suppressed"
    transport_expected = bool(authorized and sign_ok and transport_ok)
    if transport.sent != int(transport_expected):
        raise AssertionError("pre-send fail-closed invariant violated")
    if heartbeat_channel is None and active_heartbeat.emitted != 1:
        raise AssertionError("fixed-slot heartbeat invariant violated")
    e2e_ns = time.perf_counter_ns() - started
    cpu_ns = time.process_time_ns() - cpu_started
    return Event(
        scenario=scenario,
        slot=slot,
        status=status,
        release_authorized=authorized,
        sign_attempted=sign_attempted,
        sign_ok=sign_ok,
        transport_attempted=transport_attempted,
        transport_ok=transport_ok,
        send_suppressed_reason=suppressed,
        heartbeat_emitted=True,
        send_bytes=send_bytes,
        heartbeat_bytes=heartbeat_bytes,
        release_ns=release_ns,
        serialize_ns=serialize_ns,
        sign_ns=sign_ns,
        verify_ns=verify_ns,
        transport_ns=transport_ns,
        heartbeat_ns=heartbeat_ns,
        e2e_ns=e2e_ns,
        cpu_ns=cpu_ns,
        released=released,
        budget_cap=budget_cap,
    )


def _run_normal(repeats: int, warmup: int) -> List[Event]:
    events: List[Event] = []
    for _ in range(warmup + repeats):
        events.append(_make_event("normal", 0, "order", VALID_ACTION, AuditSigner(), MockTransport(), 3))
    return events[warmup:]


def _run_single_fault(scenario: str, repeats: int, warmup: int) -> List[Event]:
    events: List[Event] = []
    for repeat_index in range(warmup + repeats):
        measured_index = repeat_index - warmup
        if scenario == "budget-exhaustion":
            session_seed = 106
        elif scenario in ("invalid-proposal", "timeout", "audit-signing-failure"):
            session_seed = 3
        elif scenario == "no-order":
            session_seed = 2 if measured_index < 0 or measured_index % 2 == 0 else 3
        else:
            session_seed = 1
        session = _session(session_seed)
        if scenario == "budget-exhaustion":
            exhausted = False
            heartbeat_channel = MockHeartbeatChannel()
            for slot in range(8):
                event = _make_event(
                    scenario,
                    slot,
                    "order",
                    VALID_ACTION,
                    AuditSigner(),
                    MockTransport(),
                    3,
                    session=session,
                    heartbeat_channel=heartbeat_channel,
                )
                events.append(event)
                exhausted = exhausted or event.budget_cap
            if not exhausted:
                raise AssertionError("budget exhaustion was not reached in eight fixed slots")
            if heartbeat_channel.emitted != 8 or heartbeat_channel.last_slot != 7:
                raise AssertionError("budget session heartbeat slots were incomplete")
            continue
        if scenario == "no-order":
            action: Optional[Mapping[str, Any]] = None
            raw_status = "no-order"
        elif scenario == "reject":
            action = None
            raw_status = "reject"
        elif scenario == "invalid-proposal":
            action = {"signed_qty": float("nan")}
            raw_status = "order"
        elif scenario == "timeout":
            action = VALID_ACTION
            raw_status = "order"
        elif scenario == "audit-signing-failure":
            action = VALID_ACTION
            raw_status = "order"
        else:
            raise ValueError(scenario)
        signer = AuditSigner(fail=scenario == "audit-signing-failure")
        transport = MockTransport(timeout=scenario == "timeout")
        events.append(_make_event(scenario, 0, raw_status, action, signer, transport, session_seed))
    return events[warmup * 8:] if scenario == "budget-exhaustion" else events[warmup:]


def _scenario_summary(events: Sequence[Event]) -> Dict[str, Any]:
    counts: Dict[str, int] = {}
    for event in events:
        counts[event.status] = counts.get(event.status, 0) + 1
    return {
        "samples": len(events),
        "status_counts": counts,
        "budget_cap_count": sum(event.budget_cap for event in events),
        "randomized_budget_token_count": sum(event.status == "budget-exhausted" and not event.budget_cap for event in events),
        "send_count": sum(event.transport_ok and event.sign_ok and event.release_authorized for event in events),
        "authorized_release_count": sum(event.release_authorized for event in events),
        "sign_attempt_count": sum(event.sign_attempted for event in events),
        "signed_count": sum(event.sign_ok for event in events),
        "transport_attempt_count": sum(event.transport_attempted for event in events),
        "send_confirmed_count": sum(event.transport_ok for event in events),
        "heartbeat_count": sum(event.heartbeat_emitted for event in events),
        "suppressed_count": sum(bool(event.send_suppressed_reason) for event in events),
        "latency_ms": {
            key: {name: value / 1_000_000 if value is not None else None for name, value in _percentiles(getattr(event, key) for event in events).items()}
            for key in ("release_ns", "serialize_ns", "sign_ns", "verify_ns", "transport_ns", "heartbeat_ns", "e2e_ns", "cpu_ns")
        },
        "bytes": {
            "send": _percentiles(event.send_bytes for event in events),
            "heartbeat": _percentiles(event.heartbeat_bytes for event in events),
        },
    }


def _write_csv(path: Path, events: Sequence[Event]) -> None:
    fields = (
        "scenario",
        "slot",
        "status",
        "release_authorized",
        "sign_attempted",
        "sign_ok",
        "transport_attempted",
        "transport_ok",
        "send_suppressed_reason",
        "heartbeat_emitted",
        "send_bytes",
        "heartbeat_bytes",
        "release_ns",
        "serialize_ns",
        "sign_ns",
        "verify_ns",
        "transport_ns",
        "heartbeat_ns",
        "e2e_ns",
        "cpu_ns",
    )
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for event in events:
            writer.writerow({field: getattr(event, field) for field in fields})


def _sign_samples(path: Path, events: Sequence[Event], signer: AuditSigner) -> Dict[str, Any]:
    entries: List[Dict[str, Any]] = []
    previous = "0" * 64
    for event in events:
        record = dict(event.public_record(), previous_hash=previous, certificate="edge-release-v1", key_id=signer.key_id)
        payload = _canonical(record)
        signature = signer._key.sign(payload).hex()
        entry_hash = hashlib.sha256(previous.encode() + payload + bytes.fromhex(signature)).hexdigest()
        entries.append(dict(record, signature=signature, signature_alg="Ed25519", entry_hash=entry_hash))
        previous = entry_hash
    with path.open("w", encoding="utf-8") as stream:
        for entry in entries:
            stream.write(json.dumps(entry, sort_keys=True, separators=(",", ":")) + "\n")
    public_key = Ed25519PublicKey.from_public_bytes(signer.public_key)
    previous = "0" * 64
    for entry in entries:
        payload_record = {key: value for key, value in entry.items() if key not in ("signature", "signature_alg", "entry_hash")}
        payload = _canonical(payload_record)
        public_key.verify(bytes.fromhex(entry["signature"]), payload)
        expected = hashlib.sha256(previous.encode() + payload + bytes.fromhex(entry["signature"])).hexdigest()
        if expected != entry["entry_hash"] or entry["previous_hash"] != previous:
            raise AssertionError("sample ledger chain verification failed")
        previous = entry["entry_hash"]
    return {"verified": True, "entries": len(entries), "key_id": signer.key_id, "public_key_ed25519": signer.public_key.hex(), "head": previous}


def run(out: Path, normal_repeats: int = 1000, fault_repeats: int = 100, warmup: int = 25) -> Dict[str, Any]:
    before_rss = _rss_bytes()
    before_cpu = time.process_time_ns()
    all_events: List[Event] = []
    all_events.extend(_run_normal(normal_repeats, warmup))
    for scenario in SCENARIOS[1:]:
        all_events.extend(_run_single_fault(scenario, fault_repeats, warmup))
    grouped = {scenario: [event for event in all_events if event.scenario == scenario] for scenario in SCENARIOS}
    if not any(event.sign_attempted for event in grouped["normal"]):
        raise AssertionError("normal path did not reach the Ed25519 signer")
    if not grouped["invalid-proposal"] or any(event.sign_attempted for event in grouped["invalid-proposal"]):
        raise AssertionError("invalid proposal reached signing")
    if fault_repeats >= 2 and (not any(event.release_authorized for event in grouped["no-order"]) or not any(not event.release_authorized for event in grouped["no-order"])):
        raise AssertionError("no-order case did not cover both public no-order and RR cover paths")
    if not any(event.transport_attempted for event in grouped["timeout"]):
        raise AssertionError("timeout path did not reach mocked transport")
    if any(event.transport_ok for event in grouped["timeout"]):
        raise AssertionError("timeout path unexpectedly confirmed a send")
    if not any(event.sign_attempted for event in grouped["audit-signing-failure"]):
        raise AssertionError("audit signing failure path did not reach signer")
    if any(event.sign_ok for event in grouped["audit-signing-failure"]):
        raise AssertionError("audit signing failure unexpectedly signed")
    budget_events = grouped["budget-exhaustion"]
    if not budget_events or not any(event.budget_cap for event in budget_events):
        raise AssertionError("budget exhaustion path was not reached")
    if any(event.budget_cap and (event.sign_attempted or event.transport_attempted) for event in budget_events):
        raise AssertionError("budget-exhausted slot attempted signing or transport")
    for scenario, events in grouped.items():
        if any(not event.heartbeat_emitted for event in events):
            raise AssertionError(f"missing fixed-slot heartbeat in {scenario}")
    after_rss = _rss_bytes()
    after_cpu = time.process_time_ns()
    out.mkdir(parents=True, exist_ok=True)
    _write_csv(out / "edge_fault_metrics.csv", all_events)
    ledger = _sign_samples(out / "edge_fault_signed_sample.jsonl", all_events[: min(12, len(all_events))], AuditSigner())
    summary = {
        "benchmark": "edge_fault_benchmark",
        "benchmark_version": "1.0",
        "kernel_config": {"slots": 8, "max_orders": 4, "eps_scale": 1.0},
        "normal_repeats": normal_repeats,
        "fault_repeats": fault_repeats,
        "warmup_excluded": warmup,
        "scope": "local process only; transport latency is injected software fault timing",
        "normal_path": "raw order with deterministic public order token (seed 3) for a stable pre-send microbenchmark",
        "diagnostic_scope": "scenario and suppression enums are test diagnostics, not deployment or privacy output",
        "sample_ledger_scope": "sanitized benchmark records signed separately from per-event pre-send signatures",
        "budget_status": "budget-exhausted is counted as a cap stop only when the public cap predicate is reached; other tokens remain randomized status cells",
        "heartbeat_channel": "independent local fixed-slot mock callback with sequential slot checks",
        "scenarios": {scenario: _scenario_summary(grouped[scenario]) for scenario in SCENARIOS},
        "process": {"cpu_ms": (after_cpu - before_cpu) / 1_000_000, "rss_peak_delta_bytes": max(0, after_rss - before_rss)},
        "ledger": ledger,
        "invariants": {
            "send_only_after_authorized_sign_and_transport": True,
            "signing_or_timeout_suppresses_send": True,
            "fixed_slot_heartbeat_on_every_event": True,
            "public_rows_exclude_raw_actions_and_exception_text": True,
            "privacy_or_dp_proof": False,
        },
    }
    (out / "edge_fault_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    manifest = {
        "benchmark": "edge_fault_benchmark",
        "benchmark_version": "1.0",
        "kernel_api": "Config(slots,max_orders,eps_scale); Session(config,seed).step(raw_status,raw_action,slot)",
        "normal_repeats": normal_repeats,
        "fault_repeats": fault_repeats,
        "warmup_excluded": warmup,
        "scenarios": list(SCENARIOS),
        "latency_units": "milliseconds in summary, nanoseconds in metrics CSV",
        "rss_units": "bytes; process maximum RSS normalized by operating-system convention",
        "rss_measurement": "ru_maxrss peak increase before versus after the run; zero means no new process peak",
        "transport": "local mocked transport; no network/cloud latency claim",
        "normal_path": "raw order with deterministic public order token (seed 3) for a stable pre-send microbenchmark",
        "heartbeat_channel": "independent local fixed-slot mock callback with sequential slot checks; timing is software-only",
        "diagnostic_scope": "scenario and suppression enums are test diagnostics, not deployment or privacy output",
        "sample_ledger_scope": "sanitized benchmark records signed separately from per-event pre-send signatures",
        "budget_status": "budget-exhausted is counted as a cap stop only when the public cap predicate is reached; other tokens remain randomized status cells",
        "public_schema": ["scenario", "slot", "status", "release_authorized", "sign_ok", "transport_ok", "send_suppressed_reason", "heartbeat_emitted", "bytes", "timings"],
        "excluded_fields": ["raw_action", "exception_text", "private_state", "host_identity", "serial_number"],
    }
    (out / "edge_fault_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    (out / "edge_fault_ledger_verify.json").write_text(json.dumps(ledger, indent=2, sort_keys=True), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=MODULE_DIR / "results")
    parser.add_argument("--normal-repeats", type=int, default=1000)
    parser.add_argument("--fault-repeats", type=int, default=100)
    parser.add_argument("--warmup", type=int, default=25)
    args = parser.parse_args()
    print(json.dumps(run(args.out, args.normal_repeats, args.fault_repeats, args.warmup), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
