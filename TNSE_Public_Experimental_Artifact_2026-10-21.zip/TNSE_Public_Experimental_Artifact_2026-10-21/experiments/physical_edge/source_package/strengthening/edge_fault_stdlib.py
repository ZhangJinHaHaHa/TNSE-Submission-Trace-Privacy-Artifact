#!/usr/bin/env python3
"""Dependency-free fail-closed timing harness for constrained boards."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import time
from pathlib import Path


SCENARIOS = ("normal", "no-order", "invalid-proposal", "reject", "timeout", "audit-signing-failure", "budget-exhaustion")


def token(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def event(scenario: str, slot: int) -> dict[str, object]:
    started = time.perf_counter_ns()
    authorized = scenario == "normal"
    signing_attempted = authorized or scenario == "audit-signing-failure"
    signing_ok = signing_attempted and scenario != "audit-signing-failure"
    transport_attempted = signing_ok
    transport_ok = transport_attempted and scenario != "timeout"
    suppressed = ""
    if scenario == "invalid-proposal":
        suppressed = "invalid_proposal"
    elif scenario == "reject":
        suppressed = "status_not_order"
    elif scenario == "no-order":
        suppressed = "status_not_order"
    elif scenario == "timeout":
        suppressed = "transport_timeout"
    elif scenario == "audit-signing-failure":
        suppressed = "audit_signing_failure"
    elif scenario == "budget-exhaustion":
        suppressed = "budget_exhausted"
    if authorized and signing_ok and transport_ok:
        status = "order"
    elif scenario == "budget-exhaustion":
        status = "budget-exhausted"
    else:
        status = "reject"
    payload = json.dumps({"scenario": scenario, "slot": slot, "status": status}, sort_keys=True).encode("utf-8")
    signature_token = token(payload) if signing_ok else ""
    return {
        "scenario": scenario,
        "slot": slot,
        "status": status,
        "release_authorized": authorized,
        "sign_attempted": signing_attempted,
        "sign_ok": signing_ok,
        "transport_attempted": transport_attempted,
        "transport_ok": transport_ok,
        "send_suppressed_reason": suppressed,
        "heartbeat_emitted": True,
        "send_bytes": len(payload) + len(signature_token) if transport_ok else 0,
        "heartbeat_bytes": 17,
        "e2e_ns": time.perf_counter_ns() - started,
        "signature_alg": "SHA256-test-token-no-Ed25519",
    }


def run(output: Path, normal_repeats: int, fault_repeats: int) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    for _ in range(normal_repeats):
        rows.append(event("normal", 0))
    for scenario in SCENARIOS[1:]:
        repeats = 8 if scenario == "budget-exhaustion" else fault_repeats
        for repeat in range(repeats):
            rows.append(event(scenario, repeat % 8))
    output.mkdir(parents=True, exist_ok=True)
    fields = ["scenario", "slot", "status", "release_authorized", "sign_attempted", "sign_ok", "transport_attempted", "transport_ok", "send_suppressed_reason", "heartbeat_emitted", "send_bytes", "heartbeat_bytes", "e2e_ns", "signature_alg"]
    with (output / "edge_fault_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows({field: row[field] for field in fields} for row in rows)
    samples = rows[:12]
    with (output / "edge_fault_signed_sample.jsonl").open("w", encoding="utf-8") as handle:
        for row in samples:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
    summary = {"benchmark": "edge_fault_stdlib", "compatibility_mode": "stdlib_no_cryptography", "normal_repeats": normal_repeats, "fault_repeats": fault_repeats, "scope": "local fail-closed timing harness; SHA256 test token is not an Ed25519 signature", "invariants": {"send_only_after_authorized_sign_and_transport": True, "signing_or_timeout_suppresses_send": True, "fixed_slot_heartbeat_on_every_event": True, "cryptographic_ed25519_evidence": False}, "scenarios": {scenario: {"samples": sum(row["scenario"] == scenario for row in rows), "send_count": sum(row["scenario"] == scenario and row["transport_ok"] for row in rows)} for scenario in SCENARIOS}, "python": platform.python_version()}
    (output / "edge_fault_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    manifest = {"benchmark": "edge_fault_stdlib", "compatibility_mode": "stdlib_no_cryptography", "cryptographic_ed25519_evidence": False, "limitations": ["Use the cryptography-backed edge_fault_benchmark.py when the cryptography package is available.", "This fallback measures fail-closed control flow only and must not be described as Ed25519 evidence."]}
    (output / "edge_fault_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    ledger = {"verified": True, "verification": "SHA256 test tokens only", "entries": len(samples), "cryptographic_ed25519": False}
    (output / "edge_fault_ledger_verify.json").write_text(json.dumps(ledger, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--normal-repeats", type=int, default=1000)
    parser.add_argument("--fault-repeats", type=int, default=100)
    parser.add_argument("--warmup", type=int, default=25)
    args = parser.parse_args()
    print(json.dumps(run(args.out, args.normal_repeats, args.fault_repeats), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
