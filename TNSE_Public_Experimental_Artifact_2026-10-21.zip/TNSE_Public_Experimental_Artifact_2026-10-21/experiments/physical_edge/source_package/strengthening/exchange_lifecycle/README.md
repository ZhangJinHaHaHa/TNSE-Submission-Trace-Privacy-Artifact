> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Deterministic exchange-lifecycle replay

`matching_engine_replay.py` implements a small, single-threaded limit-order
book with price-time priority.  It emits explicit accepted/rejected ACKs,
resting orders, fills, cancellations, and modifications.  A modification is
requeued with a new sequence number, so it loses time priority; fills execute
at the resting maker price.

The input is the 2,000-row public LOBSTER AAPL message replay already included
in the supplement.  Submission rows are replayed as historical source
commands.  Cancellation/deletion rows become source cancel commands.  LOBSTER
execution and halt rows remain observations and are not fed back as client
orders, because the source does not identify an aggressor or provide an ACK
channel.  Every 40th source row can add a labelled synthetic marketable order
when an opposite quote exists, and every 25th source submission can issue a
labelled synthetic modify.  These stress commands exercise lifecycle paths but
are not historical exchange events.

## Reproduction

```bash
python3 matching_engine_replay.py \
  --replay ../lobster_replay_2000/lobster_replay_2000.csv \
  --out results
```

The archived run contains `exchange_lifecycle_events.csv`,
`exchange_lifecycle_summary.json`, and `exchange_lifecycle_manifest.json`.
The run produced 1,740 engine ACKs, 119 fills (2,970 units), 708 accepted
cancel events, and 31 accepted synthetic modify commands.  The result is a
software simulation, not a physical edge appliance, exchange certification,
queue reconstruction, latency measurement, or evidence that the historical
venue produced these ACKs/fills.

Each output row carries a monotonic `venue_sequence` and clamped monotonic
`timestamp`; the original source/synthetic command time is retained as
`input_timestamp`.  The archived trace self-check reports zero ordering or
negative-quantity violations and quantity conservation across 942 accepted
orders (fills + modify reductions + cancels + residual book quantity).

`deterministic_scenarios.py` separately checks same-price FIFO, full and
partial fills, cancel-before-fill idempotence, quantity reduction, price-
changing replace, and duplicate/unknown/invalid rejects.  All five checks pass
in `results/scenarios/scenario_metrics.json`; these are implementation
invariants, not venue-protocol conformance claims.
