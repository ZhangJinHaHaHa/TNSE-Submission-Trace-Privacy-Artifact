#!/usr/bin/env python3
"""Small deterministic checks for matching-engine lifecycle invariants."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from matching_engine_replay import PriceTimeEngine, sha256_file


def fill_rows(engine: PriceTimeEngine) -> list[dict[str, object]]:
    return [event for event in engine.events if event["kind"] == "fill"]


def ack_status(engine: PriceTimeEngine, order_id: str) -> list[str]:
    return [
        str(event["ack_status"])
        for event in engine.events
        if event["kind"] == "ack" and event["order_id"] == order_id
    ]


def run(out_dir: Path) -> dict[str, object]:
    out_dir.mkdir(parents=True, exist_ok=True)
    checks: list[dict[str, object]] = []

    # Resting FIFO + partial fill: B1 is older than B2 at the same price.
    engine = PriceTimeEngine()
    engine.submit(1.0, "B1", "B", 100.0, 10, "scenario")
    engine.submit(2.0, "B2", "B", 100.0, 5, "scenario")
    engine.submit(3.0, "S1", "S", 100.0, 12, "scenario")
    fills = fill_rows(engine)
    fifo_ok = [row["maker_order_id"] for row in fills] == ["B1", "B2"] and [
        row["quantity"] for row in fills
    ] == [10, 2]
    checks.append({"name": "same_price_fifo_partial_fill", "passed": fifo_ok})

    # Cancel-before-fill and terminal idempotence.
    engine = PriceTimeEngine()
    engine.submit(1.0, "B3", "B", 99.0, 4, "scenario")
    engine.cancel(2.0, "B3", "scenario", "cancel_before_fill")
    engine.cancel(3.0, "B3", "scenario", "terminal_repeat")
    engine.submit(4.0, "S3", "S", 99.0, 4, "scenario")
    cancel_acks = [
        event["ack_status"]
        for event in engine.events
        if event["kind"] == "ack"
        and event["order_id"] == "B3"
        and str(event["message"]).startswith("cancel")
    ]
    cancel_ok = not fill_rows(engine) and cancel_acks == ["accepted", "rejected"]
    checks.append({"name": "cancel_before_fill_idempotence", "passed": cancel_ok})

    # Quantity reduction keeps the price but requeues with a fresh priority.
    engine = PriceTimeEngine()
    engine.submit(1.0, "B4", "B", 98.0, 7, "scenario")
    engine.modify(2.0, "B4", "scenario", 3)
    engine.submit(3.0, "S4", "S", 98.0, 3, "scenario")
    modify_down_ok = len(fill_rows(engine)) == 1 and fill_rows(engine)[0]["quantity"] == 3
    checks.append({"name": "modify_down_then_fill", "passed": modify_down_ok})

    # Price-changing replace crosses the resting ask and fills at maker price.
    engine = PriceTimeEngine()
    engine.submit(1.0, "S5", "S", 96.0, 2, "scenario")
    engine.submit(2.0, "B5", "B", 95.0, 2, "scenario")
    engine.modify(3.0, "B5", "scenario", 2, new_price=97.0)
    modify_cross_fills = fill_rows(engine)
    modify_cross_ok = len(modify_cross_fills) == 1 and modify_cross_fills[0]["price"] == 96.0
    checks.append({"name": "modify_crosses_at_maker_price", "passed": modify_cross_ok})

    # Duplicate, unknown, and invalid requests are rejected without phantom fills.
    engine = PriceTimeEngine()
    engine.submit(1.0, "B6", "B", 95.0, 1, "scenario")
    engine.submit(2.0, "B6", "B", 95.0, 1, "scenario")
    engine.submit(3.0, "bad", "B", 95.0, 0, "scenario")
    engine.cancel(4.0, "unknown", "scenario", "unknown")
    engine.modify(5.0, "unknown", "scenario", 1)
    reject_count = sum(1 for event in engine.events if event["kind"] == "ack" and event["ack_status"] == "rejected")
    rejects_ok = reject_count == 4 and not fill_rows(engine)
    checks.append({"name": "invalid_duplicate_unknown_rejects", "passed": rejects_ok})

    events = []
    for engine_event in engine.events:
        events.append({key: value for key, value in engine_event.items()})
    event_path = out_dir / "scenario_events.jsonl"
    event_path.write_text("\n".join(json.dumps(row, sort_keys=True) for row in events) + "\n")

    passed = all(bool(check["passed"]) for check in checks)
    metrics = {
        "passed": passed,
        "checks": checks,
        "check_count": len(checks),
        "passed_count": sum(bool(check["passed"]) for check in checks),
        "scope": "deterministic unit scenarios for the local matching-engine implementation; not a venue conformance test",
    }
    (out_dir / "scenario_metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    manifest = {
        "script": "deterministic_scenarios.py",
        "script_sha256": sha256_file(Path(__file__)),
        "event_sha256": sha256_file(event_path),
        "metrics_sha256": sha256_file(out_dir / "scenario_metrics.json"),
        "checks": [check["name"] for check in checks],
        "limitations": [
            "Scenarios verify local ACK causality, FIFO, cancellation, replacement, and reject behavior only.",
            "They do not establish exchange-specific protocol, network latency, or physical-edge performance.",
        ],
    }
    (out_dir / "scenario_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    if not passed:
        raise SystemExit("deterministic scenario check failed")
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.out), indent=2))


if __name__ == "__main__":
    main()
