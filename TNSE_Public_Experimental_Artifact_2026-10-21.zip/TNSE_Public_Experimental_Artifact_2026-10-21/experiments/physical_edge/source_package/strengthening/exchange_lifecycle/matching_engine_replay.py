#!/usr/bin/env python3
"""Run a deterministic price-time-priority exchange lifecycle replay.

The LOBSTER file supplies observable submissions/cancellations/deletions.  It
does not contain client acknowledgements, aggressor identifiers, queue
position, or venue timing.  Consequently the engine is an explicit local
simulation: source messages are replayed as commands, while a small,
deterministic synthetic stress stream creates marketable orders and modifies.
Synthetic commands are labelled in every output row and are not presented as
historical exchange events.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import heapq
import json
import platform
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


EVENT_NAMES = {
    1: "submission",
    2: "partial_cancellation",
    3: "deletion",
    4: "visible_execution_observation",
    5: "hidden_execution_observation",
    6: "cross_trade_observation",
    7: "trading_halt_observation",
}
SIDES = {1: "B", -1: "S"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclass
class Order:
    order_id: str
    side: str
    price: float
    quantity: int
    remaining: int
    sequence: int
    origin: str
    timestamp: float


class PriceTimeEngine:
    """Minimal deterministic limit-order book with ACKs, fills and cancels."""

    def __init__(self) -> None:
        self.orders: dict[str, Order] = {}
        self._bids: list[tuple[float, int, str]] = []
        self._asks: list[tuple[float, int, str]] = []
        self.sequence = 0
        self.execution_id = 0
        self.venue_sequence = 0
        self.last_timestamp = float("-inf")
        self.events: list[dict[str, object]] = []

    def _next_sequence(self) -> int:
        self.sequence += 1
        return self.sequence

    def _push(self, order: Order) -> None:
        if order.side == "B":
            heapq.heappush(self._bids, (-order.price, order.sequence, order.order_id))
        else:
            heapq.heappush(self._asks, (order.price, order.sequence, order.order_id))

    def _clean(self) -> None:
        while self._bids and (
            self._bids[0][2] not in self.orders
            or self.orders[self._bids[0][2]].remaining <= 0
            or self.orders[self._bids[0][2]].side != "B"
            or self.orders[self._bids[0][2]].sequence != self._bids[0][1]
        ):
            heapq.heappop(self._bids)
        while self._asks and (
            self._asks[0][2] not in self.orders
            or self.orders[self._asks[0][2]].remaining <= 0
            or self.orders[self._asks[0][2]].side != "S"
            or self.orders[self._asks[0][2]].sequence != self._asks[0][1]
        ):
            heapq.heappop(self._asks)

    def best_bid(self) -> float | None:
        self._clean()
        return None if not self._bids else -self._bids[0][0]

    def best_ask(self) -> float | None:
        self._clean()
        return None if not self._asks else self._asks[0][0]

    def _emit(self, timestamp: float, kind: str, origin: str, **values: object) -> None:
        self.venue_sequence += 1
        input_timestamp = float(timestamp)
        venue_timestamp = max(input_timestamp, self.last_timestamp)
        self.last_timestamp = venue_timestamp
        row: dict[str, object] = {
            "venue_sequence": self.venue_sequence,
            "timestamp": venue_timestamp,
            "input_timestamp": input_timestamp,
            "kind": kind,
            "origin": origin,
            "ack_status": "",
            "order_id": "",
            "side": "",
            "price": "",
            "quantity": "",
            "remaining": "",
            "maker_order_id": "",
            "taker_order_id": "",
            "execution_id": "",
            "message": "",
        }
        row.update(values)
        self.events.append(row)

    def _ack(
        self,
        timestamp: float,
        origin: str,
        order_id: str,
        status: str,
        message: str,
        quantity: int | None = None,
        remaining: int | None = None,
    ) -> None:
        self._emit(
            timestamp,
            "ack",
            origin,
            ack_status=status,
            order_id=order_id,
            quantity="" if quantity is None else quantity,
            remaining="" if remaining is None else remaining,
            message=message,
        )

    def submit(
        self,
        timestamp: float,
        order_id: str,
        side: str,
        price: float,
        quantity: int,
        origin: str,
    ) -> None:
        if order_id in self.orders or side not in {"B", "S"} or quantity <= 0 or price <= 0:
            self._ack(timestamp, origin, order_id, "rejected", "invalid_or_duplicate_submission")
            return
        order = Order(
            order_id=order_id,
            side=side,
            price=round(price, 4),
            quantity=int(quantity),
            remaining=int(quantity),
            sequence=self._next_sequence(),
            origin=origin,
            timestamp=timestamp,
        )
        self.orders[order_id] = order
        self._ack(timestamp, origin, order_id, "accepted", "new_order", quantity, quantity)
        self._match(timestamp, order)
        if order.remaining > 0:
            self._push(order)
            self._emit(
                timestamp,
                "resting",
                origin,
                order_id=order_id,
                side=side,
                price=order.price,
                quantity=order.quantity,
                remaining=order.remaining,
            )

    def _match(self, timestamp: float, taker: Order) -> None:
        while taker.remaining > 0:
            self._clean()
            if taker.side == "B":
                if not self._asks or self._asks[0][0] > taker.price:
                    break
                maker_id = self._asks[0][2]
                maker = self.orders[maker_id]
                trade_price = maker.price
            else:
                if not self._bids or -self._bids[0][0] < taker.price:
                    break
                maker_id = self._bids[0][2]
                maker = self.orders[maker_id]
                trade_price = maker.price
            fill_size = min(taker.remaining, maker.remaining)
            taker.remaining -= fill_size
            maker.remaining -= fill_size
            self.execution_id += 1
            execution_id = f"exec-{self.execution_id:06d}"
            self._emit(
                timestamp,
                "fill",
                taker.origin,
                order_id=taker.order_id,
                side=taker.side,
                price=trade_price,
                quantity=fill_size,
                remaining=taker.remaining,
                maker_order_id=maker.order_id,
                taker_order_id=taker.order_id,
                execution_id=execution_id,
            )
            if maker.remaining == 0:
                del self.orders[maker.order_id]
        if taker.remaining == 0:
            self.orders.pop(taker.order_id, None)

    def cancel(self, timestamp: float, order_id: str, origin: str, reason: str) -> None:
        order = self.orders.pop(order_id, None)
        if order is None:
            self._ack(timestamp, origin, order_id, "rejected", f"cancel_not_found:{reason}")
            return
        self._ack(timestamp, origin, order_id, "accepted", f"cancel:{reason}")
        self._emit(
            timestamp,
            "cancel",
            origin,
            order_id=order_id,
            side=order.side,
            price=order.price,
            quantity=order.quantity,
            remaining=order.remaining,
        )

    def modify(
        self,
        timestamp: float,
        order_id: str,
        origin: str,
        new_quantity: int,
        new_price: float | None = None,
    ) -> None:
        order = self.orders.pop(order_id, None)
        if order is None:
            self._ack(timestamp, origin, order_id, "rejected", "modify_not_found")
            return
        if new_quantity <= 0 or (new_price is not None and new_price <= 0):
            self._ack(timestamp, origin, order_id, "rejected", "modify_invalid_quantity_or_price")
            self.orders[order_id] = order
            return
        old_price, old_remaining = order.price, order.remaining
        order.price = round(order.price if new_price is None else new_price, 4)
        order.quantity = max(order.quantity, new_quantity)
        order.remaining = min(old_remaining, int(new_quantity))
        order.sequence = self._next_sequence()  # modification loses time priority
        self._ack(timestamp, origin, order_id, "accepted", "modify_requeued")
        self._emit(
            timestamp,
            "modify",
            origin,
            order_id=order_id,
            side=order.side,
            price=order.price,
            quantity=order.quantity,
            remaining=order.remaining,
            message=f"old_price={old_price:.4f};old_remaining={old_remaining}",
        )
        self.orders[order_id] = order
        self._match(timestamp, order)
        if order.remaining > 0:
            self._push(order)
            self._emit(
                timestamp,
                "resting",
                origin,
                order_id=order_id,
                side=order.side,
                price=order.price,
                quantity=order.quantity,
                remaining=order.remaining,
            )

    def book_depth(self) -> tuple[int, int]:
        self._clean()
        bid = sum(order.remaining for order in self.orders.values() if order.side == "B")
        ask = sum(order.remaining for order in self.orders.values() if order.side == "S")
        return bid, ask


def read_rows(path: Path) -> Iterable[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        yield from csv.DictReader(stream)


def validate_trace(events: list[dict[str, object]]) -> dict[str, object]:
    """Check causal ACK ordering, nonnegative quantities, and terminality."""
    sequences = [int(event["venue_sequence"]) for event in events]
    timestamps = [float(event["timestamp"]) for event in events]
    accepted_ack: dict[str, int] = {}
    terminal: dict[str, int] = {}
    violations: list[str] = []
    for event in events:
        sequence = int(event["venue_sequence"])
        order_id = str(event.get("order_id", ""))
        kind = str(event["kind"])
        status = str(event.get("ack_status", ""))
        if kind == "ack" and status == "accepted":
            accepted_ack.setdefault(order_id, sequence)
        if kind in {"resting", "fill", "modify"} and order_id and order_id not in accepted_ack:
            violations.append(f"{kind}_before_ack:{order_id}")
        if kind == "cancel" and order_id:
            terminal[order_id] = sequence
        if kind == "fill":
            quantity = int(event["quantity"])
            if quantity < 0 or int(event["remaining"]) < 0:
                violations.append(f"negative_fill_quantity:{order_id}")
            for participant in (order_id, str(event.get("maker_order_id", ""))):
                if participant in terminal and sequence > terminal[participant]:
                    violations.append(f"fill_after_cancel:{participant}")
        elif event.get("remaining", "") not in {"", None} and int(event["remaining"]) < 0:
            violations.append(f"negative_remaining:{order_id}")
    timestamp_monotonic = all(
        timestamps[index] >= timestamps[index - 1]
        for index in range(1, len(timestamps))
    )
    if not timestamp_monotonic:
        violations.append("venue_timestamp_not_monotonic")
    return {
        "passed": not violations and sequences == list(range(1, len(events) + 1)),
        "event_sequence_monotonic": sequences == list(range(1, len(events) + 1)),
        "venue_timestamp_monotonic": timestamp_monotonic,
        "violation_count": len(violations),
        "violations": violations[:20],
    }


def validate_quantity_conservation(
    events: list[dict[str, object]],
    open_orders: dict[str, Order],
) -> dict[str, object]:
    """Reconcile each accepted order across fills, reductions, cancels, and residuals."""
    initial: dict[str, int] = {}
    current: dict[str, int] = {}
    filled: Counter[str] = Counter()
    reduced: Counter[str] = Counter()
    cancelled: Counter[str] = Counter()
    for event in events:
        order_id = str(event.get("order_id", ""))
        kind = str(event["kind"])
        if kind == "ack" and event.get("ack_status") == "accepted" and event.get("message") == "new_order":
            initial[order_id] = int(event["quantity"])
            current[order_id] = int(event["remaining"])
        elif kind == "fill":
            quantity = int(event["quantity"])
            taker = str(event.get("taker_order_id", ""))
            maker = str(event.get("maker_order_id", ""))
            for participant in {taker, maker}:
                if participant in current:
                    current[participant] -= quantity
                    filled[participant] += quantity
        elif kind == "modify" and order_id in current:
            new_remaining = int(event["remaining"])
            reduction = max(0, current[order_id] - new_remaining)
            reduced[order_id] += reduction
            current[order_id] = new_remaining
        elif kind == "cancel" and order_id in current:
            cancelled[order_id] += current[order_id]
            current[order_id] = 0
    mismatches: list[dict[str, object]] = []
    for order_id, quantity in initial.items():
        residual = open_orders[order_id].remaining if order_id in open_orders else 0
        accounted = filled[order_id] + reduced[order_id] + cancelled[order_id] + residual
        if accounted != quantity:
            mismatches.append({
                "order_id": order_id,
                "initial": quantity,
                "filled": filled[order_id],
                "reduced": reduced[order_id],
                "cancelled": cancelled[order_id],
                "residual": residual,
                "accounted": accounted,
            })
    return {
        "passed": not mismatches,
        "checked_orders": len(initial),
        "mismatch_count": len(mismatches),
        "mismatches": mismatches[:20],
    }


def run(replay: Path, out_dir: Path, stress_stride: int = 40, modify_stride: int = 25) -> dict[str, object]:
    out_dir.mkdir(parents=True, exist_ok=True)
    engine = PriceTimeEngine()
    source_counts: Counter[str] = Counter()
    command_counts: Counter[str] = Counter()
    source_rows = 0
    synthetic_stress = 0
    synthetic_modifies = 0

    for row_index, row in enumerate(read_rows(replay)):
        source_rows += 1
        timestamp = float(row["timestamp"])
        event_type = int(row["event_type"])
        source_counts[EVENT_NAMES.get(event_type, f"unknown_{event_type}")] += 1
        order_id = f"src-{row['order_id']}"
        side = SIDES.get(int(row["event_direction"]))
        price = float(row["event_price"])
        quantity = int(row["event_size"])

        if event_type == 1 and side is not None:
            engine.submit(timestamp, order_id, side, price, quantity, "historical_submission")
            command_counts["historical_submit"] += 1
            # A deterministic, explicitly synthetic marketable order exercises
            # FIFO matching when the opposite side is present.
            if row_index % stress_stride == 0:
                opposite = engine.best_ask() if side == "B" else engine.best_bid()
                if opposite is not None:
                    stress_side = "B" if side == "S" else "S"
                    stress_id = f"syn-stress-{row_index:06d}"
                    engine.submit(
                        timestamp + 1e-9,
                        stress_id,
                        stress_side,
                        opposite,
                        max(1, min(quantity, 5)),
                        "synthetic_stress",
                    )
                    synthetic_stress += 1
                    command_counts["synthetic_stress_submit"] += 1
            if row_index % modify_stride == 0 and order_id in engine.orders:
                current = engine.orders[order_id]
                engine.modify(
                    timestamp + 2e-9,
                    order_id,
                    "synthetic_modify",
                    max(1, current.remaining // 2),
                )
                synthetic_modifies += 1
                command_counts["synthetic_modify"] += 1
        elif event_type in {2, 3}:
            # A partial cancellation/deletion is an observable source intent;
            # the local exchange maps both to a cancel command because the
            # source has no client request/ACK channel for partial reduction.
            engine.cancel(timestamp, order_id, "historical_cancel", EVENT_NAMES[event_type])
            command_counts["historical_cancel"] += 1
        else:
            # Execution and halt rows are retained as observations only.  They
            # are not fed back into the simulated book.
            engine._emit(
                timestamp,
                "source_observation",
                "historical_observation",
                order_id=order_id,
                side=side or "",
                price=price,
                quantity=quantity,
                message=EVENT_NAMES.get(event_type, f"unknown_{event_type}"),
            )
            command_counts["historical_observation"] += 1

    event_path = out_dir / "exchange_lifecycle_events.csv"
    fields = [
        "venue_sequence", "timestamp", "input_timestamp", "kind", "origin", "ack_status", "order_id", "side", "price",
        "quantity", "remaining", "maker_order_id", "taker_order_id", "execution_id", "message",
    ]
    with event_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(engine.events)

    kinds = Counter(str(event["kind"]) for event in engine.events)
    statuses = Counter(str(event["ack_status"]) for event in engine.events if event["kind"] == "ack")
    fill_sizes = [int(event["quantity"]) for event in engine.events if event["kind"] == "fill"]
    trace_validation = validate_trace(engine.events)
    quantity_conservation = validate_quantity_conservation(engine.events, engine.orders)
    summary = {
        "source_rows": source_rows,
        "source_event_counts": dict(sorted(source_counts.items())),
        "command_counts": dict(sorted(command_counts.items())),
        "synthetic_stress_submissions": synthetic_stress,
        "synthetic_modify_commands": synthetic_modifies,
        "engine_event_counts": dict(sorted(kinds.items())),
        "ack_status_counts": dict(sorted(statuses.items())),
        "fills": len(fill_sizes),
        "filled_quantity": sum(fill_sizes),
        "mean_fill_quantity": (sum(fill_sizes) / len(fill_sizes)) if fill_sizes else 0.0,
        "open_orders_at_end": len(engine.orders),
        "book_depth_at_end": {"bid_quantity": engine.book_depth()[0], "ask_quantity": engine.book_depth()[1]},
        "trace_validation": trace_validation,
        "quantity_conservation": quantity_conservation,
        "price_time_priority": "price first, then monotonically increasing sequence at each price",
        "scope": "deterministic local matching-engine simulation; synthetic stress flow is explicitly labelled; no claim of historical venue matching",
    }
    (out_dir / "exchange_lifecycle_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    manifest = {
        "script": "matching_engine_replay.py",
        "script_sha256": sha256_file(Path(__file__)),
        "replay_file": replay.name,
        "replay_sha256": sha256_file(replay),
        "output_events_sha256": sha256_file(event_path),
        "output_rows": len(engine.events),
        "stress_stride": stress_stride,
        "modify_stride": modify_stride,
        "python": platform.python_version(),
        "algorithm": "single-threaded limit-order book; price-time priority; matching at resting-maker price; cancel and modify ACK paths; deterministic synthetic marketable stress orders",
        "limitations": [
            "LOBSTER execution rows are retained as observations and are not interpreted as client ACKs or aggressor orders.",
            "The source does not provide queue position, order-entry latency, network latency, matching-engine timestamps, or venue ACK semantics.",
            "Synthetic stress orders and modifies exercise lifecycle paths but are not historical orders.",
            "This is software simulation on a general-purpose host, not a physical edge appliance or live exchange deployment.",
        ],
        "summary": summary,
    }
    (out_dir / "exchange_lifecycle_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--stress-stride", type=int, default=40)
    parser.add_argument("--modify-stride", type=int, default=25)
    args = parser.parse_args()
    print(json.dumps(run(args.replay, args.out, args.stress_stride, args.modify_stride), indent=2))


if __name__ == "__main__":
    main()
