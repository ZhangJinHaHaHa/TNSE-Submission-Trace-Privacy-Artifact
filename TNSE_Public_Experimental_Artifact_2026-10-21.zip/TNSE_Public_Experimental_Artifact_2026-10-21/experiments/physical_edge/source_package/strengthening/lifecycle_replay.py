#!/usr/bin/env python3
"""Summarize observable order-event lifecycles in a LOBSTER replay.

This is deliberately a market-message lifecycle audit.  It does not infer
agent acknowledgements, queue position, venue latency, or fills for orders
that were not present in the source message file.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
from collections import Counter, defaultdict
from pathlib import Path


EVENT_NAMES = {
    1: "submission",
    2: "partial_cancellation",
    3: "deletion",
    4: "visible_execution",
    5: "hidden_execution",
    6: "cross_trade",
    7: "trading_halt",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def summarize(path: Path, output: Path) -> dict[str, object]:
    states: dict[int, str] = {}
    quantities: dict[int, int] = defaultdict(int)
    transitions: Counter[tuple[str, str]] = Counter()
    events: Counter[str] = Counter()
    left_censored: Counter[str] = Counter()
    underflow: Counter[str] = Counter()
    rows: list[dict[str, object]] = []

    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        for index, row in enumerate(reader):
            event_type = int(row["event_type"])
            event_name = EVENT_NAMES.get(event_type, f"unknown_{event_type}")
            order_id = int(row["order_id"])
            previous = states.get(order_id, "absent")
            size = int(row["event_size"])
            if event_type == 1:
                current = "open"
                quantities[order_id] = size
            elif event_type == 2:
                if previous not in {"open", "partial"} or order_id not in quantities:
                    left_censored["partial_cancellation"] += 1
                    current = "left_censored_partial_cancellation"
                    quantities.pop(order_id, None)
                else:
                    if size > quantities[order_id]:
                        underflow["partial_cancellation"] += 1
                    quantities[order_id] = max(0, quantities[order_id] - size)
                    current = "closed" if quantities[order_id] == 0 else "partial"
            elif event_type == 3:
                if previous not in {"open", "partial"} or order_id not in quantities:
                    left_censored["deletion"] += 1
                    current = "left_censored_deletion"
                    quantities.pop(order_id, None)
                else:
                    quantities[order_id] = 0
                    current = "closed"
            elif event_type == 4:
                if previous not in {"open", "partial"} or order_id not in quantities:
                    left_censored["visible_execution"] += 1
                    current = "left_censored_visible_execution"
                    quantities.pop(order_id, None)
                else:
                    if size > quantities[order_id]:
                        underflow["visible_execution"] += 1
                    quantities[order_id] = max(0, quantities[order_id] - size)
                    current = "closed" if quantities[order_id] == 0 else "partial"
            elif event_type in {5, 6}:
                if event_type == 6:
                    current = "cross_trade"
                else:
                    current = "hidden_execution"
            elif event_type == 7:
                current = "halt"
            else:
                current = "unclassified"
            if event_type not in {5, 6, 7}:
                transitions[(previous, current)] += 1
            if event_type not in {5, 6, 7}:
                states[order_id] = current
            events[event_name] += 1
            rows.append({
                "row_index": index,
                "timestamp": row["timestamp"],
                "order_id": order_id,
                "event_type": event_type,
                "event": event_name,
                "previous_state": previous,
                "state": current,
                "remaining_size": quantities.get(order_id),
            })

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]) if rows else ["row_index"])
        writer.writeheader()
        writer.writerows(rows)
    manifest = {
        "replay_file": path.name,
        "replay_sha256": sha256_file(path),
        "rows": len(rows),
        "event_counts": dict(sorted(events.items())),
        "transition_counts": {
            f"{before}->{after}": count
            for (before, after), count in sorted(transitions.items())
        },
        "left_censored_counts": dict(sorted(left_censored.items())),
        "underflow_clamped_counts": dict(sorted(underflow.items())),
        "terminal_state_counts": dict(sorted(Counter(states.values()).items())),
        "scope": "observable LOBSTER message lifecycle only; no agent ACK, queue reconstruction, venue latency, or live-trading claim",
        "python": platform.python_version(),
    }
    output.with_name("lifecycle_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(summarize(args.replay, args.out), indent=2))


if __name__ == "__main__":
    main()
