#!/usr/bin/env python3
"""Small, reproducible experiment using one real local pretrained LLM.

The runner talks only to a local OpenAI-compatible llama.cpp server. It keeps
the experiment deliberately narrow while making the protected-input question
explicit: the same public replay is evaluated with a public-only control, an
explicit user-state condition, and a hidden system-state condition. Raw
completion samples and paired action effects are retained as diagnostics. This
is an empirical checkpoint/interface test, not a claim about all LLMs or a
live venue.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import re
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path
from statistics import mean, quantiles
from typing import Any

import numpy as np

_path = Path(__file__).resolve()
_candidates = [
    _path.parent,
    _path.parents[1],
    _path.parents[1] / "updated" / "experiments" / "TNSE_Revised_Supplement" / "experiments",
    _path.parents[2] / "work" / "updated" / "experiments" / "TNSE_Revised_Supplement" / "experiments",
]
EXPERIMENT_ROOT = next(
    candidate for candidate in _candidates
    if (candidate / "augmented" / "llm_edge_experiment.py").exists()
)
sys.path.insert(0, str(EXPERIMENT_ROOT / "augmented"))
from llm_edge_experiment import (  # noqa: E402
    Action,
    ReleaseConfig,
    aggregate,
    auc_score,
    eti_release,
    make_observation,
)


BASE_SYSTEM_PROMPT = (
    "You are a deterministic trading-action policy. Use both the public LOB "
    "observation and the private risk state. For reproducibility, choose side "
    "1 when private_state[0] is nonnegative and -1 otherwise; choose quantity "
    "between 0.25 and 2.0 from the magnitude of private_state[0]; choose "
    "urgency between 0 and 1 from public_observation[2] (higher imbalance "
    "means higher urgency); choose delay between 0 and 10 inversely from "
    "urgency. Return exactly one JSON object with numeric keys side, quantity, "
    "urgency, and delay. Do not include markdown or extra keys."
)
PUBLIC_ONLY_SYSTEM_PROMPT = (
    "You are a deterministic trading-action policy. Use only the public LOB "
    "observation supplied by the user; do not infer or invent a private state. "
    "Choose side from the public imbalance, quantity between 0.25 and 2.0, "
    "urgency between 0 and 1, and delay between 0 and 10. Return exactly one "
    "JSON object with numeric keys side, quantity, urgency, and delay. Do not "
    "include markdown or extra keys."
)
CONDITIONS = ("public_only", "explicit_user_state", "hidden_system_state")
JSON_SCHEMA = {
    "type": "json_schema",
    "json_schema": {
        "name": "trading_action",
        "schema": {
            "type": "object",
            "properties": {
                "side": {"type": "integer"},
                "quantity": {"type": "number"},
                "urgency": {"type": "number"},
                "delay": {"type": "number"},
            },
            "required": ["side", "quantity", "urgency", "delay"],
            "additionalProperties": False,
        },
    },
}
STATE_PROFILES = {
    0: np.array([-0.65, -0.15, 0.25, 0.10], dtype=float),
    1: np.array([0.65, 0.15, -0.25, -0.10], dtype=float),
}


def sha256_file(path: Path | None) -> str | None:
    if path is None:
        return None
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _json_from_text(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", cleaned, flags=re.I | re.S).strip()
    try:
        value = json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        if start < 0:
            raise
        depth = 0
        in_string = False
        escaped = False
        end = None
        for index in range(start, len(cleaned)):
            char = cleaned[index]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    end = index
                    break
        if end is None:
            raise
        value = json.loads(cleaned[start : end + 1])
    if not isinstance(value, dict):
        raise ValueError("model output is not a JSON object")
    return value


def parse_action(text: str) -> tuple[Action | None, str]:
    try:
        obj = _json_from_text(text)
        required = {"side", "quantity", "urgency", "delay"}
        if set(obj) != required:
            return None, "invalid_schema"
        strict_types = (
            isinstance(obj["side"], int)
            and not isinstance(obj["side"], bool)
            and all(
                isinstance(obj[name], (int, float)) and not isinstance(obj[name], bool)
                for name in ("quantity", "urgency", "delay")
            )
        )
        side_value = float(obj["side"])
        quantity = float(obj["quantity"])
        urgency = float(obj["urgency"])
        delay = float(obj["delay"])
        strict = strict_types and text.strip().startswith("{") and text.strip().endswith("}")
        strict = strict and side_value in (-1.0, 1.0) and side_value.is_integer()
        strict = strict and 0.0 <= quantity <= 2.0 and 0.0 <= urgency <= 1.0 and 0.0 <= delay <= 10.0
        side = int(round(side_value))
        if side not in (-1, 1):
            side = 1 if side >= 0 else -1
        if not all(np.isfinite([quantity, urgency, delay])):
            raise ValueError("non-finite action")
        action = Action(
            side=side,
            quantity=float(np.clip(abs(quantity), 0.0, 2.0)),
            urgency=float(np.clip(urgency, 0.0, 1.0)),
            delay=float(np.clip(delay, 0.0, 10.0)),
            confidence=1.0,
        )
        return action, "valid" if strict else "normalized"
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        return None, "invalid"


class LocalChatClient:
    def __init__(self, base_url: str, model: str, timeout: float, temperature: float, allow_json_object_fallback: bool):
        self.url = base_url.rstrip("/") + "/chat/completions"
        self.model = model
        self.timeout = timeout
        self.temperature = temperature
        self.allow_json_object_fallback = allow_json_object_fallback

    def complete(self, user_content: str, seed: int, system_content: str) -> dict[str, Any]:
        body = {
            "model": self.model,
            "temperature": self.temperature,
            "seed": int(seed),
            "max_tokens": 128,
            "stop": ["<|im_end|>", "<|im_start|>"],
            "response_format": JSON_SCHEMA,
            "messages": [
                {"role": "system", "content": system_content},
                {"role": "user", "content": user_content},
            ],
        }
        started = time.perf_counter()
        try:
            request = urllib.request.Request(
                self.url,
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            error_body = error.read().decode("utf-8", errors="replace")
            unsupported_format = "response_format" in error_body and (
                "json_schema" in error_body or "json_object" in error_body
            )
            if not self.allow_json_object_fallback or error.code not in {400, 422, 500} or not unsupported_format:
                raise
            body["response_format"] = {"type": "json_object"}
            request = urllib.request.Request(
                self.url,
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
            payload["_response_format_fallback"] = True
            payload["_response_format_fallback_error"] = {
                "status": error.code,
                "body_sha256": sha256_text(error_body),
            }
        payload["_latency_ms"] = (time.perf_counter() - started) * 1000.0
        return payload


def public_window(seed: int, episode: int, steps: int, replay: np.ndarray | None) -> np.ndarray:
    if replay is None:
        return make_observation(np.random.default_rng(seed * 100_003 + episode * 997), steps)
    start = (seed * 10_000 + episode * steps) % max(1, len(replay) - steps + 1)
    return np.asarray(replay[start : start + steps], dtype=float)


def make_system_prompt(condition: str, state: np.ndarray) -> str:
    if condition == "public_only":
        return PUBLIC_ONLY_SYSTEM_PROMPT
    if condition == "explicit_user_state":
        return BASE_SYSTEM_PROMPT
    if condition == "hidden_system_state":
        private = json.dumps([round(float(x), 6) for x in state], separators=(",", ":"))
        return (
            BASE_SYSTEM_PROMPT
            + "\nThe private risk state is supplied only in this system context and "
            + "must not be repeated in the user-facing response. private_state="
            + private
        )
    raise ValueError(f"unknown condition: {condition}")


def make_user_prompt(observation: np.ndarray, state: np.ndarray, condition: str) -> str:
    payload = {
        "public_observation": [round(float(x), 6) for x in observation],
        "instruction": "Return one bounded action for this slot.",
    }
    if condition == "explicit_user_state":
        payload["private_state"] = [round(float(x), 6) for x in state]
    elif condition not in {"public_only", "hidden_system_state"}:
        raise ValueError(f"unknown condition: {condition}")
    return json.dumps(payload, separators=(",", ":"))


def evaluate_auc(rows: list[dict[str, Any]], feature_key: str, seed: int, condition: str) -> float:
    data = [row for row in rows if row["seed"] == seed and row["condition"] == condition]
    episodes = sorted({row["episode"] for row in data})
    if len(episodes) < 4:
        return float("nan")
    split = max(2, int(len(episodes) * 0.7))
    train_eps = set(episodes[:split])
    x_train = np.asarray([row[feature_key] for row in data if row["episode"] in train_eps])
    y_train = np.asarray([row["membership"] for row in data if row["episode"] in train_eps])
    x_test = np.asarray([row[feature_key] for row in data if row["episode"] not in train_eps])
    y_test = np.asarray([row["membership"] for row in data if row["episode"] not in train_eps])
    if len(np.unique(y_train)) < 2 or len(np.unique(y_test)) < 2:
        return float("nan")
    mu = x_train.mean(axis=0)
    sd = x_train.std(axis=0)
    sd[sd < 1e-8] = 1.0
    x_train = (x_train - mu) / sd
    x_test = (x_test - mu) / sd
    x_train = np.c_[np.ones(len(x_train)), x_train]
    x_test = np.c_[np.ones(len(x_test)), x_test]
    reg = 1e-2 * np.eye(x_train.shape[1])
    reg[0, 0] = 0.0
    weights = np.linalg.solve(x_train.T @ x_train + reg, x_train.T @ y_train)
    return auc_score(y_test, x_test @ weights)


def load_replay(path: Path | None) -> np.ndarray | None:
    if path is None:
        return None
    frame = np.genfromtxt(path, delimiter=",", names=True)
    names = list(frame.dtype.names or ())
    columns = [f"obs{i}" for i in range(8)]
    if not all(column in names for column in columns):
        raise ValueError(f"replay file must contain {columns}")
    return np.column_stack([frame[column] for column in columns]).astype(float)


def bootstrap_interval(values: list[float], seed: int, samples: int = 2000) -> tuple[float, float]:
    if not values:
        return float("nan"), float("nan")
    if len(values) == 1:
        return values[0], values[0]
    rng = np.random.default_rng(seed)
    draws = rng.choice(np.asarray(values, dtype=float), size=(samples, len(values)), replace=True)
    means = draws.mean(axis=1)
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def paired_effects(action_rows: list[dict[str, Any]], seed_offset: int = 0) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, int, int, int], dict[int, dict[str, float]]] = {}
    fields = ("raw_side", "raw_quantity", "raw_urgency", "raw_delay", "released_side", "released_quantity", "released_urgency", "released_delay")
    for row in action_rows:
        key = (row["condition"], row["seed"], row["episode"], row["step"])
        grouped.setdefault(key, {})[row["membership"]] = row
    episode_values: dict[tuple[str, int, str, str], list[float]] = {}
    for (condition, seed, episode, _step), members in grouped.items():
        if 0 not in members or 1 not in members:
            continue
        for field in fields:
            key = (condition, seed, episode, field)
            episode_values.setdefault(key, []).append(float(members[1][field]) - float(members[0][field]))
    rows: list[dict[str, Any]] = []
    for (condition, seed, episode, field), values in sorted(episode_values.items()):
        low, high = bootstrap_interval(values, seed_offset + seed * 1009 + episode * 17 + len(field))
        rows.append({
            "condition": condition,
            "seed": seed,
            "episode": episode,
            "field": field,
            "paired_count": len(values),
            "mean_delta_membership1_minus0": float(np.mean(values)),
            "bootstrap_low": low,
            "bootstrap_high": high,
        })
    return rows


def run(args: argparse.Namespace) -> None:
    replay = load_replay(args.replay)
    client = LocalChatClient(args.base_url, args.model, args.timeout, args.temperature, args.allow_json_object_fallback)
    args.out.mkdir(parents=True, exist_ok=True)
    action_rows: list[dict[str, Any]] = []
    session_rows: list[dict[str, Any]] = []
    action_latency: list[float] = []
    model_call_latency: list[float] = []
    completion_samples: list[dict[str, Any]] = []
    completion_records: list[dict[str, Any]] = []
    response_format_fallbacks = 0
    completion_cache: dict[tuple[int, int, int], dict[str, Any]] = {}
    for seed in args.seeds:
        for episode in range(args.episodes):
            observations = public_window(seed, episode, args.steps, replay)
            for condition in args.conditions:
                for membership, state in STATE_PROFILES.items():
                    raw_actions: list[Action] = []
                    released_actions: list[Action] = []
                    invalid = 0
                    normalized = 0
                    condition_index = args.conditions.index(condition)
                    release_rng = np.random.default_rng(seed * 1_000_003 + episode * 1009 + condition_index * 997)
                    config = ReleaseConfig()
                    for step, observation in enumerate(observations):
                        cache_key = (seed, episode, step)
                        was_cached = condition == "public_only" and cache_key in completion_cache
                        if was_cached:
                            payload = completion_cache[cache_key]
                        else:
                            system_content = make_system_prompt(condition, state)
                            user_content = make_user_prompt(observation, state, condition)
                            request_seed = seed + episode + step
                            payload = client.complete(user_content, request_seed, system_content)
                            response_format_fallbacks += int(payload.get("_response_format_fallback", False))
                            payload["_condition"] = condition
                            payload["_system_prompt_sha256"] = sha256_text(system_content)
                            payload["_user_prompt_sha256"] = sha256_text(user_content)
                            payload["_user_prompt"] = user_content
                            payload["_system_prompt"] = system_content
                            if condition == "public_only":
                                completion_cache[cache_key] = payload
                            model_call_latency.append(float(payload.get("_latency_ms", 0.0)))
                            if len(completion_samples) < args.sample_completions:
                                choice = payload.get("choices", [{}])[0]
                                message = choice.get("message", {})
                                completion_samples.append({
                                    "condition": condition,
                                    "seed": seed,
                                    "episode": episode,
                                    "step": step,
                                    "membership": membership,
                                    "request_user_prompt": user_content,
                                    "system_prompt_sha256": sha256_text(system_content),
                                    "response_text": message.get("content", ""),
                                    "finish_reason": choice.get("finish_reason"),
                                    "latency_ms": payload.get("_latency_ms", 0.0),
                                })
                        action_latency.append(float(payload.get("_latency_ms", 0.0)))
                        content = payload["choices"][0]["message"]["content"]
                        action, parse_status = parse_action(content)
                        if action is None:
                            invalid += 1
                            action = Action(1, 0.0, 0.0, 0.0, 0.0)
                        elif parse_status == "normalized":
                            normalized += 1
                        choice = payload.get("choices", [{}])[0]
                        message = choice.get("message", {})
                        completion_records.append({
                            "condition": condition,
                            "seed": seed,
                            "episode": episode,
                            "step": step,
                            "membership": membership,
                            "request_seed": seed + episode + step,
                            "cached_public_response": was_cached,
                            "user_prompt": payload.get("_user_prompt", make_user_prompt(observation, state, condition)),
                            "system_prompt_sha256": payload.get("_system_prompt_sha256", sha256_text(make_system_prompt(condition, state))),
                            "response_text": content,
                            "finish_reason": choice.get("finish_reason"),
                            "response_format_fallback": bool(payload.get("_response_format_fallback", False)),
                            "latency_ms": payload.get("_latency_ms", 0.0),
                            "parse_status": parse_status,
                        })
                        raw_actions.append(action)
                        center = np.asarray([float(np.clip(2.0 + observation[0], 0.0, 4.0)), 0.0, 1.5])
                        released, release_meta = eti_release(action, center, release_rng, config)
                        released_actions.append(released)
                        action_rows.append({
                            "condition": condition,
                            "seed": seed,
                            "episode": episode,
                            "step": step,
                            "membership": membership,
                            "parse_status": parse_status,
                            "raw_side": action.side,
                            "raw_quantity": action.quantity,
                            "raw_urgency": action.urgency,
                            "raw_delay": action.delay,
                            "released_side": released.side,
                            "released_quantity": released.quantity,
                            "released_urgency": released.urgency,
                            "released_delay": released.delay,
                            "clip_count": release_meta["clip_count"],
                            "eps_spent": release_meta["eps_spent"],
                            "delta_spent": release_meta["delta_spent"],
                            "latency_ms": payload.get("_latency_ms", 0.0),
                        })
                    raw_feature = aggregate(raw_actions)
                    released_feature = aggregate(released_actions)
                    session_rows.append({
                        "condition": condition,
                        "seed": seed,
                        "episode": episode,
                        "membership": membership,
                        "invalid_count": invalid,
                        "normalized_count": normalized,
                        "raw_feature": raw_feature.tolist(),
                        "released_feature": released_feature.tolist(),
                        "raw_action_disagreement": float(np.mean([a.side != b.side for a, b in zip(raw_actions, released_actions)])),
                    })
        print(f"completed seed {seed}", flush=True)

    metrics = []
    for condition in args.conditions:
        for seed in args.seeds:
            condition_rows = [row for row in session_rows if row["condition"] == condition and row["seed"] == seed]
            action_condition_rows = [row for row in action_rows if row["condition"] == condition and row["seed"] == seed]
            normalized_side_rate = float(np.mean([
                int(row["raw_side"] == (-1 if row["membership"] == 0 else 1))
                for row in action_condition_rows
            ])) if condition != "public_only" else float("nan")
            strict_side_values = []
            if condition != "public_only":
                for record in completion_records:
                    if record["condition"] != condition or record["seed"] != seed:
                        continue
                    if record["parse_status"] != "valid":
                        continue
                    try:
                        strict_obj = _json_from_text(record["response_text"])
                        strict_side_values.append(
                            int(strict_obj["side"] == (-1 if record["membership"] == 0 else 1))
                        )
                    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
                        continue
            strict_side_rate = float(np.mean(strict_side_values)) if strict_side_values else float("nan")
            metrics.append({
                "condition": condition,
                "seed": seed,
                "raw_auc": evaluate_auc(session_rows, "raw_feature", seed, condition),
                "released_auc": evaluate_auc(session_rows, "released_feature", seed, condition),
                "invalid_rate": float(np.mean([row["invalid_count"] for row in condition_rows]) / args.steps),
                "normalized_rate": float(np.mean([row["normalized_count"] for row in condition_rows]) / args.steps),
                "strict_valid_rate": float(np.mean([
                    max(0, args.steps - row["invalid_count"] - row["normalized_count"])
                    for row in condition_rows
                ]) / args.steps),
                "mean_action_disagreement": float(np.mean([row["raw_action_disagreement"] for row in condition_rows])),
                "normalized_expected_side_compliance": normalized_side_rate,
                "strict_expected_side_compliance": strict_side_rate,
                "strict_expected_side_count": len(strict_side_values),
            })

    def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
        if not rows:
            return
        with path.open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    write_csv(args.out / "action_rows.csv", action_rows)
    write_csv(args.out / "session_metrics.csv", session_rows)
    write_csv(args.out / "run_metrics.csv", metrics)
    write_csv(args.out / "paired_effects.csv", paired_effects(action_rows))
    with (args.out / "raw_completion_samples.jsonl").open("w", encoding="utf-8") as stream:
        for sample in completion_samples:
            stream.write(json.dumps(sample, ensure_ascii=False) + "\n")
    with (args.out / "raw_completions.jsonl").open("w", encoding="utf-8") as stream:
        for record in completion_records:
            stream.write(json.dumps(record, ensure_ascii=False) + "\n")
    manifest = {
        "model_id": args.model,
        "model_sha256": sha256_file(args.model_path),
        "model_filename": args.model_path.name if args.model_path else args.model,
        "prompt_sha256": sha256_text(BASE_SYSTEM_PROMPT),
        "condition_prompt_hashes": {
            condition: {
                str(membership): sha256_text(make_system_prompt(condition, state))
                for membership, state in STATE_PROFILES.items()
            }
            for condition in args.conditions
        },
        "base_url": args.base_url,
        "temperature": args.temperature,
        "seeds": args.seeds,
        "episodes": args.episodes,
        "steps": args.steps,
        "conditions": args.conditions,
        "model_calls": len(completion_cache) + sum(
            1 for row in action_rows if row["condition"] != "public_only"
        ),
        "raw_action_rows": len(action_rows),
        "raw_completion_sample_count": len(completion_samples),
        "raw_completion_record_count": len(completion_records),
        "response_format_fallbacks": response_format_fallbacks,
        "json_object_fallback_allowed": args.allow_json_object_fallback,
        "paired_randomness": "request seeds and release RNG streams are shared across membership pairs; public-only responses are cached across memberships",
        "replay_file": str(args.replay) if args.replay else None,
        "replay_sha256": sha256_file(args.replay),
        "model_call_latency_p50_ms": float(np.quantile(model_call_latency, 0.50)) if model_call_latency else None,
        "model_call_latency_p95_ms": float(np.quantile(model_call_latency, 0.95)) if model_call_latency else None,
        "model_call_latency_count": len(model_call_latency),
        "action_latency_p50_ms": float(np.quantile(action_latency, 0.50)) if action_latency else None,
        "action_latency_p95_ms": float(np.quantile(action_latency, 0.95)) if action_latency else None,
        "action_latency_count": len(action_latency),
        "llama_cpp_version": args.llama_cpp_version,
        "server_command": args.server_command,
        "context_size": args.context_size,
        "backend": args.backend,
        "max_tokens": 128,
        "stop_sequences": ["<|im_end|>", "<|im_start|>"],
        "host": platform.platform(),
        "scope": "one local pretrained checkpoint; synthetic or snapshot replay public inputs; no live venue, external model generalization, or hardware claim",
        "python": platform.python_version(),
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"manifest": manifest, "metrics": metrics}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:8765/v1")
    parser.add_argument("--model", default="qwen2.5-3b-instruct-q4_k_m.gguf")
    parser.add_argument("--model-path", type=Path)
    parser.add_argument("--replay", type=Path)
    parser.add_argument("--out", type=Path, default=Path(__file__).parent / "results" / "pretrained_llm")
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    parser.add_argument("--episodes", type=int, default=8)
    parser.add_argument("--steps", type=int, default=8)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--timeout", type=float, default=120.0)
    parser.add_argument("--conditions", nargs="+", choices=CONDITIONS, default=list(CONDITIONS))
    parser.add_argument("--sample-completions", type=int, default=24)
    parser.add_argument("--llama-cpp-version", default="not-recorded")
    parser.add_argument("--server-command", default="not-recorded")
    parser.add_argument("--context-size", type=int, default=None)
    parser.add_argument("--backend", default="not-recorded")
    parser.add_argument("--allow-json-object-fallback", action="store_true")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
