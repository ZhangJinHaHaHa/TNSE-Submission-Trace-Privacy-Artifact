#!/usr/bin/env python3
"""Create a short LOBSTER message/order-book replay without redistributing data."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd


SOURCE_URL = "https://php.lobsterdata.com/info/sample/LOBSTER_SampleFile_AAPL_2012-06-21_10.zip"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_events(archive: Path, rows: int) -> pd.DataFrame:
    with zipfile.ZipFile(archive) as bundle:
        message_name = next(name for name in bundle.namelist() if name.endswith("_message_10.csv"))
        book_name = next(name for name in bundle.namelist() if name.endswith("_orderbook_10.csv"))
        messages = csv.reader((line.decode("utf-8") for line in bundle.open(message_name)))
        books = csv.reader((line.decode("utf-8") for line in bundle.open(book_name)))
        out = []
        previous_mid = None
        returns = []
        for index, (message, book) in enumerate(zip(messages, books)):
            if index >= rows:
                break
            if len(message) != 6 or len(book) != 40:
                raise ValueError(f"unexpected LOBSTER row at {index}: message={len(message)} book={len(book)}")
            timestamp, event_type, order_id, size, price, direction = message
            values = np.asarray([float(value) for value in book], dtype=float).reshape(20, 2)
            ask_price, ask_size = values[0::2, 0], values[0::2, 1]
            bid_price, bid_size = values[1::2, 0], values[1::2, 1]
            best_ask, best_bid = ask_price[0], bid_price[0]
            mid = (best_ask + best_bid) / 2.0
            ret = 0.0 if previous_mid is None else (mid - previous_mid) / max(abs(previous_mid), 1e-12)
            previous_mid = mid
            returns.append(ret)
            volatility = float(np.std(returns[-8:]))
            out.append({
                "timestamp": float(timestamp),
                "event_type": int(event_type),
                "order_id": int(order_id),
                "event_size": int(size),
                "event_price": float(price) / 10000.0,
                "event_direction": int(direction),
                "obs0": mid / 10000.0,
                "obs1": (best_ask - best_bid) / 10000.0,
                "obs2": float((bid_size[0] - ask_size[0]) / (bid_size[0] + ask_size[0] + 1e-9)),
                "obs3": float(np.sum(ask_size + bid_size) / 10000.0),
                "obs4": float(ret),
                "obs5": volatility,
                "obs6": float(best_ask) / 10000.0,
                "obs7": float(event_type) / 7.0,
            })
    return pd.DataFrame(out)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", "--zip", dest="archive", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--rows", type=int, default=240)
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    frame = read_events(args.archive, args.rows)
    frame.to_csv(args.out, index=False)
    manifest = {
        "source_url": SOURCE_URL,
        "archive_sha256": sha256_file(args.archive),
        "rows_exported": len(frame),
        "ticker": "AAPL",
        "date": "2012-06-21",
        "level": 10,
        "event_types": {
            "1": "submission",
            "2": "partial_cancellation",
            "3": "deletion",
            "4": "visible_execution",
            "5": "hidden_execution",
            "7": "trading_halt",
        },
        "observed_event_types": {
            str(int(event_type)): int(count)
            for event_type, count in frame["event_type"].value_counts().sort_index().items()
        },
        "scope": "short historical LOBSTER message/order-book replay; no live venue, queue reconstruction beyond supplied book, or claim of future profitability",
        "python": platform.python_version(),
    }
    args.out.with_name("lobster_replay_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
