#!/usr/bin/env python3
"""Validation checks for :mod:`bounded_release`.

The output is an audit of the mechanism and its public-halt boundary.  It is
not a claim that a hardware failure has been made private: a real unavailable
gateway is represented by the same public exogenous halt signal for every raw
private status, and no dummy order is generated.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

from bounded_release import (
    Config,
    LABELS,
    PUBLIC_FIELDS,
    PublicHaltActive,
    Session,
    randomized_response,
    randomized_response_probabilities,
)


def rr_matrix(samples: int = 10_000, seed: int = 20261008) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for scale in (0.5, 1.0, 2.0):
        cfg = Config(eps_scale=scale)
        rng = np.random.default_rng(seed + int(scale * 100))
        counts = {raw: {public: 0 for public in LABELS} for raw in LABELS}
        for raw in LABELS:
            for _ in range(samples):
                counts[raw][randomized_response(raw, rng, cfg.eps_order)] += 1
        expected_ratio = math.exp(cfg.eps_order)
        for raw in LABELS:
            exact = randomized_response_probabilities(raw, cfg.eps_order)
            if not math.isclose(exact[raw] / exact[LABELS[0] if LABELS[0] != raw else LABELS[1]], expected_ratio, rel_tol=1e-12):
                raise AssertionError("RR probability ratio is not exact")
            correct = counts[raw][raw]
            others = sum(counts[raw][label] for label in LABELS if label != raw)
            observed_ratio = correct / (others / (len(LABELS) - 1))
            if abs(observed_ratio / expected_ratio - 1.0) > 0.10:
                raise AssertionError(
                    f"RR ratio outside 10% Monte Carlo tolerance: scale={scale}, raw={raw}, "
                    f"observed={observed_ratio}, expected={expected_ratio}"
                )
            for public in LABELS:
                rows.append({
                    "eps_scale": scale,
                    "raw_status": raw,
                    "public_status": public,
                    "count": counts[raw][public],
                    "probability": counts[raw][public] / samples,
                })
    return rows


def session_invariants(seed: int, scale: float) -> dict[str, Any]:
    cfg = Config(eps_scale=scale)
    session = Session(cfg, seed=seed)
    raw_statuses = ("no-order", "order", "reject", "order", "audit-failure", "order", "budget-exhausted", "order")
    raw_actions = {"signed_qty": 99.0, "timing_offset": -4.0, "delay": 99.0}
    public_rows = []
    for slot, raw in enumerate(raw_statuses):
        result = session.step(raw, raw_actions if raw == "order" else None, slot)
        if tuple(result) != PUBLIC_FIELDS:
            raise AssertionError(f"public schema changed: {tuple(result)}")
        if result["eps_after"] > cfg.epsilon_cap + 1e-12 or result["delta_after"] > cfg.delta_cap + 1e-12:
            raise AssertionError("privacy budget cap exceeded")
        if result["status"] == "order":
            if not (-cfg.qty_cap - 1e-12 <= result["signed_qty"] <= cfg.qty_cap + 1e-12):
                raise AssertionError("quantity cap exceeded")
            if abs(result["signed_qty"]) < cfg.qty_floor - 1e-12:
                raise AssertionError("quantity floor violated")
            if not (0.0 <= result["timing_offset"] <= cfg.time_cap):
                raise AssertionError("timing cap violated")
            if not (0.0 <= result["delay"] <= cfg.time_cap):
                raise AssertionError("delay cap violated")
        public_rows.append(result)
    diagnostic = session.diagnostics
    if diagnostic["release_count"] > cfg.max_orders:
        raise AssertionError("max_orders exceeded")
    if diagnostic["cover_release_count"] < 0 or diagnostic["projected_release_count"] < 0:
        raise AssertionError("diagnostic count invalid")
    return {
        "seed": seed,
        "eps_scale": scale,
        "public_rows": len(public_rows),
        "release_count": diagnostic["release_count"],
        "cover_release_count": diagnostic["cover_release_count"],
        "projected_release_count": diagnostic["projected_release_count"],
        "epsilon_cap": cfg.epsilon_cap,
        "delta_cap": cfg.delta_cap,
        "epsilon_realized": diagnostic["eps_after"],
        "delta_realized": diagnostic["delta_after"],
    }


def halt_boundary_test() -> dict[str, Any]:
    receipts = []
    halted = 0
    for index, raw in enumerate(LABELS):
        session = Session(Config(), seed=100 + index)
        receipt = session.halt_from_public_signal(0, "gateway-unavailable")
        receipts.append(receipt)
        try:
            session.step(raw, {"signed_qty": 1.0, "timing_offset": 0.0, "delay": 0.0} if raw == "order" else None, 0)
        except PublicHaltActive:
            halted += 1
        else:
            raise AssertionError("a halted session emitted a release")
        if session.diagnostics["release_count"] != 0:
            raise AssertionError("halt path submitted or counted an order")
    if len({json.dumps(receipt, sort_keys=True) for receipt in receipts}) != 1:
        raise AssertionError("public exogenous halt was not status-independent")
    return {"statuses_tested": len(LABELS), "halted_sessions": halted, "orders_submitted": 0, "receipt": receipts[0]}


def validate(output: Path, samples: int = 10_000) -> dict[str, Any]:
    matrix = rr_matrix(samples=samples)
    invariant_rows = [session_invariants(seed, scale) for scale in (0.5, 1.0, 2.0) for seed in range(8)]
    halt = halt_boundary_test()
    summary = {
        "validated": True,
        "rr_samples_per_status_scale": samples,
        "rr_rows": len(matrix),
        "rr_ratio_exact_algebra": True,
        "scales": [0.5, 1.0, 2.0],
        "status_labels": list(LABELS),
        "public_fields": list(PUBLIC_FIELDS),
        "session_invariant_runs": len(invariant_rows),
        "session_invariants": invariant_rows,
        "public_halt_boundary": halt,
        "interpretation": (
            "The five-way audit-failure token is a randomized status cell. "
            "An actual unavailable gateway is represented by a public exogenous halt; "
            "the halt path emits no dummy or cover order."
        ),
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (output / "rr_matrix.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(matrix[0]))
        writer.writeheader()
        writer.writerows(matrix)
    with (output / "session_invariants.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(invariant_rows[0]))
        writer.writeheader()
        writer.writerows(invariant_rows)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "results" / "release_validation")
    parser.add_argument("--samples", type=int, default=10_000)
    args = parser.parse_args()
    if args.samples < 1_000:
        raise SystemExit("--samples must be at least 1000 for the stochastic ratio check")
    print(json.dumps(validate(args.out, args.samples), indent=2))


if __name__ == "__main__":
    main()
