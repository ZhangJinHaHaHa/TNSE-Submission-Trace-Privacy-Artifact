#!/usr/bin/env python3
"""Standard-library compatibility audit for boards without NumPy."""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
from pathlib import Path


LABELS = ("order", "no-order", "reject", "budget-exhausted", "audit-failure")
PUBLIC_FIELDS = ("status", "signed_qty", "timing_offset", "delay", "eps_after", "delta_after", "release_count")


def probabilities(status: str, epsilon: float) -> dict[str, float]:
    weight = math.exp(epsilon)
    denominator = weight + len(LABELS) - 1.0
    return {label: (weight if label == status else 1.0) / denominator for label in LABELS}


def sample_status(status: str, generator: random.Random, epsilon: float) -> str:
    draw = generator.random()
    cumulative = 0.0
    for label in LABELS:
        cumulative += probabilities(status, epsilon)[label]
        if draw <= cumulative:
            return label
    return LABELS[-1]


def laplace(generator: random.Random, scale: float) -> float:
    draw = generator.random() - 0.5
    return -scale * math.copysign(math.log1p(-2.0 * abs(draw)), draw)


class StdConfig:
    slots = 8
    max_orders = 4
    delta = 1e-5
    delta_t = 4.0
    delta_q = 4.0
    delta_d = 3.0
    qty_cap = 2.0
    qty_floor = 0.15
    time_cap = 10.0

    def __init__(self, eps_scale: float = 1.0):
        self.eps_scale = eps_scale
        self.eps_order = 0.25 * eps_scale
        self.eps_time = 0.45 * eps_scale
        self.eps_qty = 0.70 * eps_scale
        self.eps_delay = 0.35 * eps_scale
        self.eps_coordinate_sum = self.eps_time + self.eps_qty + self.eps_delay
        self.epsilon_cap = self.slots * self.eps_order + self.max_orders * self.eps_coordinate_sum
        self.delta_cap = self.max_orders * self.delta


class StdSession:
    def __init__(self, config: StdConfig, seed: int):
        self.config = config
        self.generator = random.Random(seed)
        self.next_slot = 0
        self.epsilon = 0.0
        self.delta = 0.0
        self.release_count = 0
        self.cover_count = 0
        self.projected_count = 0
        self.halted = False

    def diagnostics(self) -> dict[str, float | int | bool]:
        return {
            "release_count": self.release_count,
            "cover_release_count": self.cover_count,
            "projected_release_count": self.projected_count,
            "eps_after": self.epsilon,
            "delta_after": self.delta,
        }

    def halt(self, slot: int) -> dict[str, object]:
        self.halted = True
        return {"event": "public-halt", "slot": int(slot), "reason": "gateway-unavailable", "orders_submitted": 0}

    def step(self, raw_status: str, raw_action: dict[str, float] | None, slot: int) -> dict[str, object]:
        if self.halted:
            raise RuntimeError("public gateway halt is active")
        if slot != self.next_slot:
            raise ValueError("fixed-slot order violation")
        if raw_status == "order" and raw_action is None:
            raise ValueError("order action missing")
        self.epsilon += self.config.eps_order
        public_status = sample_status(raw_status, self.generator, self.config.eps_order)
        signed_quantity = 0.0
        timing_offset = 0.0
        delay = 0.0
        if public_status == "order" and self.release_count < self.config.max_orders and self.delta + self.config.delta <= self.config.delta_cap:
            source = raw_action if raw_status == "order" and raw_action is not None else {"signed_qty": 0.0, "timing_offset": 0.0, "delay": 0.0}
            bounded_quantity = max(-self.config.qty_cap, min(self.config.qty_cap, float(source["signed_qty"])))
            bounded_time = max(0.0, min(self.config.time_cap, float(source["timing_offset"])))
            bounded_delay = max(0.0, min(self.config.time_cap, float(source["delay"])))
            self.projected_count += int((bounded_quantity != float(source["signed_qty"])) or (bounded_time != float(source["timing_offset"])) or (bounded_delay != float(source["delay"])))
            signed_quantity = max(-self.config.qty_cap, min(self.config.qty_cap, bounded_quantity + self.generator.gauss(0.0, 0.05)))
            if abs(signed_quantity) < self.config.qty_floor:
                signed_quantity = self.config.qty_floor if signed_quantity >= 0.0 else -self.config.qty_floor
            timing_offset = max(0.0, min(self.config.time_cap, bounded_time + laplace(self.generator, self.config.delta_t / self.config.eps_time)))
            delay = max(0.0, min(self.config.time_cap, bounded_delay + laplace(self.generator, self.config.delta_d / self.config.eps_delay)))
            self.epsilon += self.config.eps_coordinate_sum
            self.delta += self.config.delta
            self.release_count += 1
            self.cover_count += int(raw_status != "order")
        elif public_status == "order":
            public_status = "budget-exhausted"
        self.next_slot += 1
        return {
            "status": public_status,
            "signed_qty": signed_quantity,
            "timing_offset": timing_offset,
            "delay": delay,
            "eps_after": self.epsilon,
            "delta_after": self.delta,
            "release_count": self.release_count,
        }


def rr_matrix(samples: int) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for scale in (0.5, 1.0, 2.0):
        for raw_status in LABELS:
            generator = random.Random(20261008 + int(scale * 1000) + LABELS.index(raw_status))
            counts = {label: 0 for label in LABELS}
            for _ in range(samples):
                counts[sample_status(raw_status, generator, 0.25 * scale)] += 1
            for public_status in LABELS:
                rows.append({"eps_scale": scale, "raw_status": raw_status, "public_status": public_status, "count": counts[public_status], "probability": counts[public_status] / samples})
    return rows


def session_rows() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    raw_statuses = ("no-order", "order", "reject", "order", "audit-failure", "order", "budget-exhausted", "order")
    raw_action = {"signed_qty": 99.0, "timing_offset": -4.0, "delay": 99.0}
    for scale in (0.5, 1.0, 2.0):
        for seed in range(8):
            session = StdSession(StdConfig(scale), seed)
            for slot, raw_status in enumerate(raw_statuses):
                result = session.step(raw_status, raw_action if raw_status == "order" else None, slot)
                if tuple(result) != PUBLIC_FIELDS:
                    raise AssertionError("public schema changed")
                if float(result["eps_after"]) > session.config.epsilon_cap + 1e-12 or float(result["delta_after"]) > session.config.delta_cap + 1e-12:
                    raise AssertionError("budget cap exceeded")
            diagnostic = session.diagnostics()
            rows.append({"seed": seed, "eps_scale": scale, "public_rows": len(raw_statuses), **diagnostic, "epsilon_cap": session.config.epsilon_cap, "delta_cap": session.config.delta_cap})
    return rows


def validate(output: Path, samples: int) -> dict[str, object]:
    matrix = rr_matrix(samples)
    invariants = session_rows()
    receipts = []
    for index, raw_status in enumerate(LABELS):
        session = StdSession(StdConfig(), 100 + index)
        receipts.append(session.halt(0))
        try:
            session.step(raw_status, {"signed_qty": 1.0, "timing_offset": 0.0, "delay": 0.0} if raw_status == "order" else None, 0)
        except RuntimeError:
            pass
        else:
            raise AssertionError("halt path emitted a release")
    if len({json.dumps(receipt, sort_keys=True) for receipt in receipts}) != 1:
        raise AssertionError("halt receipt was not status-independent")
    summary = {
        "validated": True,
        "compatibility_mode": "stdlib_no_numpy_fallback",
        "rr_samples_per_status_scale": samples,
        "rr_rows": len(matrix),
        "rr_ratio_exact_algebra": True,
        "scales": [0.5, 1.0, 2.0],
        "status_labels": list(LABELS),
        "public_fields": list(PUBLIC_FIELDS),
        "session_invariant_runs": len(invariants),
        "public_halt_boundary": {"statuses_tested": len(LABELS), "orders_submitted": 0, "receipt": receipts[0]},
        "interpretation": "Standard-library compatibility audit of the fixed-slot invariants; it is not a byte-for-byte replacement for the NumPy implementation.",
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    with (output / "rr_matrix.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(matrix[0]))
        writer.writeheader()
        writer.writerows(matrix)
    with (output / "session_invariants.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(invariants[0]))
        writer.writeheader()
        writer.writerows(invariants)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=10000)
    args = parser.parse_args()
    print(json.dumps(validate(args.out, args.samples), indent=2))


if __name__ == "__main__":
    main()
