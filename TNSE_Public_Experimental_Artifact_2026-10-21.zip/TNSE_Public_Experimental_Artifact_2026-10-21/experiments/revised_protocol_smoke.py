#!/usr/bin/env python3
"""Audit-only implementation of the revised fixed-schedule ETI contract.
It exercises disposition randomized response, hard epsilon/delta caps, Ed25519
ledger signatures, an anchor receipt, and projection/event counters. It is
separate from the legacy unconstrained benchmark so both can be audited."""
from __future__ import annotations
import argparse
import csv, hashlib, json, math, time
from pathlib import Path
import numpy as np
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

EPS_O, EPS_T, EPS_Q, EPS_D, DELTA = 0.25, 0.45, 0.70, 0.35, 1e-5
# The disposition channel is charged for every scheduled slot.  The cap is
# therefore large enough to cover 72 slots (18.0 epsilon) plus at most seven
# protected releases (10.5 epsilon).  If no disposition charge remains, the
# executor emits a deterministic budget-exhausted token before a raw query.
EPS_MAX, DELTA_MAX, MAX_RELEASES = 28.5, 7e-5, 7
K = 5

def rr(symbol: str, rng: np.random.Generator) -> str:
    labels = ["order", "no-order", "reject", "budget-exhausted", "audit-failure"]
    p = np.full(K, 1.0 / (math.exp(EPS_O) + K - 1.0))
    p[labels.index(symbol)] = math.exp(EPS_O) / (math.exp(EPS_O) + K - 1.0)
    return labels[int(rng.choice(K, p=p))]

class Ledger:
    def __init__(self):
        self.key = Ed25519PrivateKey.generate()
        self.pub = self.key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex()
        self.prev = "0" * 64
        self.entries = []
    def append(self, record):
        record = dict(record, prev_hash=self.prev)
        payload = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
        sig = self.key.sign(payload).hex()
        head = hashlib.sha256((self.prev + sig).encode() + payload).hexdigest()
        entry = dict(record, signature=sig, signature_alg="Ed25519", entry_hash=head)
        self.entries.append(entry); self.prev = head
    def verify(self):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        pub = Ed25519PublicKey.from_public_bytes(bytes.fromhex(self.pub)); prev = "0" * 64
        for e in self.entries:
            sig = bytes.fromhex(e["signature"]); rec = {k:v for k,v in e.items() if k not in ("signature","signature_alg","entry_hash")}
            payload = json.dumps(rec, sort_keys=True, separators=(",", ":")).encode(); pub.verify(sig, payload)
            head = hashlib.sha256((prev + e["signature"]).encode() + payload).hexdigest()
            assert head == e["entry_hash"] and e["prev_hash"] == prev; prev = head
        return prev == self.prev

def run(seed: int, ledger: Ledger, episodes: int = 80, steps: int = 72):
    """Run one seed and return session counters plus every scheduled token.

    Each disposition-available slot queries raw state and samples an internal
    RR candidate. An ``order`` candidate authorizes a protected release only
    when the action budget has room. The final status is recorded after this
    filter. The disposition cap is checked before any raw query or RR draw.
    """
    rng = np.random.default_rng(seed); rows=[]; events=[]
    for ep in range(episodes):
        eps=delta=0.0; releases=0; raw=orders=public_orders=no_order=clip=exhaust=0; status_mismatch=0
        disposition_counts = {k: 0 for k in ["order", "no-order", "reject", "budget-exhausted", "audit-failure"]}
        for ts in range(steps):
            # Public schedule is independent of the protected labels.
            # Once the disposition budget is exhausted, the fail-closed token
            # is deterministic and leaks no additional protected information.
            if eps + EPS_O > EPS_MAX + 1e-12:
                final_status = "budget-exhausted"
                disposition_counts[final_status] += 1; exhaust += 1
                events.append({"seed": seed, "episode": ep, "ts": ts, "raw_status": None,
                               "public_status": None, "final_status": final_status})
                ledger.append({"seed":seed,"episode":ep,"ts":ts,"status":final_status,
                               "eps_increment":0.0,"delta_increment":0.0,
                               "eps_after":round(eps,9),"delta_after":round(delta,12),
                               "certificate":"cert-v2","record_type":"scheduled-slot"})
                continue
            alpha = float(rng.normal())
            raw_order = abs(alpha) > 0.55
            raw += 1; orders += int(raw_order); no_order += int(not raw_order)
            raw_status = "order" if raw_order else "no-order"
            eps += EPS_O
            public_status = rr(raw_status, rng)
            status_mismatch += int(public_status != raw_status)
            if public_status == "order": public_orders += 1
            final_status = public_status
            if public_status == "order" and (eps + (EPS_T+EPS_Q+EPS_D) > EPS_MAX + 1e-12 or delta + DELTA > DELTA_MAX + 1e-12 or releases >= MAX_RELEASES):
                exhaust += 1; final_status = "budget-exhausted"
            disposition_counts[final_status] += 1
            events.append({"seed": seed, "episode": ep, "ts": ts, "raw_status": raw_status,
                           "public_status": public_status, "final_status": final_status})
            if final_status != "order":
                ledger.append({"seed":seed,"episode":ep,"ts":ts,"status":final_status,
                               "eps_increment":EPS_O,"delta_increment":0.0,
                               "eps_after":round(eps,9),"delta_after":round(delta,12),
                               "certificate":"cert-v2","record_type":"scheduled-slot"})
                continue
            # Bounded action cell; record if projection changed the proposal.
            q = float(rng.normal(0, 3.4)); q_proj = float(np.clip(q, -2, 2)); clip += int(abs(q-q_proj) > 1e-12)
            eps += EPS_T+EPS_Q+EPS_D; delta += DELTA; releases += 1
            ledger.append({"seed":seed,"episode":ep,"ts":ts,"status":final_status,
                           "eps_increment":EPS_O+EPS_T+EPS_Q+EPS_D,"delta_increment":DELTA,
                           "eps_after":round(eps,9),"delta_after":round(delta,12),
                           "certificate":"cert-v2","record_type":"scheduled-slot"})
        rows.append({"seed":seed,"episode":ep,"raw_decisions":raw,"raw_orders":orders,"public_orders":public_orders,
                     "no_order":no_order,"status_mismatch":status_mismatch,"projection_clip":clip,
                     "release_count":releases,"eps_spent":eps,"delta_spent":delta,"budget_exhaustion":exhaust,
                     **{f"disposition_{k.replace('-', '_')}": v for k, v in disposition_counts.items()}})
    return rows, events

def main():
    parser = argparse.ArgumentParser(
        description="Generate a fresh fixed-slot accounting export without replacing the frozen historical ledger."
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(__file__).resolve().parent / "results" / "revised_protocol_rerun_2026-10-21",
        help="fresh output directory (default is intentionally not results/revised_protocol)",
    )
    args = parser.parse_args()
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    allrows=[]; allevents=[]; ledger=Ledger()
    for seed in range(10):
        rows, events = run(seed, ledger); allrows.extend(rows); allevents.extend(events)
    with (out/"session_audit.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(allrows[0])); w.writeheader(); w.writerows(allrows)
    with (out/"ledger_full.jsonl").open("w") as f:
        for e in ledger.entries: f.write(json.dumps(e,sort_keys=True)+"\n")
    with (out/"ledger_sample.jsonl").open("w") as f:
        for e in ledger.entries[:20]: f.write(json.dumps(e,sort_keys=True)+"\n")
    # Raw statuses only contribute to aggregate session diagnostic counts.
    # They are never serialized into the public supplement.
    with (out/"disposition_events_public.jsonl").open("w") as f:
        for e in allevents:
            f.write(json.dumps({k:e[k] for k in ("seed","episode","ts","final_status")},sort_keys=True)+"\n")
    for obsolete in ("disposition_events.jsonl", "disposition_events_private_synthetic.jsonl"):
        legacy = out/obsolete
        if legacy.exists(): legacy.unlink()
    anchor={"algorithm":"SHA-256","head":ledger.prev,"public_key_ed25519":ledger.pub,
            "expected_scheduled_events":len(allevents),
            "created_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
            "anchor_scope":"local exported-log receipt; no independent trusted anchor"}
    (out/"anchor_receipt.json").write_text(json.dumps(anchor,indent=2))
    from verify_export import verify_export
    checked=verify_export(out)
    summary={"sessions":len(allrows),"scheduled_disposition_events":len(allevents),"epsilon_cap":EPS_MAX,"delta_cap":DELTA_MAX,
             "max_realized_epsilon":round(max(r['eps_spent'] for r in allrows), 10),"max_realized_delta":round(max(r['delta_spent'] for r in allrows), 10),
             "max_release_count":max(r['release_count'] for r in allrows),"budget_exhaustion_rate":float(np.mean([r['budget_exhaustion']>0 for r in allrows])),
             "projection_clip_rate_intermediate_order":float(sum(r['projection_clip'] for r in allrows)/sum(r['public_orders'] for r in allrows)),
             "projection_clip_rate_authorized_release":float(sum(r['projection_clip'] for r in allrows)/sum(r['release_count'] for r in allrows)),
             "raw_no_order_rate":float(sum(r['no_order'] for r in allrows)/sum(r['raw_decisions'] for r in allrows)),
             "public_order_rate":float(sum(r['public_orders'] for r in allrows)/sum(r['raw_decisions'] for r in allrows)),
             "ledger_signature_verified":checked['verified'],"ledger_entries":len(ledger.entries),
             "accepted_releases":checked['accepted_releases'],
             "export_signature_and_budget_verified":checked['verified'],
             "anchor_receipt":str(out / "anchor_receipt.json")}
    (out/"summary.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
