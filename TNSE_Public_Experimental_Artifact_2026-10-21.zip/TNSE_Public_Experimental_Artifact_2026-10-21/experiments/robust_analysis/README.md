> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Final derived-analysis code

This directory contains only the analysis code used to regenerate the final `robust_public` tables in the submission-ready artifact. It intentionally excludes preliminary, quick, baseline30, robust10, and legacy analysis outputs.

`extended_analysis_revised.py` computes the sequence-flatten attack, privacy curve, paired component ablation, sensitivity audit, and software-overhead diagnostics from `../eti_lob_benchmark.py`. `paired_feature_check.py` verifies the ETI-only/ETI+ledger feature comparison.
