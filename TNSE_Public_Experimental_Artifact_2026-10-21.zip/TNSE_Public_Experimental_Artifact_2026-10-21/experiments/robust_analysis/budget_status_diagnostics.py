#!/usr/bin/env python3
"""Derive explicit budget-label, action-filter, and release-count diagnostics."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_ACCOUNTING = ROOT / "experiments/results/revised_protocol_rerun_2026-10-21"
DEFAULT_PAIRED = ROOT / "experiments/results/pairedseq_temporal_mlp_rerun_2026-10-21"
DEFAULT_OUTPUT = ROOT / "outputs/budget_status_diagnostics_2026-10-21"
STATUS_LABELS = ("order", "no-order", "reject", "budget-exhausted", "audit-failure")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"no rows to write: {path}")
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def read_accounting(input_dir: Path) -> list[dict]:
    sessions = read_csv(input_dir / "session_audit.csv")
    summary = json.loads((input_dir / "summary.json").read_text())
    ledger_sessions = defaultdict(list)
    public_events = []
    with (input_dir / "disposition_events_public.jsonl").open() as stream:
        public_events = [json.loads(line) for line in stream if line.strip()]
    with (input_dir / "ledger_full.jsonl").open() as stream:
        ledger = [json.loads(line) for line in stream if line.strip()]
    if len(ledger) != len(public_events):
        raise ValueError("ledger and public stream lengths differ")
    for entry, public in zip(ledger, public_events):
        expected = {name: entry[name] for name in ("seed", "episode", "ts")}
        expected["final_status"] = entry["status"]
        if public != expected:
            raise ValueError("public stream does not match the final ledger status")
        if entry["status"] not in STATUS_LABELS:
            raise ValueError("unknown final status")
        ledger_sessions[(entry["seed"], entry["episode"])].append(entry)
    if len(sessions) != len(ledger_sessions):
        raise ValueError("session counters and ledger have different session counts")
    rows = []
    for session in sessions:
        key = (int(session["seed"]), int(session["episode"]))
        entries = ledger_sessions.pop(key)
        if [entry["ts"] for entry in entries] != list(range(len(entries))):
            raise ValueError(f"noncontiguous slots in {key}")
        statuses = Counter(entry["status"] for entry in entries)
        for label in STATUS_LABELS:
            if statuses[label] != int(session["disposition_" + label.replace("-", "_")]):
                raise ValueError(f"final-status counter mismatch in {key}")
        pre_rr_slots = sum(math.isclose(entry["eps_increment"], 0.0, abs_tol=1e-12) for entry in entries)
        if any(entry["status"] != "budget-exhausted" for entry in entries if math.isclose(entry["eps_increment"], 0.0, abs_tol=1e-12)):
            raise ValueError(f"unexpected zero-charge status in {key}")
        releases = int(session["release_count"])
        latent_orders = int(session["public_orders"])
        coarsenings = latent_orders - releases
        native_labels = statuses["budget-exhausted"] - coarsenings - pre_rr_slots
        if min(coarsenings, native_labels) < 0 or releases != statuses["order"]:
            raise ValueError(f"inconsistent latent/final counters in {key}")
        if int(session["budget_exhaustion"]) != coarsenings + pre_rr_slots:
            raise ValueError(f"historical exhaustion counter mismatch in {key}")
        rows.append({
            "seed": key[0], "episode": key[1], "scheduled_slots": len(entries),
            "authorized_releases": releases, "latent_order_candidates": latent_orders,
            "action_filter_coarsenings": coarsenings,
            "pre_rr_disposition_exhausted_slots": pre_rr_slots,
            "final_budget_exhausted_labels": statuses["budget-exhausted"],
            "native_rr_budget_exhausted_labels": native_labels,
            "has_action_filter_coarsening": int(coarsenings > 0),
            "has_final_budget_exhausted_label": int(statuses["budget-exhausted"] > 0),
            "has_native_rr_budget_exhausted_label": int(native_labels > 0),
            "reached_seven_release_cap": int(releases == 7),
            "reached_epsilon_cap": int(math.isclose(float(session["eps_spent"]), summary["epsilon_cap"], abs_tol=1e-9)),
            "reached_delta_cap": int(math.isclose(float(session["delta_spent"]), summary["delta_cap"], abs_tol=1e-12)),
            "projection_count": int(session["projection_clip"]),
            "epsilon_spent": float(session["eps_spent"]),
            "delta_spent": float(session["delta_spent"]),
        })
    return rows


def distribution(values: list[int], metric: str, minimum: int = 0, maximum: int = 7) -> list[dict]:
    if not values or min(values) < minimum or max(values) > maximum:
        raise ValueError(f"unexpected support for {metric}")
    counts = Counter(values)
    return [{"metric": metric, "count_per_session": count,
             "sessions": counts[count], "fraction_of_sessions": counts[count] / len(values)}
            for count in range(minimum, maximum + 1)]


def aggregate(rows: list[dict]) -> dict:
    summed = ("scheduled_slots", "authorized_releases", "latent_order_candidates",
              "action_filter_coarsenings", "pre_rr_disposition_exhausted_slots",
              "final_budget_exhausted_labels", "native_rr_budget_exhausted_labels",
              "has_action_filter_coarsening", "has_final_budget_exhausted_label",
              "has_native_rr_budget_exhausted_label", "reached_seven_release_cap",
              "reached_epsilon_cap", "reached_delta_cap", "projection_count")
    result = {"sessions": len(rows), **{name: sum(row[name] for row in rows) for name in summed}}
    for name in ("has_action_filter_coarsening", "has_final_budget_exhausted_label", "reached_seven_release_cap"):
        result[name + "_session_fraction"] = result[name] / len(rows)
    result["projection_fraction_of_authorized_releases"] = result["projection_count"] / result["authorized_releases"]
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--accounting", type=Path, default=DEFAULT_ACCOUNTING)
    parser.add_argument("--paired", type=Path, default=DEFAULT_PAIRED)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    for source in (args.accounting.resolve(), args.paired.resolve()):
        if args.out.resolve() == source or source in args.out.resolve().parents:
            raise ValueError("diagnostic output must be outside frozen input directories")
    rows = read_accounting(args.accounting)
    paired = [row for row in read_csv(args.paired / "session_metrics.csv") if row["mode"] == "protected"]
    if not paired:
        raise ValueError("no protected paired sessions")
    distributions = {
        "accounting_release_count_distribution.csv": distribution([row["authorized_releases"] for row in rows], "accounting_authorized_releases"),
        "paired_release_count_distribution.csv": distribution([int(row["releases"]) for row in paired], "paired_authorized_noisy_releases"),
        "paired_cover_count_distribution.csv": distribution([int(row["cover_release_count"]) for row in paired], "paired_authorized_cover_releases"),
    }
    seed_rows = [{"seed": seed, **aggregate([row for row in rows if row["seed"] == seed])}
                 for seed in sorted({row["seed"] for row in rows})]
    summary = {
        "scope": "Derived synthetic accounting and paired-kernel diagnostics; frozen inputs are unchanged.",
        "definitions": {
            "final_budget_exhausted_labels": "Observed final labels, including native RR outcomes, action-filter coarsenings, and any pre-RR terminal slots.",
            "action_filter_coarsenings": "Latent RR order candidates minus authorized final orders; a private aggregate evaluation diagnostic.",
            "pre_rr_disposition_exhausted_slots": "Zero-charge terminal slots identified from ledger increments; no RR candidate is sampled.",
            "native_rr_budget_exhausted_labels": "Session-level final-label total minus coarsenings and pre-RR terminal slots; no individual latent cause is inferred or published.",
            "reached_seven_release_cap": "Sessions with seven authorized releases, whether or not a later order candidate is blocked.",
            "historical_budget_exhaustion": "The frozen budget_exhaustion counter sums action-filter coarsenings and pre-RR terminal slots; it does not count all final budget-exhausted labels.",
            "historical_paired_exhausted_sessions": "The frozen paired exhausted_sessions field counts sessions reaching seven releases; it does not count final budget-exhausted labels or blocked candidates.",
        },
        "accounting": aggregate(rows),
        "accounting_release_count_distribution": distributions["accounting_release_count_distribution.csv"],
        "paired": {
            "sessions": len(paired),
            "authorized_noisy_releases": sum(int(row["releases"]) for row in paired),
            "sessions_reaching_seven_release_cap": sum(int(row["releases"]) == 7 for row in paired),
            "authorized_cover_releases": sum(int(row["cover_release_count"]) for row in paired),
            "release_count_distribution": distributions["paired_release_count_distribution.csv"],
            "cover_count_distribution": distributions["paired_cover_count_distribution.csv"],
        },
        "validation": {"public_stream_matches_ledger": True, "session_counts_match_ledger": True,
                       "cryptographic_signature_verification": "Not performed by this diagnostic; use verify_export.py."},
    }
    args.out.mkdir(parents=True, exist_ok=True)
    write_csv(args.out / "accounting_session_diagnostics.csv", rows)
    write_csv(args.out / "accounting_seed_summary.csv", seed_rows)
    for name, content in distributions.items():
        write_csv(args.out / name, content)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    input_paths = [args.accounting / name for name in ("session_audit.csv", "summary.json", "ledger_full.jsonl", "disposition_events_public.jsonl")]
    input_paths.append(args.paired / "session_metrics.csv")
    output_names = ["accounting_session_diagnostics.csv", "accounting_seed_summary.csv", *distributions, "summary.json"]
    manifest = {
        "script_sha256": sha256_file(Path(__file__)),
        "input_files_sha256": {str(path.relative_to(ROOT)): sha256_file(path) for path in input_paths},
        "output_files_sha256": {name: sha256_file(args.out / name) for name in output_names},
        "read_only_inputs": True,
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"output": str(args.out), "accounting": summary["accounting"]}, indent=2))


if __name__ == "__main__":
    main()
