#!/usr/bin/env python3
"""Supplementary analyses for the ETI synthetic benchmark.

This file imports the supplied benchmark without editing it.  It produces
audits that are useful for a resubmission: session-level privacy accounting,
stronger sequence attacks, paired mechanism ablations, sensitivity-event
counts, and local (software-only) edge overhead measurements.

The analyses remain B-layer synthetic evidence.  They do not emulate an LLM,
an edge NIC, or a live exchange.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import resource
import sys
import time
import tracemalloc
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
SRC = Path(__file__).resolve().parents[1] / "eti_lob_benchmark.py"
spec = importlib.util.spec_from_file_location("eti_supplied", SRC)
eti = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = eti
spec.loader.exec_module(eti)
BASE_CERTIFICATE = eti.Certificate


def write_csv(path: Path, rows: Iterable[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("")
        return
    pd.DataFrame(rows).to_csv(path, index=False)


def flatten_sequence_attack(seed: int, episodes: int = 120, steps: int = 72) -> List[dict]:
    """Train a sequence-flattened logistic attacker on each configuration.

    The supplied LSTM-reservoir has fixed recurrent weights and a linear
    readout.  Flattened sequence logistic regression exposes all 48 ordered
    events directly and provides an independent temporal baseline using only
    the supplied numpy implementation.
    """
    rows, seqs = [], []
    for i in range(episodes):
        base_seed = seed * 100_000 + i * 997
        for cfg in eti.CONFIGS:
            row, seq, _ = eti.simulate_episode(base_seed, cfg, steps)
            rows.append({**row, "episode": i, "seed": seed})
            seqs.append(seq)
    df = pd.DataFrame(rows)
    seq_arr = np.asarray(seqs)
    out = []
    for cfg in eti.CONFIGS:
        mask = df.config.to_numpy() == cfg
        cdf = df.loc[mask].reset_index(drop=True)
        cseq = seq_arr[mask].reshape(mask.sum(), -1)
        split = int(0.7 * len(cdf))
        Xtr, Xte, _, _ = eti.standardize(cseq[:split], cseq[split:])
        ytr = cdf.membership.to_numpy(dtype=float)[:split]
        yte = cdf.membership.to_numpy(dtype=int)[split:]
        model = eti.BinaryLogistic(lr=0.06, epochs=360, l2=3e-3).fit(Xtr, ytr)
        p = model.predict_proba(Xte)
        out.append({
            "seed": seed,
            "config": cfg,
            "attacker": "SequenceFlatten-LR",
            "membership_auc": eti.auc_score(yte, p),
            "episodes": episodes,
            "steps": steps,
        })
    return out


def make_certificate(scale: float):
    """Return a Certificate subclass with all privacy epsilons scaled."""
    base = BASE_CERTIFICATE

    class ScaledCertificate(base):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.eps_t *= scale
            self.eps_q *= scale
            self.eps_d *= scale

    return ScaledCertificate


def privacy_curve(
    scales: Iterable[float], seeds: Iterable[int], episodes: int = 60, steps: int = 72
) -> List[dict]:
    """Measure attack/utility/accounting over several epsilon calibrations.

    Only the full release path is run to keep this targeted analysis small.
    Each scale uses deterministic seeds and the supplied mechanism; lower
    epsilon means larger release noise.  ``eps_max`` and cumulative delta are
    computed per session from the release count.
    """
    original_configs = eti.CONFIGS
    original_cert = eti.Certificate
    out: List[dict] = []
    try:
        eti.CONFIGS = ["full"]
        for scale in scales:
            eti.Certificate = make_certificate(float(scale))
            for seed in seeds:
                metrics, feat, seq_arr, _ = eti.run_seed(seed, episodes, steps, HERE / "privacy_curve_tmp")
                # ``run_seed`` returns one row per attacker for the sole config.
                n_releases = feat.eps_spent.to_numpy(dtype=float) / (1.5 * float(scale))
                # No budget cap exists in the supplied implementation.  These
                # are realized max/mean expenditures, not a formal cap.
                eps_vals = feat.eps_spent.to_numpy(dtype=float)
                delta_vals = n_releases * 1e-5
                for m in metrics:
                    out.append({
                        "scale": float(scale),
                        "epsilon_per_release": 1.5 * float(scale),
                        "seed": seed,
                        "config": "full",
                        "attacker": m["attacker"],
                        "membership_auc": m["membership_auc"],
                        "reconstruction_rmse": m.get("reconstruction_rmse"),
                        "risk_accuracy": m.get("risk_accuracy"),
                        "sharpe_like": m["sharpe_like"],
                        "eps_mean": float(np.mean(eps_vals)),
                        "eps_max": float(np.max(eps_vals)),
                        "delta_mean": float(np.mean(delta_vals)),
                        "delta_max": float(np.max(delta_vals)),
                        "release_count_mean": float(np.mean(n_releases)),
                        "release_count_max": int(np.max(n_releases)),
                        "budget_exhaustion_frequency_at_eps20": float(np.mean(eps_vals >= 20.0)),
                        "episodes": episodes,
                        "steps": steps,
                    })
                # Independent ordered-trace attacker on the same test split.
                split = int(0.7 * len(feat))
                flat = seq_arr.reshape(len(seq_arr), -1)
                Xtr, Xte, _, _ = eti.standardize(flat[:split], flat[split:])
                ytr = feat.membership.to_numpy(dtype=float)[:split]
                yte = feat.membership.to_numpy(dtype=int)[split:]
                seq_model = eti.BinaryLogistic(lr=0.06, epochs=360, l2=3e-3).fit(Xtr, ytr)
                seq_auc = eti.auc_score(yte, seq_model.predict_proba(Xte))
                out.append({
                    "scale": float(scale),
                    "epsilon_per_release": 1.5 * float(scale),
                    "seed": seed,
                    "config": "full",
                    "attacker": "SequenceFlatten-LR",
                    "membership_auc": seq_auc,
                    "reconstruction_rmse": np.nan,
                    "risk_accuracy": np.nan,
                    "sharpe_like": float(feat.pnl.to_numpy(dtype=float).mean() / (feat.pnl.to_numpy(dtype=float).std() + 1e-8) * np.sqrt(252.0)),
                    "eps_mean": float(np.mean(eps_vals)),
                    "eps_max": float(np.max(eps_vals)),
                    "delta_mean": float(np.mean(delta_vals)),
                    "delta_max": float(np.max(delta_vals)),
                    "release_count_mean": float(np.mean(n_releases)),
                    "release_count_max": int(np.max(n_releases)),
                    "budget_exhaustion_frequency_at_eps20": float(np.mean(eps_vals >= 20.0)),
                    "episodes": episodes,
                    "steps": steps,
                })
    finally:
        eti.CONFIGS = original_configs
        eti.Certificate = original_cert
    return out


def paired_component_ablation(seeds: Iterable[int], episodes: int = 60, steps: int = 72) -> List[dict]:
    """Run ETI-only and ETI+ledger with exactly paired release RNG streams.

    The supplied script offsets the defence RNG by configuration index, which
    confounds component ablations.  Here a local wrapper forces the same
    defence seed for both paths while retaining the ledger side effect.
    """
    original_configs = eti.CONFIGS
    original_sim = eti.simulate_episode
    out = []
    try:
        # Keep the original CONFIGS for all internal index calculations but
        # force the ETI and ledger paths to share the ETI-only stream.
        def paired_sim(base_seed: int, config: str, steps_: int):
            # This is a minimally adapted copy of simulate_episode's seed rule:
            # invoke the original simulator with an equivalent config while
            # temporarily remapping the config index used by its RNG.
            # The implementation below uses a local temporary CONFIGS where
            # both names have the same index and restores it before returning.
            saved = eti.CONFIGS
            try:
                eti.CONFIGS = ["eti_only", "eti_ledger"]
                # index(eti_only)=0; index(eti_ledger)=1 remains different, so
                # patch the index lookup for this one call through a proxy.
                class ConfigList(list):
                    def index(self, value, *args):
                        if value == "eti_ledger":
                            return 0
                        return super().index(value, *args)
                eti.CONFIGS = ConfigList(["eti_only", "eti_ledger"])
                return original_sim(base_seed, config, steps_)
            finally:
                eti.CONFIGS = saved

        class PairedConfigList(list):
            def index(self, value, *args):
                if value in {"eti_only", "eti_ledger"}:
                    return 0
                return super().index(value, *args)

        eti.CONFIGS = PairedConfigList(["eti_only", "eti_ledger"])
        eti.simulate_episode = paired_sim
        for seed in seeds:
            metrics, feat, _, _ = eti.run_seed(seed, episodes, steps, HERE / "paired_tmp")
            for m in metrics:
                out.append({
                    "seed": seed,
                    "config": m["config"],
                    "attacker": m["attacker"],
                    "membership_auc": m["membership_auc"],
                    "reconstruction_rmse": m.get("reconstruction_rmse"),
                    "risk_accuracy": m.get("risk_accuracy"),
                    "sharpe_like": m["sharpe_like"],
                    "eps_mean": m["eps_spent_mean"],
                    "episodes": episodes,
                    "steps": steps,
                })
    finally:
        eti.CONFIGS = original_configs
        eti.simulate_episode = original_sim
    return out


class AuditCounter:
    def __init__(self):
        self.calls = 0
        self.projected_any = 0
        self.time_clip = 0
        self.qty_clip = 0
        self.delay_clip = 0
        self.delay_nonnegative_clip = 0
        self.raw_orders = 0
        self.no_orders = 0
        self.release_calls = 0


def sensitivity_audit(seeds: Iterable[int], episodes: int = 120, steps: int = 72) -> List[dict]:
    """Count projection events and no-order decisions in supplied code."""
    original_project = eti.ETIRelease.project
    original_policy = eti.raw_policy
    out = []
    try:
        for cfg in eti.CONFIGS:
            c = AuditCounter()

            def wrapped_policy(ts, momentum, sentiment, vol, membership, risk, theta):
                val = original_policy(ts, momentum, sentiment, vol, membership, risk, theta)
                if val is None:
                    c.no_orders += 1
                else:
                    c.raw_orders += 1
                return val

            def wrapped_project(self, raw_time, raw_qty, raw_delay, public_center):
                c.calls += 1
                t, q, d = original_project(self, raw_time, raw_qty, raw_delay, public_center)
                ct, cq, cd = public_center
                if abs(t - raw_time) > 1e-9 or abs(q - raw_qty) > 1e-9 or abs(d - raw_delay) > 1e-9:
                    c.projected_any += 1
                if abs(t - raw_time) > 1e-9:
                    c.time_clip += 1
                if abs(q - raw_qty) > 1e-9:
                    c.qty_clip += 1
                if abs(d - raw_delay) > 1e-9:
                    c.delay_clip += 1
                if raw_delay < 0.0 and d == 0.0:
                    c.delay_nonnegative_clip += 1
                return t, q, d

            eti.raw_policy = wrapped_policy
            eti.ETIRelease.project = wrapped_project
            n_eps = 0
            n_events = 0
            for seed in seeds:
                for i in range(episodes):
                    base_seed = seed * 100_000 + i * 997
                    row, _seq, _ledger = eti.simulate_episode(base_seed, cfg, steps)
                    n_eps += 1
                    n_events += int(row["event_count"])
            out.append({
                "config": cfg,
                "episodes": n_eps,
                "raw_decision_count": c.raw_orders + c.no_orders,
                "raw_order_count": c.raw_orders,
                "no_order_count": c.no_orders,
                "no_order_rate": c.no_orders / max(1, c.raw_orders + c.no_orders),
                "release_calls": c.calls,
                "projection_any_count": c.projected_any,
                "projection_any_rate": c.projected_any / max(1, c.calls),
                "time_clip_count": c.time_clip,
                "qty_clip_count": c.qty_clip,
                "delay_clip_count": c.delay_clip,
                "negative_delay_clip_count": c.delay_nonnegative_clip,
                "executed_trace_events": n_events,
                "budget_cap_implemented": False,
                "budget_exhaustion_observed": False,
            })
    finally:
        eti.ETIRelease.project = original_project
        eti.raw_policy = original_policy
    return out


def edge_overhead(seeds: Iterable[int], episodes: int = 20, steps: int = 72) -> List[dict]:
    """Measure local Python path time and serialized audit payload size."""
    out = []
    for cfg in eti.CONFIGS:
        elapsed = []
        event_counts = []
        ledger_bytes = []
        tracemalloc.start()
        # Warm-up avoids first-import effects.
        eti.simulate_episode(0, cfg, steps)
        for seed in seeds:
            for i in range(episodes):
                base_seed = seed * 100_000 + i * 997
                t0 = time.perf_counter_ns()
                row, _seq, ledger = eti.simulate_episode(base_seed, cfg, steps)
                elapsed.append((time.perf_counter_ns() - t0) / 1e6)
                event_counts.append(int(row["event_count"]))
                ledger_bytes.append(sum(len(json.dumps(e, sort_keys=True).encode()) for e in ledger))
        _current, peak_bytes = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        a = np.asarray(elapsed)
        out.append({
            "config": cfg,
            "n_episodes": len(a),
            "episode_ms_mean": float(a.mean()),
            "episode_ms_p50": float(np.percentile(a, 50)),
            "episode_ms_p95": float(np.percentile(a, 95)),
            "episode_ms_max": float(a.max()),
            "per_step_ms_mean": float(a.mean() / steps),
            "trace_events_mean": float(np.mean(event_counts)),
            "ledger_bytes_mean_first5": float(np.mean(ledger_bytes)),
            "tracemalloc_peak_kb": float(peak_bytes / 1024.0),
            "measurement": "single-process local Python wall clock; no network or edge hardware",
        })
    return out


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--out", type=Path, default=HERE)
    p.add_argument("--quick", action="store_true")
    args = p.parse_args()
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    if args.quick:
        seeds = [0, 1]
        eps = 20
        curve_scales = [0.5, 1.0, 2.0]
        curve_eps = 20
    else:
        seeds = [0, 1, 2, 3, 4]
        eps = 60
        curve_scales = [0.35, 0.5, 1.0, 2.0]
        curve_eps = 50

    seq_rows = []
    for s in seeds:
        seq_rows.extend(flatten_sequence_attack(s, episodes=eps, steps=72))
    write_csv(out / "sequence_flatten_attack.csv", seq_rows)
    write_csv(out / "sequence_flatten_attack_summary.csv",
              pd.DataFrame(seq_rows).groupby("config").membership_auc.agg(["mean", "std"]).reset_index().to_dict("records"))

    curve_rows = privacy_curve(curve_scales, seeds[:3] if args.quick else seeds, episodes=curve_eps, steps=72)
    write_csv(out / "privacy_curve.csv", curve_rows)
    cdf = pd.DataFrame(curve_rows)
    write_csv(out / "privacy_curve_summary.csv", cdf.groupby(["scale", "attacker"], dropna=False).agg(
        membership_auc_mean=("membership_auc", "mean"), membership_auc_std=("membership_auc", "std"),
        eps_mean=("eps_mean", "mean"), eps_max=("eps_max", "max"), delta_max=("delta_max", "max"),
        release_count_max=("release_count_max", "max"), sharpe_like_mean=("sharpe_like", "mean"),
    ).reset_index().to_dict("records"))

    paired_rows = paired_component_ablation(seeds[:3], episodes=curve_eps, steps=72)
    write_csv(out / "paired_component_ablation.csv", paired_rows)
    write_csv(out / "paired_component_ablation_summary.csv", pd.DataFrame(paired_rows).groupby(["config", "attacker"]).agg(
        membership_auc_mean=("membership_auc", "mean"), membership_auc_std=("membership_auc", "std"),
        eps_mean=("eps_mean", "mean"), sharpe_like_mean=("sharpe_like", "mean"),
    ).reset_index().to_dict("records"))

    audit_rows = sensitivity_audit(seeds[:3], episodes=curve_eps, steps=72)
    write_csv(out / "sensitivity_audit.csv", audit_rows)
    edge_rows = edge_overhead(seeds[:3], episodes=10 if not args.quick else 5, steps=72)
    write_csv(out / "edge_overhead.csv", edge_rows)

    manifest = {
        "source": str(SRC),
        "source_sha256": hashlib.sha256(SRC.read_bytes()).hexdigest(),
        "python": sys.version,
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "notes": [
            "All analyses use supplied synthetic LOB and no actual LLM.",
            "Edge numbers are local single-process software timings, not hardware or network measurements.",
            "Supplied benchmark has no session budget cap, fail-closed state, or rejection counter; audits report this explicitly.",
        ],
    }
    (out / "extended_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"out": str(out), "rows": {"sequence": len(seq_rows), "curve": len(curve_rows), "paired": len(paired_rows), "audit": len(audit_rows), "edge": len(edge_rows)}}, indent=2))


if __name__ == "__main__":
    main()
