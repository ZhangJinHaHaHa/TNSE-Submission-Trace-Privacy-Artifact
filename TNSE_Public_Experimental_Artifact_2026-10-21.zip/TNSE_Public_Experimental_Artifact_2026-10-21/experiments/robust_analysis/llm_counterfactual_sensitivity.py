#!/usr/bin/env python3
"""Pairwise action-field sensitivity audit for the retained Qwen records.

Only strict-valid rows are used.  Public replay, seed, episode, and step are
held fixed while membership 1 minus membership 0 is computed.  Incomplete
pairs are excluded rather than imputed, and bootstrap resampling is clustered
by complete episode.  This is a model-interface diagnostic, not a privacy
estimate or a claim that the requested side policy was followed.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


FIELDS = ("raw_side", "raw_quantity", "raw_urgency", "raw_delay",
          "released_side", "released_quantity", "released_urgency",
          "released_delay")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def load_rows(path: Path):
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    pairs = defaultdict(dict)
    for row in rows:
        if row["condition"] not in {"explicit_user_state", "hidden_system_state"}:
            continue
        if row["parse_status"] != "valid":
            continue
        key = (row["condition"], int(row["seed"]), int(row["episode"]), int(row["step"]))
        pairs[key][int(row["membership"])] = row
    complete = []
    for key, members in sorted(pairs.items()):
        if set(members) != {0, 1}:
            continue
        delta = {field: float(members[1][field]) - float(members[0][field]) for field in FIELDS}
        complete.append((key, delta))
    return complete


def bootstrap(values_by_episode, rng, draws=5000):
    keys = sorted(values_by_episode)
    if not keys:
        return float("nan"), float("nan")
    samples = np.empty(draws, dtype=float)
    for i in range(draws):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        values = [v for index in chosen for v in values_by_episode[keys[index]]]
        samples[i] = float(np.mean(values))
    return float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--action-rows", type=Path, default=Path(
        "strengthening/real_llm_lobster/action_rows.csv"))
    parser.add_argument("--out", type=Path, default=Path(
        "robust_analysis/llm_counterfactual_sensitivity"))
    parser.add_argument("--bootstrap-draws", type=int, default=5000)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    complete = load_rows(args.action_rows)
    by_condition = defaultdict(list)
    for key, delta in complete:
        by_condition[key[0]].append((key, delta))

    rows = []
    for condition in ("explicit_user_state", "hidden_system_state"):
        items = by_condition[condition]
        all_episode_values = defaultdict(lambda: defaultdict(list))
        for key, delta in items:
            episode = (key[1], key[2])
            for field in FIELDS:
                all_episode_values[field][episode].append(delta[field])
        full_episodes = {
            field: {episode: values for episode, values in episodes.items() if len(values) == 8}
            for field, episodes in all_episode_values.items()
        }
        full_keys = set(full_episodes[FIELDS[0]])
        analysis_items = [(key, delta) for key, delta in items if (key[1], key[2]) in full_keys]
        rng = np.random.default_rng(20261009 + (0 if condition == "explicit_user_state" else 1))
        for field in FIELDS:
            values = [delta[field] for _key, delta in analysis_items]
            low, high = bootstrap(full_episodes[field], rng, args.bootstrap_draws)
            rows.append({
                "condition": condition,
                "field": field,
                "strict_valid_pairs_total": len(items),
                "full_episode_pairs_used": len(values),
                "full_episodes_used": len(full_episodes[field]),
                "mean_delta_membership1_minus0": float(np.mean(values)) if values else float("nan"),
                "bootstrap_low": low,
                "bootstrap_high": high,
                "bootstrap_unit": "complete (seed, episode) clusters",
                "invalid_or_incomplete_rows_excluded": True,
                "partial_episodes_excluded_from_estimate": True,
            })

    with (args.out / "summary.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    manifest = {
        "analysis": "counterfactual_action_field_sensitivity",
        "source": str(args.action_rows),
        "source_sha256": sha256(args.action_rows),
        "conditions": ["explicit_user_state", "hidden_system_state"],
        "fields": list(FIELDS),
        "pair_key": ["condition", "seed", "episode", "step"],
        "pair_definition": "same public replay and step with membership 0 and 1",
        "strict_valid_only": True,
        "invalid_or_incomplete_policy": "exclude; no sentinel or imputation",
        "bootstrap": {"draws": args.bootstrap_draws, "unit": "complete (seed, episode) clusters", "seed": 20261009},
        "scope": "descriptive checkpoint/interface behavior; not privacy, arbitrary-LLM, or trading-utility evidence",
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {len(rows)} field summaries to {args.out}")


if __name__ == "__main__":
    main()
