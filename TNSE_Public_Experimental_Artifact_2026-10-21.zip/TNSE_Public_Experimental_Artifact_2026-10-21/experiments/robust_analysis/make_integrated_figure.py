#!/usr/bin/env python3
"""Reproduce the exact numeric figure for the paired synthetic trace experiment."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'results' / 'end_to_end'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'pdf.fonttype': 42, 'savefig.facecolor': 'white'})


def main():
    runs = pd.read_csv(DATA / 'run_metrics.csv')
    sessions = pd.read_csv(DATA / 'session_metrics.csv')
    assert runs['seed'].nunique() == 10
    protected = sessions[sessions['mode'] == 'protected']
    assert len(protected) == 2000
    fig, axs = plt.subplots(1, 2, figsize=(10, 3.7), gridspec_kw={'width_ratios': [1.1, 1]})
    colors = {'raw': '#57697c', 'protected': '#0a789c'}
    width = .16
    x = np.arange(2)
    for j, mode in enumerate(('raw', 'protected')):
        sub = runs[runs['mode'] == mode].sort_values('seed')
        for i, metric in enumerate(('feature_auc', 'sequence_auc')):
            values = sub[metric].to_numpy()
            pos = x[i] + (j - .5) * .30
            axs[0].scatter(np.full(len(values), pos), values,
                           s=12, alpha=.28, color=colors[mode], zorder=2)
            axs[0].errorbar(pos, values.mean(), yerr=values.std(ddof=1),
                            fmt='o', markersize=7, capsize=4, elinewidth=1.3,
                            color=colors[mode], label=('Raw' if j==0 else 'Fixed-slot') if i==0 else None,
                            zorder=4)
            axs[0].text(pos + (-width if j==0 else width), values.mean()+.018,
                        f'{values.mean():.3f}', fontsize=8, ha='center', color=colors[mode])
    axs[0].axhline(.5, color='#ad7266', linewidth=1, linestyle='--', label='Chance AUC')
    axs[0].set_xticks(x, ('Feature LR', 'Flattened-sequence LR'))
    axs[0].set_ylim(.25, 1.11)
    axs[0].set_ylabel('Membership-inference AUC')
    axs[0].set_title('(a) Synthetic attack results (10 seeds)', fontsize=10, fontweight='bold')
    axs[0].legend(frameon=False, loc='lower right', fontsize=8)
    counts = protected['cover_release_count'].value_counts().sort_index()
    bins = np.arange(8)
    heights = np.array([counts.get(int(k), 0) for k in bins])
    axs[1].bar(bins, heights, width=.75, color='#da8450', edgecolor='white')
    axs[1].set_xticks(bins)
    axs[1].set_ylim(0, max(heights)*1.20)
    axs[1].set_xlabel('Authorized cover releases per session')
    axs[1].set_ylabel('Protected sessions (n = 2,000)')
    axs[1].set_title('(b) Cover-order burden', fontsize=10, fontweight='bold')
    axs[1].text(.97, .97, f'Total: {int(protected.cover_release_count.sum()):,}',
                transform=axs[1].transAxes, ha='right', va='top', fontsize=9,
                color='#85451c')
    fig.tight_layout(pad=1.25, w_pad=2.0)
    pdf = DATA / 'integrated_results.pdf'
    png = DATA / 'integrated_results.png'
    fig.savefig(pdf, bbox_inches='tight')
    fig.savefig(png, dpi=180, bbox_inches='tight')
    print(pdf)
    print(png)

if __name__=='__main__':main()
