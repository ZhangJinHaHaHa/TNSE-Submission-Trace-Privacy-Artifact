#!/usr/bin/env python3
"""Render a new three-panel figure for the 2026-10-21 paired-sequence rerun.

It never reads or rewrites results/end_to_end/integrated_results.pdf, which is
an archived legacy figure.  All panels use only the new rerun's public-sequence
attack summaries and synthetic session burden diagnostics.
"""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
DEFAULT_INPUT = HERE.parent / "results" / "pairedseq_temporal_mlp_rerun_2026-10-21"
DEFAULT_ATTACK = HERE.parents[1] / "outputs" / "pairedseq_temporal_mlp_2026-10-21"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--attack", type=Path, default=DEFAULT_ATTACK)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()
    out = args.out or args.attack
    out.mkdir(parents=True, exist_ok=True)
    per_seed = pd.read_csv(args.attack / "temporal_mlp_paired_summary_by_seed.csv").sort_values("generation_seed")
    sessions = pd.read_csv(args.input / "session_metrics.csv")
    summary = json.loads((args.attack / "summary.json").read_text())
    protected = sessions[sessions["mode"] == "protected"]
    if len(per_seed) != 10 or len(protected) != 2000:
        raise ValueError("expected the 10-seed, 2,000-protected-session rerun")

    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8.5, "axes.spines.top": False,
        "axes.spines.right": False, "pdf.fonttype": 42, "savefig.facecolor": "white",
    })
    fig, axes = plt.subplots(1, 3, figsize=(12.2, 3.55), gridspec_kw={"width_ratios": [1.14, 1.0, 1.05]})
    colors = {"raw": "#57697c", "protected": "#0a789c", "difference": "#8b5d78", "burden": "#da8450"}

    # (a) Generation-seed results; each point is the mean over the five fixed MLP initializations.
    x = np.array([0, 1])
    raw = per_seed["raw_auc_mean_over_5_inits"].to_numpy()
    protected_auc = per_seed["protected_auc_mean_over_5_inits"].to_numpy()
    for position, values, label, color in ((x[0], raw, "Raw", colors["raw"]), (x[1], protected_auc, "Fixed-slot protected", colors["protected"])):
        jitter = np.linspace(-0.07, 0.07, len(values))
        axes[0].scatter(position + jitter, values, color=color, s=20, alpha=.58, zorder=2)
        axes[0].errorbar(position, values.mean(), yerr=values.std(ddof=1), fmt="o", color=color,
                         capsize=4, markersize=7, linewidth=1.4, zorder=4)
        axes[0].text(position, min(1.02, values.mean() + .065), f"{values.mean():.3f}", ha="center", color=color)
    axes[0].axhline(.5, color="#ad7266", linewidth=1, linestyle="--", label="Chance AUC")
    axes[0].set_xticks(x, ("Raw", "Fixed-slot\nprotected"))
    axes[0].set_ylim(.2, 1.08)
    axes[0].set_ylabel("Membership-inference AUC")
    axes[0].set_title("(a) Order-sensitive TemporalMLP", fontweight="bold", fontsize=9.5)
    axes[0].legend(frameon=False, fontsize=7.5, loc="lower left")
    axes[0].text(.5, -.28, "10 generation seeds; 60 test sessions/mode/seed\npoints average 5 fixed model initializations",
                 transform=axes[0].transAxes, ha="center", va="top", fontsize=7)

    # (b) Matched raw-minus-protected differences, paired within each generator seed.
    difference = per_seed["paired_raw_minus_protected_mean_over_5_inits"].to_numpy()
    axes[1].scatter(np.arange(len(difference)), difference, color=colors["difference"], s=26, alpha=.72)
    axes[1].axhline(0, color="#444444", linewidth=.9)
    axes[1].axhline(difference.mean(), color=colors["difference"], linewidth=1.5, linestyle="--")
    ci = summary["overall"]["paired_raw_minus_protected_auc"]
    axes[1].text(.97, .08, f"mean {difference.mean():.3f}\nseed bootstrap 95% CI\n[{ci['bootstrap_95ci_low']:.3f}, {ci['bootstrap_95ci_high']:.3f}]",
                 transform=axes[1].transAxes, ha="right", va="bottom", fontsize=7.5, color=colors["difference"])
    axes[1].set_xticks(np.arange(len(difference)), [str(value) for value in per_seed["generation_seed"]])
    axes[1].set_xlabel("Generation seed")
    axes[1].set_ylabel("Raw AUC − protected AUC")
    axes[1].set_title("(b) Paired per-seed contrast", fontweight="bold", fontsize=9.5)

    # (c) Operational cover burden from the same newly generated protected sessions.
    counts = protected["cover_release_count"].value_counts().sort_index()
    bins = np.arange(int(max(7, counts.index.max())) + 1)
    heights = np.array([counts.get(int(value), 0) for value in bins])
    axes[2].bar(bins, heights, width=.78, color=colors["burden"], edgecolor="white")
    axes[2].set_xticks(bins)
    axes[2].set_xlabel("Authorized cover releases per protected session")
    axes[2].set_ylabel("Synthetic sessions (n = 2,000)")
    axes[2].set_title("(c) Fixed-slot cover burden", fontweight="bold", fontsize=9.5)
    axes[2].text(.97, .97, f"total: {int(protected.cover_release_count.sum()):,}\nmean: {protected.cover_release_count.mean():.3f}",
                 transform=axes[2].transAxes, ha="right", va="top", fontsize=8, color="#85451c")

    fig.tight_layout(pad=1.0, w_pad=1.6)
    pdf = out / "pairedseq_integrated_results.pdf"
    png = out / "pairedseq_integrated_results.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=200, bbox_inches="tight")
    shutil.copy2(Path(__file__), out / Path(__file__).name)
    print(pdf)
    print(png)


if __name__ == "__main__":
    main()
