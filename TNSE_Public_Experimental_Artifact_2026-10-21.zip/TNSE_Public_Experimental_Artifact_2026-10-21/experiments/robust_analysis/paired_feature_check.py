from pathlib import Path
import importlib.util,sys
import numpy as np,pandas as pd
root=Path(__file__).resolve().parents[1]
p=root/'eti_lob_benchmark.py';s=importlib.util.spec_from_file_location('e',p);e=importlib.util.module_from_spec(s);sys.modules[s.name]=e;s.loader.exec_module(e)
class CL(list):
    def index(self,v,*a): return 0 if v in {'eti_only','eti_ledger'} else super().index(v,*a)
e.CONFIGS=CL(['eti_only','eti_ledger'])
rows=[]
for seed in [0,1,2,3,4]:
    for i in range(60):
        base=seed*100_000+i*997
        for cfg in ['eti_only','eti_ledger']:
            row,_,_=e.simulate_episode(base,cfg,72)
            rows.append({**row,'seed':seed,'episode':i})
df=pd.DataFrame(rows)
result=[]
for seed in sorted(df.seed.unique()):
    for cfg in ['eti_only','eti_ledger']:
        cdf=df[(df.seed==seed)&(df.config==cfg)].reset_index(drop=True)
        split=int(.7*len(cdf)); ytr=cdf.membership.values[:split].astype(float); yte=cdf.membership.values[split:].astype(int)
        for drop in [False,True]:
            cols=[c for c in e.FEATURE_NAMES if not(drop and c=='ledger_entries')]
            Xtr,Xte,_,_=e.standardize(cdf[cols].values[:split],cdf[cols].values[split:])
            m=e.BinaryLogistic(lr=.07,epochs=260).fit(Xtr,ytr)
            result.append({'seed':seed,'config':cfg,'features':'all' if not drop else 'without_ledger_entries','auc':e.auc_score(yte,m.predict_proba(Xte))})
out=pd.DataFrame(result);out.to_csv(root/'robust_public'/'paired_feature_check.csv',index=False)
print(out.groupby(['config','features']).auc.agg(['mean','std']).reset_index().to_string(index=False))
# exact feature equality check excluding ledger_entries
for c in e.FEATURE_NAMES:
  if c=='ledger_entries':continue
  a=df[df.config=='eti_only'][c].to_numpy(); b=df[df.config=='eti_ledger'][c].to_numpy()
  print(c,np.max(np.abs(a-b)))
