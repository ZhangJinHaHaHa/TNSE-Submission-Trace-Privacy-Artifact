#!/usr/bin/env python3
"""Summarize the paired synthetic kernel's burden without inferring economic utility.

Run from experiments/:
  python3 robust_analysis/paired_operational_burden.py \
    --input results/pairedseq_temporal_mlp_rerun_2026-10-21/session_metrics.csv \
    --out ../outputs/pairedseq_temporal_mlp_2026-10-21

Session counters are internal research diagnostics, never attacker inputs.
Post-horizon events are artificial-continuation submissions, not network deadlines.
"""
from pathlib import Path
import argparse
import hashlib
import json
import pandas as pd


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    args = ap.parse_args()
    frame = pd.read_csv(args.input)
    assert set(frame['mode']) == {'raw', 'protected'}
    rows = []
    for mode, part in frame.groupby('mode'):
        events = int(part.order_events.sum())
        late = int(part.late_order_events.sum())
        releases = int(part.releases.sum())
        rows.append({'mode': mode, 'sessions': len(part), 'order_events': events,
                     'late_order_events': late,
                     'order_events_per_session': float(part.order_events.mean()),
                     'late_events_per_session': float(part.late_order_events.mean()),
                     'late_fraction_of_emitted_orders': late/events if events else None,
                     'cover_releases': int(part.cover_release_count.sum()),
                     'cover_releases_per_session': float(part.cover_release_count.mean()),
                     'projection_count': int(part.projected_count.sum()),
                     'authorized_noisy_releases': releases,
                     'projection_fraction_of_authorized_noisy_releases': float(part.projected_count.sum()/releases) if releases else None,
                     'mean_epsilon': float(part.eps.mean()), 'max_epsilon': float(part.eps.max())})
    args.out.mkdir(parents=True, exist_ok=True)
    out = args.out/'new_kernel_operational_burden.csv'
    pd.DataFrame(rows).set_index('mode').to_csv(out)
    manifest = {'scope': 'same paired synthetic kernel; not venue/economic utility',
                'source_sha256': sha(Path(__file__)), 'input_sha256': sha(args.input),
                'output_sha256': sha(out), 'records': rows}
    (args.out/'operational_burden_addendum.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(out)


if __name__ == '__main__':
    main()
