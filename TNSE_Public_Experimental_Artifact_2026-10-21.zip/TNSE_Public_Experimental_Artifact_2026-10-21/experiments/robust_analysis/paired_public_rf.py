#!/usr/bin/env python3
"""Post-hoc fixed nonlinear public-trace audit.

This script reads the already archived synthetic paired-state sessions. It
does not rerun the mechanism, tune a classifier, or use private accounting or
P&L as attacker inputs. The result is a static nonlinear check, not a temporal
or optimal-attacker claim.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parents[1]))
from eti_lob_benchmark import RandomForestLite, auc_score, standardize


def audit(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    auc_rows = []
    burden_rows = []
    feature_cols = [f"f{i}" for i in range(11)]
    for seed in sorted(frame["seed"].unique()):
        data = frame[(frame["seed"] == seed) & (frame["mode"] == "protected")].reset_index(drop=True)
        pairs = np.array(sorted(data["pair"].unique()))
        split = int(len(pairs) * 0.7)
        train_pairs = set(np.random.default_rng(int(seed) + 24031).permutation(pairs)[:split])
        train = data["pair"].isin(train_pairs).to_numpy()
        test = ~train
        x_train, x_test, _, _ = standardize(
            data.loc[train, feature_cols].to_numpy(dtype=float),
            data.loc[test, feature_cols].to_numpy(dtype=float),
        )
        y = data["membership"].to_numpy(dtype=int)
        model = RandomForestLite(n_trees=35, task="binary", seed=int(seed) + 4001).fit(x_train, y[train])
        auc_rows.append({
            "seed": int(seed),
            "n_train": int(train.sum()),
            "n_test": int(test.sum()),
            "rf_trees": 35,
            "rf_max_depth": 5,
            "rf_min_leaf": 5,
            "auc": auc_score(y[test], model.predict_value(x_test)),
        })
        for mode in ("raw", "protected"):
            subset = frame[(frame["seed"] == seed) & (frame["mode"] == mode)]
            burden_rows.append({
                "seed": int(seed),
                "mode": mode,
                "eps_mean": float(subset["eps"].mean()),
                "releases_mean": float(subset["releases"].mean()),
                "cover_release_mean": float(subset["cover_release_count"].mean()),
                "cover_submitted_mean": float(subset["cover_submitted_count"].mean()),
                "projected_mean": float(subset["projected_count"].mean()),
                "order_events_mean": float(subset["order_events"].mean()),
                "late_events_mean": float(subset["late_order_events"].mean()),
                "pnl_mean_simulator_only": float(subset["pnl"].mean()),
            })
    return pd.DataFrame(auc_rows), pd.DataFrame(burden_rows)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path(__file__).parents[1] / "results" / "end_to_end" / "session_metrics.csv")
    parser.add_argument("--out", type=Path, default=Path(__file__).parent / "paired_public_rf")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    auc_rows, burden_rows = audit(pd.read_csv(args.input))
    auc_rows.to_csv(args.out / "rf_auc_by_seed.csv", index=False)
    burden_rows.to_csv(args.out / "operational_burden_by_seed.csv", index=False)
    summary = {
        "method": "post-hoc fixed RandomForestLite on protected public f0..f10",
        "split": "pair-disjoint 70/30 split copied from end_to_end_trace_eval.py",
        "trees": 35,
        "max_depth": 5,
        "min_leaf": 5,
        "tuning": "none",
        "attacker_scope": "static nonlinear check only; no temporal or optimal-attacker claim",
        "auc_mean": float(auc_rows["auc"].mean()),
        "auc_sd_across_seeds": float(auc_rows["auc"].std(ddof=1)),
        "auc_by_seed": auc_rows.to_dict(orient="records"),
        "input_session_metrics": str(args.input),
        "input_sha256": sha256_file(args.input),
        "attacker_features": "public protected-session columns f0..f10 only",
        "pnl_scope": "simulator-only diagnostic; not profitability or deployment utility",
    }
    (args.out / "manifest.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
