#!/usr/bin/env python3
"""Pre-specified paired TemporalMLP audit on regenerated fixed-slot public traces.

The input archive keeps public 18x9 traces separate from score-only membership
labels.  The classifier receives only the ordered final public array, flattened
in slot order; it never receives labels, pair identifiers, private accounting,
P&L, or session diagnostics as features.  The raw condition is the unprotected
direct-output baseline, while the protected condition excludes raw policy/action
values.  Each generation seed uses exactly the same pair-disjoint 70/30 split
in raw and protected conditions.  Five fixed MLP initializations are
descriptive replications, not hyperparameter selection.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import roc_auc_score
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
import sklearn


HERE = Path(__file__).resolve().parent
DEFAULT_INPUT = HERE.parent / "results" / "pairedseq_temporal_mlp_rerun_2026-10-21"
DEFAULT_OUTPUT = HERE.parents[1] / "outputs" / "pairedseq_temporal_mlp_2026-10-21"
MODES = ("raw", "protected")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_public_archive(input_dir: Path) -> tuple[np.ndarray, pd.DataFrame, pd.DataFrame]:
    """Read public traces, non-feature pair metadata, and isolated score labels."""
    sequence_path = input_dir / "public_sequences.npz"
    index_path = input_dir / "public_sequence_index.csv"
    label_path = input_dir / "scoring_labels.csv"
    for path in (sequence_path, index_path, label_path):
        if not path.exists():
            raise FileNotFoundError(path)
    with np.load(sequence_path) as archive:
        if archive.files != ["sequences"]:
            raise ValueError("public sequence archive must contain only `sequences`")
        sequences = np.asarray(archive["sequences"], dtype=np.float64)
    index = pd.read_csv(index_path)
    labels = pd.read_csv(label_path)
    if sequences.ndim != 3 or sequences.shape[1:] != (18, 9):
        raise ValueError(f"expected public sequences [n,18,9], got {sequences.shape}")
    required_index = {"row_index", "seed", "pair", "mode"}
    if set(index.columns) != required_index:
        raise ValueError(f"public index must contain exactly {sorted(required_index)}")
    if set(labels.columns) != {"row_index", "membership"}:
        raise ValueError("score labels must contain exactly row_index,membership")
    if len(sequences) != len(index) or len(index) != len(labels):
        raise ValueError("public arrays, index, and score labels are not aligned")
    if not np.array_equal(index["row_index"].to_numpy(), np.arange(len(index))):
        raise ValueError("public index row_index is not contiguous")
    if not np.array_equal(labels["row_index"].to_numpy(), np.arange(len(labels))):
        raise ValueError("score label row_index is not contiguous")
    if set(index["mode"].unique()) != set(MODES):
        raise ValueError("archive must have exactly raw and protected modes")
    for mode in MODES:
        separate_path = input_dir / f"public_sequences_{mode}.npz"
        if not separate_path.exists():
            raise FileNotFoundError(separate_path)
        with np.load(separate_path) as separate_archive:
            separate = np.asarray(separate_archive["sequences"], dtype=np.float64)
        expected = sequences[index["mode"].to_numpy() == mode]
        if not np.array_equal(separate, expected):
            raise ValueError(f"{separate_path.name} does not match combined public archive")
    y = labels["membership"].to_numpy(dtype=int)
    if not set(np.unique(y)).issubset({0, 1}) or np.unique(y).size != 2:
        raise ValueError("score-only membership labels must be binary and include both classes")
    return sequences, index, labels


def pair_split(index: pd.DataFrame, generation_seed: int) -> tuple[set[int], set[int]]:
    """Pre-specified pair-disjoint 70/30 split shared by both mechanism modes."""
    pairs = np.sort(index.loc[index["seed"] == generation_seed, "pair"].unique())
    if len(pairs) < 4:
        raise ValueError(f"generation seed {generation_seed} has too few pairs")
    permuted = np.random.default_rng(int(generation_seed) + 24031).permutation(pairs)
    n_train = int(0.70 * len(permuted))
    train_pairs = set(int(value) for value in permuted[:n_train])
    test_pairs = set(int(value) for value in permuted[n_train:])
    if not train_pairs or not test_pairs or train_pairs.intersection(test_pairs):
        raise AssertionError("invalid pair-disjoint split")
    return train_pairs, test_pairs


def fit_condition(
    sequences: np.ndarray,
    index: pd.DataFrame,
    labels: pd.DataFrame,
    generation_seed: int,
    mode: str,
    model_init: int,
    train_pairs: set[int],
    test_pairs: set[int],
) -> dict[str, object]:
    """Fit the fixed MLP with a training-only scaler and score held-out pairs."""
    keep = (index["seed"] == generation_seed) & (index["mode"] == mode)
    positions = index.index[keep].to_numpy(dtype=int)
    meta = index.loc[keep].reset_index(drop=True)
    x = sequences[positions].reshape(len(positions), -1)  # preserves fixed slot/channel order
    y = labels.loc[positions, "membership"].to_numpy(dtype=int)
    train = meta["pair"].isin(train_pairs).to_numpy()
    test = meta["pair"].isin(test_pairs).to_numpy()
    if np.any(train & test) or not np.all(train | test):
        raise AssertionError("row partition is not disjoint and exhaustive")
    if set(meta.loc[train, "pair"]).intersection(set(meta.loc[test, "pair"])):
        raise AssertionError("a paired public path crossed the train/test split")
    if np.unique(y[train]).size != 2 or np.unique(y[test]).size != 2:
        raise ValueError("both partitions must contain both membership labels")
    scaler = StandardScaler().fit(x[train])  # no test-derived centering/scaling
    x_train = scaler.transform(x[train])
    x_test = scaler.transform(x[test])
    classifier = MLPClassifier(
        hidden_layer_sizes=(64, 32),
        activation="relu",
        solver="adam",
        alpha=1e-2,
        batch_size=32,
        learning_rate_init=2e-3,
        max_iter=400,
        early_stopping=False,
        shuffle=True,
        random_state=int(generation_seed) * 1000 + int(model_init),
    )
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        classifier.fit(x_train, y[train])
    scores = classifier.predict_proba(x_test)[:, 1]
    return {
        "generation_seed": int(generation_seed),
        "mode": mode,
        "model_init": int(model_init),
        "auc": float(roc_auc_score(y[test], scores)),
        "train_sessions": int(train.sum()),
        "test_sessions": int(test.sum()),
        "train_pairs": int(meta.loc[train, "pair"].nunique()),
        "test_pairs": int(meta.loc[test, "pair"].nunique()),
        "features": int(x.shape[1]),
        "n_iter": int(classifier.n_iter_),
        "convergence_warning": bool(any(isinstance(item.message, ConvergenceWarning) for item in caught)),
    }


def seed_bootstrap(values: np.ndarray, repeats: int, seed: int) -> dict[str, float | int]:
    """Bootstrap the mean across independent generation seeds, not test rows."""
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    sampled = values[rng.integers(0, len(values), size=(int(repeats), len(values)))].mean(axis=1)
    return {
        "mean": float(values.mean()),
        "sd_across_generation_seeds": float(values.std(ddof=1)),
        "bootstrap_repeats": int(repeats),
        "bootstrap_95ci_low": float(np.percentile(sampled, 2.5)),
        "bootstrap_95ci_high": float(np.percentile(sampled, 97.5)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--model-inits", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    parser.add_argument("--seed-bootstrap", type=int, default=10_000)
    args = parser.parse_args()
    if args.seed_bootstrap < 1000:
        raise ValueError("--seed-bootstrap must be at least 1000")
    if len(set(args.model_inits)) != len(args.model_inits) or not args.model_inits:
        raise ValueError("--model-inits must be nonempty and unique")
    args.out.mkdir(parents=True, exist_ok=True)
    sequences, index, labels = read_public_archive(args.input)

    rows: list[dict[str, object]] = []
    split_rows: list[dict[str, int]] = []
    generation_seeds = sorted(int(value) for value in index["seed"].unique())
    for generation_seed in generation_seeds:
        train_pairs, test_pairs = pair_split(index, generation_seed)
        split_rows.append({
            "generation_seed": generation_seed,
            "train_pairs": len(train_pairs), "test_pairs": len(test_pairs),
            "train_sessions_per_mode": len(train_pairs) * 2,
            "test_sessions_per_mode": len(test_pairs) * 2,
        })
        for mode in MODES:
            for model_init in args.model_inits:
                rows.append(fit_condition(
                    sequences, index, labels, generation_seed, mode, model_init, train_pairs, test_pairs,
                ))
        print(f"completed generation seed {generation_seed}", flush=True)

    by_init = pd.DataFrame(rows).sort_values(["generation_seed", "model_init", "mode"])
    by_init.to_csv(args.out / "temporal_mlp_auc_by_seed_init.csv", index=False)
    pd.DataFrame(split_rows).to_csv(args.out / "test_counts_by_seed.csv", index=False)
    pivot = by_init.pivot(index=["generation_seed", "model_init"], columns="mode", values="auc").reset_index()
    pivot["raw_minus_protected_auc"] = pivot["raw"] - pivot["protected"]
    pivot.to_csv(args.out / "paired_auc_by_seed_init.csv", index=False)

    summary_rows: list[dict[str, object]] = []
    for generation_seed, group in pivot.groupby("generation_seed", sort=True):
        raw = group["raw"].to_numpy(dtype=float)
        protected = group["protected"].to_numpy(dtype=float)
        difference = group["raw_minus_protected_auc"].to_numpy(dtype=float)
        count = by_init[(by_init["generation_seed"] == generation_seed) & (by_init["mode"] == "raw")].iloc[0]
        summary_rows.append({
            "generation_seed": int(generation_seed),
            "raw_auc_mean_over_5_inits": float(raw.mean()),
            "raw_auc_sd_over_5_inits": float(raw.std(ddof=1)),
            "protected_auc_mean_over_5_inits": float(protected.mean()),
            "protected_auc_sd_over_5_inits": float(protected.std(ddof=1)),
            "paired_raw_minus_protected_mean_over_5_inits": float(difference.mean()),
            "paired_difference_sd_over_5_inits": float(difference.std(ddof=1)),
            "train_sessions_per_mode": int(count["train_sessions"]),
            "test_sessions_per_mode": int(count["test_sessions"]),
            "train_pairs": int(count["train_pairs"]),
            "test_pairs": int(count["test_pairs"]),
        })
    per_seed = pd.DataFrame(summary_rows)
    per_seed.to_csv(args.out / "temporal_mlp_paired_summary_by_seed.csv", index=False)

    seed_difference = per_seed["paired_raw_minus_protected_mean_over_5_inits"].to_numpy(dtype=float)
    raw_seed_auc = per_seed["raw_auc_mean_over_5_inits"].to_numpy(dtype=float)
    protected_seed_auc = per_seed["protected_auc_mean_over_5_inits"].to_numpy(dtype=float)
    overall = {
        "raw_auc": seed_bootstrap(raw_seed_auc, args.seed_bootstrap, 2026102101),
        "protected_auc": seed_bootstrap(protected_seed_auc, args.seed_bootstrap, 2026102102),
        "paired_raw_minus_protected_auc": seed_bootstrap(seed_difference, args.seed_bootstrap, 2026102103),
    }
    summary = {
        "analysis": "pre-specified order-sensitive TemporalMLP membership attacker on synthetic paired fixed-slot public traces",
        "scope": "new synthetic rerun only; not a live venue, hardware, historical-market, or LLM result",
        "attacker_input": "public_sequences.npz only: ordered 18 x 9 final public channels",
        "excluded_from_attacker_features": [
            "membership score label", "seed", "pair identifier", "mode identifier",
            "private epsilon/delta accounting", "P&L", "inventory", "session diagnostics",
        ],
        "condition_specific_public_view": (
            "Raw is the direct-output baseline and protected is the randomized fixed-slot output; "
            "both use the same 18x9 public schema and paired exogenous path, but no single sequence "
            "realization is reused across conditions. Protected attacker inputs exclude raw policy/action values."
        ),
        "split": {
            "type": "pair-disjoint fixed 70/30 split within each generation seed",
            "formula": "numpy.default_rng(generation_seed + 24031).permutation(pairs)[:floor(0.70*n_pairs)]",
            "shared_between_raw_and_protected": True,
            "train_sessions_per_mode_per_seed": int(per_seed["train_sessions_per_mode"].iloc[0]),
            "test_sessions_per_mode_per_seed": int(per_seed["test_sessions_per_mode"].iloc[0]),
            "train_pairs_per_seed": int(per_seed["train_pairs"].iloc[0]),
            "test_pairs_per_seed": int(per_seed["test_pairs"].iloc[0]),
        },
        "model": {
            "name": "sklearn.neural_network.MLPClassifier",
            "order_sensitive_representation": "flattened 18x9 public sequence in fixed slot order (no permutation-invariant pooling)",
            "hidden_layer_sizes": [64, 32], "activation": "relu", "solver": "adam",
            "alpha": 1e-2, "batch_size": 32, "learning_rate_init": 2e-3,
            "max_iter": 400, "early_stopping": False,
            "model_initializations": [int(value) for value in args.model_inits],
            "scaling": "StandardScaler fit on each condition's training sessions only",
            "test_set_tuning": "none; architecture, optimization, split, five initializations, and seed bootstrap were fixed before scoring",
        },
        "uncertainty": {
            "unit": "generation seed after averaging matched model initializations",
            "method": "nonparametric bootstrap of the mean across the 10 generation seeds",
            "seed_bootstrap_repeats": int(args.seed_bootstrap),
            "paired_estimate": "raw AUC minus protected AUC for the same generation seed and model initialization",
        },
        "generation_seeds": generation_seeds,
        "overall": overall,
        "convergence_warnings": int(by_init["convergence_warning"].sum()),
        "runtime": {
            "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
            "scikit_learn": sklearn.__version__,
        },
        "input_files_sha256": {
            name: sha256_file(args.input / name)
            for name in [
                "public_sequences.npz", "public_sequences_raw.npz", "public_sequences_protected.npz",
                "public_sequence_index.csv", "scoring_labels.csv", "generation_manifest.json",
            ]
        },
    }
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    manifest = {
        "script": str(Path(__file__).resolve()),
        "script_sha256": sha256_file(Path(__file__).resolve()),
        "input_dir": str(args.input.resolve()),
        "output_dir": str(args.out.resolve()),
        "runtime": summary["runtime"],
        "data_hashes": summary["input_files_sha256"],
        "hyperparameters": summary["model"],
        "csv_and_summary_sha256": {
            name: sha256_file(args.out / name)
            for name in [
                "temporal_mlp_auc_by_seed_init.csv", "paired_auc_by_seed_init.csv",
                "temporal_mlp_paired_summary_by_seed.csv", "test_counts_by_seed.csv", "summary.json",
            ]
        },
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"out": str(args.out), "overall": overall}, indent=2))


if __name__ == "__main__":
    main()
