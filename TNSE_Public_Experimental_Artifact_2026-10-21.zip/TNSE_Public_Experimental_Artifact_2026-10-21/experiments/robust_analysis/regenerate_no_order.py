#!/usr/bin/env python3
"""Regenerate raw no-order counts from the CURRENT legacy policy and seeds.

This diagnostic is evaluated before any release; it is not a public trace.
Use the same seed/episode construction as the paired 60-episode check.
"""
from pathlib import Path
import csv
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from eti_lob_benchmark import CONFIGS, public_series, raw_policy  # noqa: E402


def main():
    counts = {0: [0, 0], 1: [0, 0]}
    for seed in range(5):
        for episode in range(60):
            label_rng = np.random.default_rng(seed * 100_000 + episode * 997 + 11)
            membership = int(label_rng.integers(0, 2))
            risk = int(label_rng.integers(0, 3))
            theta = float(label_rng.normal(0, 1))
            momentum, sentiment, vol = public_series(label_rng, 72, membership)
            interval = (4, 5, 6)[risk]
            for ts in range(0, 72, interval):
                counts[membership][0] += 1
                counts[membership][1] += raw_policy(
                    ts, momentum, sentiment, vol, membership, risk, theta) is None
    out = ROOT / 'robust_public' / 'no_order_by_membership_summary.csv'
    with out.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=('config', 'membership', 'decisions',
                                               'no_order_count', 'no_order_rate'))
        writer.writeheader()
        for cfg in CONFIGS:
            for m, (n, k) in counts.items():
                writer.writerow({'config': cfg, 'membership': m, 'decisions': n,
                                 'no_order_count': k, 'no_order_rate': k / n})
    print(out, counts)


if __name__ == '__main__':
    main()
