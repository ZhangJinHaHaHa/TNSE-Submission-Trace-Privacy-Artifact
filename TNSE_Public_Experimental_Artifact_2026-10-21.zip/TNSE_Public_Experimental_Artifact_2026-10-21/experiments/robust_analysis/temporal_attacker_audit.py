#!/usr/bin/env python3
"""Audit a trained, order-sensitive attacker on archived public sequences.

The input is the public sequence archive produced by ``eti_lob_benchmark.py``
and its row-level metadata.  The attacker never receives membership, private
accounting, raw policy values, or P&L.  A blocked-by-time split is applied
within each generation seed: early episodes are used for training and later
episodes are held out.  The episode identifier is the pair/group key, so no
episode can contribute rows to both partitions.

This is a stronger learned temporal check than the existing linear and fixed
reservoir baselines, but it is not an optimal attacker, a trained recurrent
network, or evidence of an unrestricted adversary.  The order-sensitive
features preserve the event order and are followed by a fitted MLP classifier.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import warnings
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    brier_score_loss,
    roc_auc_score,
)
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler


HERE = Path(__file__).resolve().parent
DEFAULT_INPUT = (
    HERE.parent / "robust_public" / "primary5"
)
DEFAULT_OUTPUT = HERE / "temporal_attacker_audit"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def temporal_features(sequences: np.ndarray) -> np.ndarray:
    """Create public, order-sensitive features without using labels.

    The flattened channels retain absolute event order.  First differences
    expose changes between adjacent public events.  Four fixed time windows
    add local level, volatility, and directional trend summaries.  No model
    parameter is fit in this transformation, which keeps leakage checks
    straightforward; the scaler and MLP are fit on training rows only.
    """
    values = np.asarray(sequences, dtype=np.float64)
    if values.ndim != 3:
        raise ValueError(f"expected [n,time,channels], got {values.shape}")
    n, length, channels = values.shape
    differences = np.diff(values, axis=1, prepend=values[:, :1, :])
    blocks = [values.reshape(n, -1), differences.reshape(n, -1)]
    edges = np.linspace(0, length, 5, dtype=int)
    window_features = []
    for start, stop in zip(edges[:-1], edges[1:]):
        window = values[:, start:stop, :]
        window_features.extend(
            [
                np.mean(window, axis=1),
                np.std(window, axis=1),
                window[:, -1, :] - window[:, 0, :],
            ]
        )
    blocks.append(np.concatenate(window_features, axis=1))
    return np.concatenate(blocks, axis=1)


def bootstrap_auc(
    y_true: np.ndarray,
    scores: np.ndarray,
    rng: np.random.Generator,
    repeats: int,
) -> tuple[float, float, float]:
    """Return percentile 95% CI for test-set AUC by row bootstrap."""
    values: list[float] = []
    n = len(y_true)
    for _ in range(int(repeats)):
        sample = rng.integers(0, n, size=n)
        if np.unique(y_true[sample]).size < 2:
            continue
        values.append(float(roc_auc_score(y_true[sample], scores[sample])))
    if not values:
        return float("nan"), float("nan"), float("nan")
    return (
        float(np.mean(values)),
        float(np.percentile(values, 2.5)),
        float(np.percentile(values, 97.5)),
    )


def permutation_auc_pvalue(
    y_true: np.ndarray,
    scores: np.ndarray,
    rng: np.random.Generator,
    repeats: int,
) -> float:
    """Two-sided label permutation across the pooled held-out sessions."""
    observed = float(roc_auc_score(y_true, scores))
    distance = abs(observed - 0.5)
    exceed = 0
    valid = 0
    for _ in range(int(repeats)):
        permuted = rng.permutation(y_true)
        if np.unique(permuted).size < 2:
            continue
        valid += 1
        if abs(float(roc_auc_score(permuted, scores)) - 0.5) >= distance:
            exceed += 1
    return float((1 + exceed) / (1 + valid))


def read_archive(input_dir: Path) -> tuple[pd.DataFrame, np.ndarray, list[Path]]:
    """Load and align full-configuration rows with saved sequence arrays."""
    metadata_path = input_dir / "trace_features.csv"
    if not metadata_path.exists():
        raise FileNotFoundError(metadata_path)
    metadata = pd.read_csv(metadata_path)
    required = {"seed", "episode", "config", "membership"}
    missing = required.difference(metadata.columns)
    if missing:
        raise ValueError(f"metadata missing columns: {sorted(missing)}")
    sequence_paths = sorted(input_dir.glob("sequences_seed*.npz"))
    if not sequence_paths:
        raise FileNotFoundError(f"no sequences_seed*.npz under {input_dir}")

    rows: list[pd.DataFrame] = []
    sequences: list[np.ndarray] = []
    for sequence_path in sequence_paths:
        name = sequence_path.stem
        seed = int(name.removeprefix("sequences_seed"))
        seed_rows = metadata[metadata["seed"] == seed].reset_index(drop=True)
        raw = np.load(sequence_path)
        if "sequences" not in raw.files:
            raise ValueError(f"{sequence_path} does not contain `sequences`")
        seed_sequences = np.asarray(raw["sequences"], dtype=np.float64)
        if len(seed_rows) != len(seed_sequences):
            raise ValueError(
                f"row/sequence mismatch for seed {seed}: "
                f"{len(seed_rows)} rows vs {len(seed_sequences)} sequences"
            )
        # The benchmark emits episode-major, configuration-minor rows and
        # arrays in the same order.  Keep only the full public configuration;
        # configuration labels themselves are never model inputs.
        keep = seed_rows["config"].eq("full").to_numpy()
        rows.append(seed_rows.loc[keep].copy())
        sequences.append(seed_sequences[keep])

    frame = pd.concat(rows, ignore_index=True)
    sequence_array = np.concatenate(sequences, axis=0)
    if len(frame) != len(sequence_array):
        raise AssertionError("aligned frame and sequence lengths differ")
    # A stable group key prevents the same episode/pair from crossing a split.
    frame["pair_id"] = frame["seed"].astype(str) + ":" + frame["episode"].astype(str)
    return frame, sequence_array, sequence_paths


def blocked_split(frame: pd.DataFrame, train_fraction: float) -> tuple[np.ndarray, np.ndarray]:
    """Return early-episode train and late-episode test masks per seed."""
    train = np.zeros(len(frame), dtype=bool)
    test = np.zeros(len(frame), dtype=bool)
    for seed, group in frame.groupby("seed", sort=True):
        episodes = np.sort(group["episode"].unique())
        if len(episodes) < 4:
            raise ValueError(f"seed {seed} has too few episodes for a blocked split")
        cut = max(1, min(len(episodes) - 1, int(np.floor(len(episodes) * train_fraction))))
        train_eps = set(episodes[:cut])
        test_eps = set(episodes[cut:])
        train |= ((frame["seed"] == seed) & frame["episode"].isin(train_eps)).to_numpy()
        test |= ((frame["seed"] == seed) & frame["episode"].isin(test_eps)).to_numpy()
    if np.any(train & test) or not np.all(train | test):
        raise AssertionError("blocked split is not a disjoint partition")
    if frame.loc[train, "pair_id"].isin(frame.loc[test, "pair_id"]).any():
        raise AssertionError("pair leakage across blocked split")
    return train, test


def fit_one(
    x_train: np.ndarray,
    x_test: np.ndarray,
    y_train: np.ndarray,
    y_test: np.ndarray,
    model_seed: int,
    bootstrap_repeats: int,
    permutation_repeats: int,
) -> dict:
    scaler = StandardScaler().fit(x_train)
    train_scaled = scaler.transform(x_train)
    test_scaled = scaler.transform(x_test)
    model = MLPClassifier(
        hidden_layer_sizes=(64, 32),
        activation="relu",
        solver="adam",
        alpha=1e-2,
        batch_size=min(32, len(y_train)),
        learning_rate_init=2e-3,
        max_iter=600,
        random_state=int(model_seed),
        shuffle=True,
        early_stopping=False,
    )
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        model.fit(train_scaled, y_train)
    scores = model.predict_proba(test_scaled)[:, 1]
    predictions = (scores >= 0.5).astype(int)
    auc = float(roc_auc_score(y_test, scores))
    ci_mean, ci_low, ci_high = bootstrap_auc(
        y_test,
        scores,
        np.random.default_rng(10_000 + int(model_seed)),
        bootstrap_repeats,
    )
    pvalue = permutation_auc_pvalue(
        y_test,
        scores,
        np.random.default_rng(20_000 + int(model_seed)),
        permutation_repeats,
    )
    return {
        "attacker": "Temporal-MLP",
        "model_seed": int(model_seed),
        "auc": auc,
        "auc_bootstrap_mean": ci_mean,
        "auc_bootstrap_ci_low": ci_low,
        "auc_bootstrap_ci_high": ci_high,
        "auc_permutation_pvalue_vs_0_5": pvalue,
        "accuracy": float(accuracy_score(y_test, predictions)),
        "balanced_accuracy": float(balanced_accuracy_score(y_test, predictions)),
        "brier_score": float(brier_score_loss(y_test, scores)),
        "n_iter": int(model.n_iter_),
        "convergence_warning": bool(any(isinstance(w.message, ConvergenceWarning) for w in caught)),
    }


def summarize(rows: pd.DataFrame) -> pd.DataFrame:
    grouped = rows.groupby("attacker", dropna=False)
    result = grouped.agg(
        n_fits=("model_seed", "count"),
        auc_mean=("auc", "mean"),
        auc_sd=("auc", "std"),
        auc_min=("auc", "min"),
        auc_max=("auc", "max"),
        auc_bootstrap_ci_low_mean=("auc_bootstrap_ci_low", "mean"),
        auc_bootstrap_ci_high_mean=("auc_bootstrap_ci_high", "mean"),
        permutation_pvalue_mean=("auc_permutation_pvalue_vs_0_5", "mean"),
        accuracy_mean=("accuracy", "mean"),
        balanced_accuracy_mean=("balanced_accuracy", "mean"),
        brier_score_mean=("brier_score", "mean"),
    ).reset_index()
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--train-fraction", type=float, default=0.70)
    parser.add_argument("--model-seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--permutations", type=int, default=2000)
    args = parser.parse_args()
    if not 0.5 <= args.train_fraction < 1.0:
        raise ValueError("--train-fraction must be in [0.5, 1)")
    args.out.mkdir(parents=True, exist_ok=True)
    frame, sequences, sequence_paths = read_archive(args.input)
    train_mask, test_mask = blocked_split(frame, args.train_fraction)
    x = temporal_features(sequences)
    y = frame["membership"].to_numpy(dtype=int)
    if np.unique(y[train_mask]).size < 2 or np.unique(y[test_mask]).size < 2:
        raise ValueError("blocked split must contain both membership classes")

    rows = []
    for model_seed in args.model_seeds:
        metrics = fit_one(
            x[train_mask],
            x[test_mask],
            y[train_mask],
            y[test_mask],
            model_seed,
            args.bootstrap,
            args.permutations,
        )
        metrics.update(
            {
                "train_rows": int(train_mask.sum()),
                "test_rows": int(test_mask.sum()),
                "train_pairs": int(frame.loc[train_mask, "pair_id"].nunique()),
                "test_pairs": int(frame.loc[test_mask, "pair_id"].nunique()),
                "train_episode_max": int(frame.loc[train_mask, "episode"].max()),
                "test_episode_min": int(frame.loc[test_mask, "episode"].min()),
                "feature_count": int(x.shape[1]),
                "sequence_shape": json.dumps(list(sequences.shape[1:])),
            }
        )
        rows.append(metrics)
    metrics_df = pd.DataFrame(rows)
    metrics_df.to_csv(args.out / "temporal_attacker_by_seed.csv", index=False)
    summary_df = summarize(metrics_df)
    summary_df.to_csv(args.out / "temporal_attacker_summary.csv", index=False)

    manifest = {
        "analysis": "trained order-sensitive Temporal-MLP membership attacker",
        "input_dir": str(args.input),
        "metadata_sha256": sha256_file(args.input / "trace_features.csv"),
        "sequence_files": [
            {"path": str(path), "sha256": sha256_file(path)} for path in sequence_paths
        ],
        "configuration": "full",
        "public_inputs": "archived full-configuration sequence channels only",
        "excluded_inputs": [
            "membership label",
            "raw policy/action values",
            "private epsilon/delta accounting",
            "P&L and inventory",
            "configuration identifier",
        ],
        "split": {
            "type": "blocked-by-time within each generation seed",
            "train_fraction": args.train_fraction,
            "group_key": "seed:episode (pair/group key)",
            "pair_disjoint": True,
            "train_episode_max": int(frame.loc[train_mask, "episode"].max()),
            "test_episode_min": int(frame.loc[test_mask, "episode"].min()),
            "note": "The archived primary5 rows contain one membership state per episode; pair_id prevents repeated episodes crossing the split but is not a counterfactual state pair.",
        },
        "feature_map": "ordered sequence + adjacent differences + four fixed-window mean/std/trend summaries",
        "classifier": {
            "name": "sklearn.neural_network.MLPClassifier",
            "hidden_layer_sizes": [64, 32],
            "alpha": 1e-2,
            "max_iter": 600,
            "model_seeds": [int(value) for value in args.model_seeds],
        },
        "uncertainty": {
            "bootstrap_repeats": int(args.bootstrap),
            "permutation_repeats": int(args.permutations),
            "permutation_null": "AUC = 0.5",
            "permutation_scope": "Labels are shuffled across the pooled held-out sessions; blocked describes the train/test split, not the permutation.",
            "pvalue_aggregation": "The mean over fixed model initializations is a descriptive arithmetic mean, not a combined significance test.",
        },
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
        },
        "not_claimed": [
            "not an optimal or unrestricted attacker",
            "not a recurrent-neural-network result",
            "not a live exchange or hardware-edge experiment",
            "not arbitrary-LLM generalization",
        ],
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"rows": len(metrics_df), "out": str(args.out)}, indent=2))
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
