> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Trained temporal attacker audit

`temporal_attacker_audit.py` evaluates a learned order-sensitive membership
attacker against the archived public sequence output of the supplied synthetic
benchmark.  It is an additional robustness audit and does not replace the
existing fixed-reservoir, logistic, or random-forest checks.

## Reproduction

From the `experiments` directory:

```bash
python robust_analysis/temporal_attacker_audit.py \
  --input robust_public/primary5 \
  --out robust_analysis/temporal_attacker_audit
```

The script keeps only the `full` mechanism configuration and uses the saved
sequence arrays plus the matching `trace_features.csv` rows.  It constructs
order-preserving sequence and adjacent-difference features, adds four fixed
time-window summaries, and trains a scikit-learn MLP classifier with five
model seeds.  The scaler is fit on training rows only.

## Split and uncertainty

Episodes are sorted within each generation seed.  The first 70% are training
episodes and the last 30% are held-out test episodes (blocked-by-time).  The
group key `seed:episode` is kept wholly on one side of the split, preventing
episode/pair leakage.  The archived primary5 data contain one membership state
per episode, so this is group isolation rather than a counterfactual state-pair
experiment.  Test-set AUC receives a percentile bootstrap interval and a
two-sided label-permutation p-value against AUC 0.5.
The permutation shuffles labels across the entire pooled held-out set;
“blocked” describes the train/test split, not a restriction on label shuffling.
The reported mean p-value across model initializations is a descriptive
arithmetic mean, not a combined significance test.

## Interpretation limits

This is a trained temporal audit, not an optimal or unrestricted attacker.  It
is not a recurrent neural network, live-exchange evidence, hardware-edge
measurement, or arbitrary-LLM generalization.  The attacker receives only
archived public sequence channels; labels, raw actions, private accounting,
P&L, inventory, and configuration identifiers are excluded.

Outputs are written to `temporal_attacker_by_seed.csv`,
`temporal_attacker_summary.csv`, and `manifest.json`.
