> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Provenance notes

## Public inputs

- Model family: Qwen2.5-3B-Instruct-GGUF, downloaded from the official
  [Qwen Hugging Face repository](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF).
  File: `qwen2.5-3b-instruct-q4_k_m.gguf`; SHA-256:
  `626b4a6678b86442240e33df819e00132d3ba7dddfe1cdc4fbb18e0a9615c62d`.
- Historical event sample: [LOBSTER AAPL sample files](https://php.lobsterdata.com/info/DataSamples.php),
  2012-06-21, 10 levels; downloaded archive SHA-256:
  `326839316d67d7819ca0541ffdf73cdb044d6ae4105cce0ef9c615e8848e9d43`.
- Direct sample URL:
  `https://php.lobsterdata.com/info/sample/LOBSTER_SampleFile_AAPL_2012-06-21_10.zip`.
  The derived replay has 240 rows and retains event-type metadata; raw vendor
  files are not redistributed.

## Experiment identity

- Prompt SHA-256:
  `50aa82e2544a0b2933672553ea0115f0b80a6eed76c2220511f1bdf96da2e24b`.
- LOBSTER-derived replay CSV SHA-256:
  `a6f934f225f58a62567d502c31fcd76b1683c9dd7d4da6d42609ab021bc7ca96`.
- Historical Qwen archive: 3 seeds, 8 episodes, 8 steps, 384 calls, with
  parser-normalized rows but no retained raw completions. The completed
  three-condition audit made 960 unique calls and retains 1,152
  completion/action rows because public-only responses are cached across the
  two membership values; public-only and explicit-state strict validity
  was 384/384 each, hidden-state strict validity was 371/384, and 13 hidden
  completions ended at the length limit. The server used the recorded
  `json_object` fallback because this llama.cpp version rejected `json_schema`.
  This is a local Qwen/llama.cpp checkpoint/interface test only.

- Second checkpoint: Qwen3-1.7B Safetensors from the existing authorized H20
  server cache (the machine-specific absolute path is intentionally omitted
  from the public artifact).
  config.json SHA-256:
  1ddb5b89ebc90dcb417a45c213d818577e65976454d29385c8f6140771d95197;
  index SHA-256:
  0d660e94b165eb912669a5249dff44b83188c4777a07ddb9611fb78d91b0578d.
  The two model-shard hashes and sizes are in
  real_llm_qwen3_1p7b/model_provenance.json. The run used Transformers
  4.53.2/PyTorch 2.6.0+cu124 on logical CUDA device 1 (mapped physical GPU 5),
  with the same three conditions and 3 seeds, 8 episodes, and 8 steps. It
  made 1,152 calls and retained raw completions. This is a second-checkpoint
  interface test, not arbitrary-LLM or live-venue evidence.

- The common-parser reanalysis retains original completion bytes and historical
  summaries. Its canonical Qwen3 public-only result is 178/384 strict and
  206/384 normalized; the original 274/384 strict count used a different
  integer/float rule. Both current runners share `checkpoint_action_parser.py`.
  See the checkpoint-local canonical manifest for input and parser hashes,
  and its provenance recovery record for recovered execution arguments and
  the distinction between recorded file identities and missing upstream
  revision/tokenizer hashes.

- The full-session AAPL replay is additionally audited in eight contiguous
  equal-duration event-time windows by historical_blocked_replay_audit.py.
  The window rows sum to 400,390; closed lifetimes sum to 180,930; two
  deletion-size mismatches and 8,381 left-censored carry-in events are
  reported rather than corrected. This remains an observable LOBSTER message
  lifecycle audit, not a matching-engine, queue, ACK, venue-latency, or
  hardware-edge experiment.

- robust_analysis/temporal_attacker_audit/ is a trainable order-sensitive
  Temporal-MLP audit on public full-configuration sequences. It uses blocked
  70/30 episode splits, five model seeds, 2,000 bootstrap resamples, and
  2,000 label permutations. Mean AUC is 0.66325 (SD 0.01665), mean
  bootstrap endpoints [0.53487, 0.78200], and mean permutation p=0.01829.
  This exposes residual signal and is not an optimal/adaptive attacker, RNN,
  live venue, hardware edge, or arbitrary-LLM result.

## Interpretation limits

No live exchange connection, third-party attestation, external timestamp
anchor, production hardware deployment, or venue matching-engine replay is
claimed. The bounded-release and edge-fault outputs are software validation
artifacts; they do not replace a formal proof or an independent production
audit.
