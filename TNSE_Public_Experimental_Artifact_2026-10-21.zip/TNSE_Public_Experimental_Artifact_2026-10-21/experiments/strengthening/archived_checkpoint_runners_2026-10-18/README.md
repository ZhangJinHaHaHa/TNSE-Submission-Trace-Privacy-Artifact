> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Archived checkpoint runner sources

These two files preserve the original runner bytes present in the 18 October
supplement. They explain the historical parser labels in the frozen checkpoint
outputs. They are evidence snapshots, not the current runnable entry points.

The active runners in the parent directory now share
`checkpoint_action_parser.py` (`integer-side-qwen25-v1`). Its strict rule follows
the original Qwen2.5 implementation: `side` must be an integer `-1` or `1`, not a
floating-point value or boolean. The JSON object must have exactly the four
action keys, no surrounding prose or Markdown, and finite values within the
declared bounds. Normalization remains a separate outcome.

The historical Qwen3 parser counted `side: 1.0` as strict. Consequently its
frozen `summary.json` is a record of the original classification, while
`real_llm_qwen3_1p7b/canonical_reanalysis_2026-10-21/summary.json` supplies the
current common-definition validity figures. Neither model was rerun for this
correction. The reanalysis manifests record these source snapshot hashes and
the unchanged raw-output hashes.
