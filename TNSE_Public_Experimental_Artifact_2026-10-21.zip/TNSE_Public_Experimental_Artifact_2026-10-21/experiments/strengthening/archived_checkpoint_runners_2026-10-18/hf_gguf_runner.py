#!/usr/bin/env python3
"""Run the fixed three-condition protocol with a public Hugging Face GGUF.

This is a second-checkpoint robustness experiment.  It deliberately keeps the
same public replay, state profiles, prompts, parser, and paired seeds as the
archived llama.cpp run.  The output is an interface check, not an arbitrary-LLM
or live-venue claim.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import platform
import re
import time
from pathlib import Path
from typing import Any

import numpy as np


CONDITIONS = ("public_only", "explicit_user_state", "hidden_system_state")
STATE_PROFILES = {
    0: np.array([-0.65, -0.15, 0.25, 0.10], dtype=float),
    1: np.array([0.65, 0.15, -0.25, -0.10], dtype=float),
}
BASE_SYSTEM_PROMPT = (
    "You are a deterministic trading-action policy. Use both the public LOB "
    "observation and the private risk state. For reproducibility, choose side "
    "1 when private_state[0] is nonnegative and -1 otherwise; choose quantity "
    "between 0.25 and 2.0 from the magnitude of private_state[0]; choose "
    "urgency between 0 and 1 from public_observation[2] (higher imbalance "
    "means higher urgency); choose delay between 0 and 10 inversely from "
    "urgency. Return exactly one JSON object with numeric keys side, quantity, "
    "urgency, and delay. Do not include markdown or extra keys."
)
PUBLIC_ONLY_SYSTEM_PROMPT = (
    "You are a deterministic trading-action policy. Use only the public LOB "
    "observation supplied by the user; do not infer or invent a private state. "
    "Choose side from the public imbalance, quantity between 0.25 and 2.0, "
    "urgency between 0 and 1, and delay between 0 and 10. Return exactly one "
    "JSON object with numeric keys side, quantity, urgency, and delay. Do not "
    "include markdown or extra keys."
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def system_prompt(condition: str, state: np.ndarray) -> str:
    if condition == "public_only":
        return PUBLIC_ONLY_SYSTEM_PROMPT
    if condition == "explicit_user_state":
        return BASE_SYSTEM_PROMPT
    if condition == "hidden_system_state":
        private = json.dumps([round(float(x), 6) for x in state], separators=(",", ":"))
        return BASE_SYSTEM_PROMPT + (
            "\nThe private risk state is supplied only in this system context and "
            "must not be repeated in the user-facing response. private_state=" + private
        )
    raise ValueError(condition)


def user_prompt(observation: np.ndarray, state: np.ndarray, condition: str) -> str:
    payload: dict[str, Any] = {
        "public_observation": [round(float(x), 6) for x in observation],
        "instruction": "Return one bounded action for this slot.",
    }
    if condition == "explicit_user_state":
        payload["private_state"] = [round(float(x), 6) for x in state]
    return json.dumps(payload, separators=(",", ":"))


def parse_action(text: str) -> tuple[str, dict[str, float] | None]:
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.I | re.S).strip()
    try:
        value = json.loads(cleaned)
    except json.JSONDecodeError:
        start, end = cleaned.find("{"), cleaned.rfind("}")
        if start < 0 or end <= start:
            return "invalid", None
        try:
            value = json.loads(cleaned[start : end + 1])
        except json.JSONDecodeError:
            return "invalid", None
    required = {"side", "quantity", "urgency", "delay"}
    if not isinstance(value, dict) or set(value) != required:
        return "invalid_schema", None
    numeric = all(isinstance(value[key], (int, float)) and not isinstance(value[key], bool) for key in required)
    if not numeric:
        return "invalid_schema", None
    action = {
        "side": float(value["side"]),
        "quantity": float(np.clip(abs(value["quantity"]), 0.0, 2.0)),
        "urgency": float(np.clip(value["urgency"], 0.0, 1.0)),
        "delay": float(np.clip(value["delay"], 0.0, 10.0)),
    }
    strict = (
        action["side"] in (-1.0, 1.0)
        and value["side"] in (-1, 1)
        and 0.0 <= float(value["quantity"]) <= 2.0
        and 0.0 <= float(value["urgency"]) <= 1.0
        and 0.0 <= float(value["delay"]) <= 10.0
        and cleaned.startswith("{")
        and cleaned.endswith("}")
    )
    action["side"] = 1.0 if action["side"] >= 0 else -1.0
    return ("valid" if strict else "normalized"), action


def load_replay(path: Path) -> np.ndarray:
    frame = np.genfromtxt(path, delimiter=",", names=True)
    names = list(frame.dtype.names or ())
    columns = [f"obs{i}" for i in range(8)]
    if not all(column in names for column in columns):
        raise ValueError(f"replay file must contain {columns}")
    return np.column_stack([frame[column] for column in columns]).astype(float)


def run(args: argparse.Namespace) -> None:
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    args.out.mkdir(parents=True, exist_ok=True)
    if args.model_path is not None:
        model_path = args.model_path
        tokenizer = AutoTokenizer.from_pretrained(str(model_path), local_files_only=True)
        model_kwargs = {"local_files_only": True, "torch_dtype": "auto"}
        if importlib.util.find_spec("accelerate") is not None:
            model_kwargs["device_map"] = "auto"
        model = AutoModelForCausalLM.from_pretrained(str(model_path), **model_kwargs)
        if importlib.util.find_spec("accelerate") is None:
            model = model.to("cuda")
    else:
        from huggingface_hub import hf_hub_download

        model_file = hf_hub_download(
            repo_id=args.repo_id,
            filename=args.filename,
            local_dir=args.model_dir,
            local_dir_use_symlinks=False,
        )
        model_path = Path(model_file)
        tokenizer = AutoTokenizer.from_pretrained(args.repo_id, cache_dir=args.cache_dir)
        model_kwargs = {
            "gguf_file": args.filename,
            "cache_dir": args.cache_dir,
            "torch_dtype": "auto",
        }
        if importlib.util.find_spec("accelerate") is not None:
            model_kwargs["device_map"] = "auto"
        model = AutoModelForCausalLM.from_pretrained(args.repo_id, **model_kwargs)
        if importlib.util.find_spec("accelerate") is None:
            model = model.to("cuda")
    model.eval()
    replay = load_replay(args.replay)
    rows: list[dict[str, Any]] = []
    calls = 0
    for seed in args.seeds:
        for episode in range(args.episodes):
            start = (seed * 10_000 + episode * args.steps) % max(1, len(replay) - args.steps + 1)
            observations = replay[start : start + args.steps]
            for condition in args.conditions:
                for membership, state in STATE_PROFILES.items():
                    for step, observation in enumerate(observations):
                        prompt = user_prompt(observation, state, condition)
                        system = system_prompt(condition, state)
                        messages = [{"role": "system", "content": system}, {"role": "user", "content": prompt}]
                        try:
                            text = tokenizer.apply_chat_template(
                                messages, tokenize=False, add_generation_prompt=True, enable_thinking=False
                            )
                        except TypeError:
                            text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                        inputs = tokenizer(text, return_tensors="pt").to(model.device)
                        started = time.perf_counter()
                        with torch.inference_mode():
                            generated = model.generate(**inputs, max_new_tokens=64, do_sample=False)
                        latency_ms = (time.perf_counter() - started) * 1000.0
                        completion = tokenizer.decode(generated[0][inputs["input_ids"].shape[1] :], skip_special_tokens=True)
                        status, action = parse_action(completion)
                        rows.append({
                            "model": args.repo_id,
                            "filename": args.filename,
                            "seed": seed,
                            "episode": episode,
                            "step": step,
                            "condition": condition,
                            "membership": membership,
                            "parse_status": status,
                            "action": action,
                            "response_text": completion,
                            "latency_ms": latency_ms,
                        })
                        calls += 1
        print(f"completed seed {seed}", flush=True)

    (args.out / "raw_completions.jsonl").write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8"
    )
    summary: list[dict[str, Any]] = []
    for condition in args.conditions:
        subset = [row for row in rows if row["condition"] == condition]
        summary.append({
            "condition": condition,
            "calls": len(subset),
            "valid_rate": float(np.mean([row["parse_status"] == "valid" for row in subset])),
            "normalized_rate": float(np.mean([row["parse_status"] == "normalized" for row in subset])),
            "invalid_rate": float(np.mean([row["parse_status"] not in {"valid", "normalized"} for row in subset])),
            "latency_p50_ms": float(np.quantile([row["latency_ms"] for row in subset], 0.50)),
            "latency_p95_ms": float(np.quantile([row["latency_ms"] for row in subset], 0.95)),
        })
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    manifest = {
        "repo_id": args.repo_id if args.model_path is None else None,
        "filename": args.filename,
        "model_path": str(model_path),
        "model_sha256": sha256_file(model_path) if model_path.is_file() else None,
        "replay": str(args.replay),
        "replay_sha256": sha256_file(args.replay),
        "seeds": args.seeds,
        "episodes": args.episodes,
        "steps": args.steps,
        "conditions": args.conditions,
        "calls": calls,
        "device": str(model.device),
        "torch": torch.__version__,
        "python": platform.python_version(),
        "scope": "second public pretrained checkpoint; fixed interface and snapshot replay; no arbitrary-LLM or live-venue claim",
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"manifest": manifest, "summary": summary}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-id", default="Qwen/Qwen2.5-1.5B-Instruct-GGUF")
    parser.add_argument("--filename", default="qwen2.5-1.5b-instruct-q4_k_m.gguf")
    parser.add_argument("--model-path", type=Path, help="Existing local Transformers checkpoint; skips Hub download")
    parser.add_argument("--model-dir", type=Path, default=Path("models"))
    parser.add_argument("--cache-dir", type=Path, default=Path("hf_cache"))
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    parser.add_argument("--episodes", type=int, default=8)
    parser.add_argument("--steps", type=int, default=8)
    parser.add_argument("--conditions", nargs="+", choices=CONDITIONS, default=list(CONDITIONS))
    run(parser.parse_args())


if __name__ == "__main__":
    main()
