"""Canonical bounded-action parser shared by both checkpoint runners."""
from __future__ import annotations

import json
import math
import re
from typing import Any


PARSER_VERSION = "integer-side-qwen25-v1"


def json_from_text(text: str) -> dict[str, Any]:
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.I | re.S).strip()
    try:
        value = json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        if start < 0:
            raise
        depth = 0
        in_string = False
        escaped = False
        end = None
        for index in range(start, len(cleaned)):
            character = cleaned[index]
            if in_string:
                if escaped:
                    escaped = False
                elif character == "\\":
                    escaped = True
                elif character == '"':
                    in_string = False
                continue
            if character == '"':
                in_string = True
            elif character == "{":
                depth += 1
            elif character == "}":
                depth -= 1
                if depth == 0:
                    end = index
                    break
        if end is None:
            raise
        value = json.loads(cleaned[start : end + 1])
    if not isinstance(value, dict):
        raise ValueError("model output is not a JSON object")
    return value


def parse_action_fields(text: str) -> tuple[str, dict[str, float | int] | None]:
    try:
        value = json_from_text(text)
        if set(value) != {"side", "quantity", "urgency", "delay"}:
            return "invalid_schema", None
        strict_types = (
            isinstance(value["side"], int)
            and not isinstance(value["side"], bool)
            and all(
                isinstance(value[name], (int, float)) and not isinstance(value[name], bool)
                for name in ("quantity", "urgency", "delay")
            )
        )
        side_value = float(value["side"])
        quantity = float(value["quantity"])
        urgency = float(value["urgency"])
        delay = float(value["delay"])
        if not all(math.isfinite(number) for number in (side_value, quantity, urgency, delay)):
            raise ValueError("non-finite action")
        try:
            direct_json = json.loads(text.strip())
        except json.JSONDecodeError:
            direct_json = None
        strict = strict_types and isinstance(direct_json, dict)
        strict = strict and side_value in (-1.0, 1.0) and side_value.is_integer()
        strict = strict and 0.0 <= quantity <= 2.0 and 0.0 <= urgency <= 1.0 and 0.0 <= delay <= 10.0
        side = int(round(side_value))
        if side not in (-1, 1):
            side = 1 if side >= 0 else -1
        action = {
            "side": side,
            "quantity": min(max(abs(quantity), 0.0), 2.0),
            "urgency": min(max(urgency, 0.0), 1.0),
            "delay": min(max(delay, 0.0), 10.0),
        }
        return "valid" if strict else "normalized", action
    except (KeyError, TypeError, ValueError, OverflowError):
        return "invalid", None
