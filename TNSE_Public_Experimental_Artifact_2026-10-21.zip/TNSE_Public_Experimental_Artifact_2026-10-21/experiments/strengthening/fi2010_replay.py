#!/usr/bin/env python3
"""Extract a small historical FI-2010 snapshot replay.

The repository stores only this adapter and its manifest.  Raw FI-2010 files
remain outside the submission package because their provider terms should be
checked by the authors.  FI-2010 supplies normalized book snapshots; it is not
an event-level venue log and is therefore not presented as live execution.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd


SOURCE_URL = (
    "https://raw.githubusercontent.com/zcakhaa/DeepLOB-Deep-Convolutional-Neural-Networks-for-Limit-Order-Books/"
    "master/data/data.zip"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load_rows(path: Path, columns: int) -> np.ndarray:
    raw = np.loadtxt(path, dtype=np.float32, max_rows=149)
    if raw.ndim != 2 or raw.shape[0] < 45:
        raise ValueError(f"expected transposed FI-2010 matrix with >=45 rows, got {raw.shape}")
    return raw[:, :columns]


def make_snapshot_frame(raw: np.ndarray) -> pd.DataFrame:
    # The first 40 FI-2010 channels are [ask price, ask size, bid price,
    # bid size] for ten occupied levels, repeated by level.
    ask_price = raw[0:40:4]
    ask_size = raw[1:40:4]
    bid_price = raw[2:40:4]
    bid_size = raw[3:40:4]
    best_ask, best_bid = ask_price[0], bid_price[0]
    mid = (best_ask + best_bid) / 2.0
    spread = best_ask - best_bid
    imbalance = (bid_size[0] - ask_size[0]) / (bid_size[0] + ask_size[0] + 1e-8)
    depth = np.sum(ask_size + bid_size, axis=0)
    returns = np.zeros_like(mid)
    returns[1:] = np.diff(mid) / np.maximum(np.abs(mid[:-1]), 1e-8)
    volatility = pd.Series(returns).rolling(8, min_periods=1).std().fillna(0.0).to_numpy()
    elapsed = np.arange(len(mid), dtype=float) / max(1, len(mid) - 1)
    frame = pd.DataFrame(
        {
            "obs0": mid,
            "obs1": spread,
            "obs2": imbalance,
            "obs3": depth,
            "obs4": returns,
            "obs5": volatility,
            "obs6": best_ask,
            "obs7": elapsed,
        }
    )
    return frame.replace([np.inf, -np.inf], 0.0).fillna(0.0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--rows", type=int, default=240)
    parser.add_argument("--source-archive", type=Path)
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    frame = make_snapshot_frame(load_rows(args.input, max(8, args.rows)))
    frame = frame.iloc[: args.rows].copy()
    frame.to_csv(args.out, index=False)
    manifest = {
        "source_url": SOURCE_URL,
        "source_file": str(args.input),
        "source_file_sha256": sha256_file(args.input),
        "source_archive_sha256": sha256_file(args.source_archive) if args.source_archive else None,
        "rows_exported": len(frame),
        "features": list(frame.columns),
        "layout": "FI-2010 normalized 10-level snapshots; first 40 channels are price/size pairs by level",
        "split": "Test_Dst_NoAuction_DecPre_CF_7",
        "scope": "historical snapshot replay; no order IDs, venue acknowledgments, queue position, or live execution",
        "python": platform.python_version(),
    }
    manifest_path = args.out.with_name("replay_manifest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
