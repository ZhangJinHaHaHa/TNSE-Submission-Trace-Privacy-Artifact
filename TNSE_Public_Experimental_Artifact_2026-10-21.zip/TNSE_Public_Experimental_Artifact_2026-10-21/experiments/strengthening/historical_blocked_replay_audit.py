#!/usr/bin/env python3
"""Audit a historical LOBSTER message stream with contiguous blocked windows.

The audit operates only on the observable messages supplied in the existing
full-session replay archive.  It does not reconstruct a matching engine,
queue position, acknowledgements, venue latency, or an edge deployment.  Each
order's lifetime is assigned to the window containing its submission, so the
window summaries remain temporally blocked rather than mixing future events
into a feature window.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import platform
import zipfile
from collections import Counter
from pathlib import Path


WINDOWS = 8
EVENT_NAMES = {
    1: "submission",
    2: "partial_cancellation",
    3: "deletion",
    4: "visible_execution",
    5: "hidden_execution",
    7: "trading_halt",
}
TRACKED_EVENTS = {1, 2, 3, 4}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_member(bundle: zipfile.ZipFile, name: str) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with bundle.open(name, "r") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
            size += len(block)
    return digest.hexdigest(), size


def member_name(bundle: zipfile.ZipFile, suffix: str) -> str:
    matches = [name for name in bundle.namelist() if name.endswith(suffix)]
    if not matches:
        raise FileNotFoundError(f"archive has no member ending with {suffix!r}")
    if len(matches) > 1:
        raise ValueError(f"archive has multiple members ending with {suffix!r}: {matches}")
    return matches[0]


def member_row_count(bundle: zipfile.ZipFile, name: str) -> int:
    with bundle.open(name, "r") as raw:
        stream = io.TextIOWrapper(raw, encoding="utf-8", newline="")
        reader = csv.reader(stream)
        next(reader, None)
        return sum(1 for _ in reader)


def read_member_json(bundle: zipfile.ZipFile, name: str) -> dict[str, object]:
    with bundle.open(name, "r") as raw:
        return json.loads(raw.read().decode("utf-8"))


def first_last_timestamp(bundle: zipfile.ZipFile, name: str) -> tuple[int, float, float]:
    with bundle.open(name, "r") as raw:
        stream = io.TextIOWrapper(raw, encoding="utf-8", newline="")
        reader = csv.DictReader(stream)
        first = last = None
        rows = 0
        for row in reader:
            timestamp = float(row["timestamp"])
            first = timestamp if first is None else first
            last = timestamp
            rows += 1
    if rows == 0 or first is None or last is None:
        raise ValueError("replay member is empty")
    return rows, first, last


def window_for(timestamp: float, start: float, duration: float) -> int:
    if duration <= 0:
        return WINDOWS - 1
    index = int(math.floor((timestamp - start) / duration))
    return max(0, min(WINDOWS - 1, index))


def quantiles(values: list[float]) -> dict[str, float | int | None]:
    if not values:
        return {"n": 0, "mean": None, "median": None, "p95": None, "p99": None, "max": None}
    ordered = sorted(float(value) for value in values)

    def percentile(probability: float) -> float:
        position = (len(ordered) - 1) * probability
        lower = int(math.floor(position))
        upper = int(math.ceil(position))
        if lower == upper:
            return ordered[lower]
        weight = position - lower
        return ordered[lower] * (1.0 - weight) + ordered[upper] * weight

    return {
        "n": len(ordered),
        "mean": sum(ordered) / len(ordered),
        "median": percentile(0.50),
        "p95": percentile(0.95),
        "p99": percentile(0.99),
        "max": ordered[-1],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True, help="full_day_lifecycle_replay.zip")
    parser.add_argument("--out", type=Path, required=True, help="new output directory")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    archive = args.archive.resolve()
    if not archive.exists():
        raise FileNotFoundError(archive)

    with zipfile.ZipFile(archive, "r") as bundle:
        replay_name = member_name(bundle, "lobster_400390.csv")
        lifecycle_name = member_name(bundle, "lifecycle_events.csv")
        replay_manifest_name = member_name(bundle, "lobster_replay_manifest.json")
        replay_hash, replay_bytes = sha256_member(bundle, replay_name)
        lifecycle_hash, lifecycle_bytes = sha256_member(bundle, lifecycle_name)
        replay_manifest_hash, replay_manifest_bytes = sha256_member(bundle, replay_manifest_name)
        replay_manifest = read_member_json(bundle, replay_manifest_name)
        replay_rows, start_timestamp, end_timestamp = first_last_timestamp(bundle, replay_name)
        lifecycle_rows = member_row_count(bundle, lifecycle_name)

        if replay_rows != 400390:
            raise ValueError(f"expected 400390 replay rows, found {replay_rows}")
        duration = end_timestamp - start_timestamp
        window_duration = duration / WINDOWS
        event_counts = [Counter() for _ in range(WINDOWS)]
        row_counts = [0] * WINDOWS
        interarrival = [[] for _ in range(WINDOWS)]
        lifetimes = [[] for _ in range(WINDOWS)]
        terminal_counts = [Counter() for _ in range(WINDOWS)]
        mismatch_examples: list[dict[str, float | int | str]] = []
        mismatch_counts = [0] * WINDOWS
        underflow_counts = [0] * WINDOWS
        unmatched_event_counts = [0] * WINDOWS
        left_censored_counts = [Counter() for _ in range(WINDOWS)]
        post_terminal_counts = [0] * WINDOWS
        transition_matrix = [[0 for _ in range(WINDOWS)] for _ in range(WINDOWS)]
        orders: dict[int, dict[str, float | int | bool | None]] = {}
        previous_timestamp = None

        with bundle.open(replay_name, "r") as raw:
            stream = io.TextIOWrapper(raw, encoding="utf-8", newline="")
            reader = csv.DictReader(stream)
            for row_index, row in enumerate(reader):
                timestamp = float(row["timestamp"])
                event_type = int(row["event_type"])
                order_id = int(row["order_id"])
                event_size = float(row["event_size"])
                window = window_for(timestamp, start_timestamp, window_duration)
                row_counts[window] += 1
                event_name = EVENT_NAMES.get(event_type, str(event_type))
                event_counts[window][event_name] += 1
                if previous_timestamp is not None:
                    interarrival[window].append(timestamp - previous_timestamp)
                previous_timestamp = timestamp

                if order_id == 0 or event_type not in TRACKED_EVENTS:
                    continue
                if event_type == 1:
                    if order_id in orders:
                        unmatched_event_counts[window] += 1
                    orders[order_id] = {
                        "remaining": event_size,
                        "submission_timestamp": timestamp,
                        "submission_window": window,
                        "terminal_timestamp": None,
                        "terminal_window": None,
                        "terminal_event": None,
                        "closed": False,
                    }
                    continue

                order = orders.get(order_id)
                if order is None:
                    unmatched_event_counts[window] += 1
                    left_censored_counts[window][EVENT_NAMES.get(event_type, str(event_type))] += 1
                    continue
                previous_remaining = float(order["remaining"])
                if bool(order["closed"]):
                    post_terminal_counts[window] += 1
                if event_type == 3 and previous_remaining > 0 and not math.isclose(event_size, previous_remaining, rel_tol=0.0, abs_tol=1e-9):
                    mismatch_counts[window] += 1
                    if len(mismatch_examples) < 20:
                        mismatch_examples.append(
                            {
                                "row_index": row_index,
                                "window": window,
                                "order_id": order_id,
                                "timestamp": timestamp,
                                "event_size": event_size,
                                "tracked_remaining_before": previous_remaining,
                            }
                        )

                if event_type == 3:
                    new_remaining = 0.0
                else:
                    new_remaining = max(previous_remaining - event_size, 0.0)
                    if previous_remaining > 0 and event_size > previous_remaining + 1e-9:
                        underflow_counts[window] += 1
                order["remaining"] = new_remaining
                if not bool(order["closed"]) and (event_type == 3 or new_remaining <= 1e-9):
                    submission_window = int(order["submission_window"])
                    terminal_counts[submission_window]["closed"] += 1
                    transition_matrix[submission_window][window] += 1
                    lifetime = timestamp - float(order["submission_timestamp"])
                    lifetimes[submission_window].append(lifetime)
                    order["closed"] = True
                    order["terminal_timestamp"] = timestamp
                    order["terminal_window"] = window
                    order["terminal_event"] = EVENT_NAMES.get(event_type, str(event_type))

        closed_by_submission_window = [terminal_counts[index]["closed"] for index in range(WINDOWS)]
        open_by_submission_window = [0] * WINDOWS
        for order in orders.values():
            if not bool(order["closed"]):
                open_by_submission_window[int(order["submission_window"])] += 1

    window_rows: list[dict[str, object]] = []
    for index in range(WINDOWS):
        lifetime_stats = quantiles(lifetimes[index])
        interarrival_stats = quantiles(interarrival[index])
        row = {
            "window": index,
            "start_timestamp": start_timestamp + index * window_duration,
            "end_timestamp": end_timestamp if index == WINDOWS - 1 else start_timestamp + (index + 1) * window_duration,
            "rows": row_counts[index],
            "submissions": event_counts[index].get("submission", 0),
            "partial_cancellations": event_counts[index].get("partial_cancellation", 0),
            "deletions": event_counts[index].get("deletion", 0),
            "visible_executions": event_counts[index].get("visible_execution", 0),
            "hidden_executions": event_counts[index].get("hidden_execution", 0),
            "trading_halts": event_counts[index].get("trading_halt", 0),
            "closed_submissions": closed_by_submission_window[index],
            "open_submissions_at_end": open_by_submission_window[index],
            "cross_window_terminal_count": sum(
                transition_matrix[index][target] for target in range(WINDOWS) if target != index
            ),
            "interarrival_n": interarrival_stats["n"],
            "interarrival_mean_seconds": interarrival_stats["mean"],
            "interarrival_median_seconds": interarrival_stats["median"],
            "interarrival_p95_seconds": interarrival_stats["p95"],
            "interarrival_p99_seconds": interarrival_stats["p99"],
            "interarrival_max_seconds": interarrival_stats["max"],
            "lifetime_n_closed": lifetime_stats["n"],
            "lifetime_mean_seconds": lifetime_stats["mean"],
            "lifetime_median_seconds": lifetime_stats["median"],
            "lifetime_p95_seconds": lifetime_stats["p95"],
            "lifetime_p99_seconds": lifetime_stats["p99"],
            "lifetime_max_seconds": lifetime_stats["max"],
            "deletion_size_mismatch_count": mismatch_counts[index],
            "quantity_underflow_count": underflow_counts[index],
            "unmatched_order_event_count": unmatched_event_counts[index],
            "left_censored_event_count": unmatched_event_counts[index],
            "left_censored_deletions": left_censored_counts[index].get("deletion", 0),
            "left_censored_partial_cancellations": left_censored_counts[index].get("partial_cancellation", 0),
            "left_censored_visible_executions": left_censored_counts[index].get("visible_execution", 0),
            "post_terminal_event_count": post_terminal_counts[index],
        }
        window_rows.append(row)

    csv_path = args.out / "blocked_window_metrics.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(window_rows[0]))
        writer.writeheader()
        writer.writerows(window_rows)

    source_archive_hash = sha256_file(archive)
    summary = {
        "artifact": "historical_blocked_replay_audit",
        "scope": "observable historical LOBSTER message lifecycle only",
        "windowing": {
            "count": WINDOWS,
            "method": "eight contiguous equal-duration event-time windows over the full replay; lifetime statistics are assigned to the submission window",
            "start_timestamp": start_timestamp,
            "end_timestamp": end_timestamp,
            "duration_seconds": duration,
            "window_duration_seconds": window_duration,
            "blocked_temporal_split": True,
        },
        "totals": {
            "rows": replay_rows,
            "event_counts": dict(sum((counter for counter in event_counts), Counter())),
            "orders_with_submission": len(orders),
            "closed_submissions": sum(closed_by_submission_window),
            "open_submissions_at_end": sum(open_by_submission_window),
            "deletion_size_mismatch_count": sum(mismatch_counts),
            "quantity_underflow_count": sum(underflow_counts),
            "unmatched_order_event_count": sum(unmatched_event_counts),
            "left_censored_event_count": sum(unmatched_event_counts),
            "left_censored_event_counts_by_type": dict(
                sum((counter for counter in left_censored_counts), Counter())
            ),
            "post_terminal_event_count": sum(post_terminal_counts),
            "interarrival_seconds": quantiles([value for values in interarrival for value in values]),
            "closed_lifetime_seconds": quantiles([value for values in lifetimes for value in values]),
        },
        "windows": window_rows,
        "submission_to_terminal_window_matrix": transition_matrix,
        "mismatch_examples": mismatch_examples,
        "source": {
            "archive": str(archive),
            "archive_sha256": source_archive_hash,
            "upstream_source_archive_sha256": replay_manifest.get("archive_sha256"),
            "members": {
                replay_name: {"rows": replay_rows, "bytes": replay_bytes, "sha256": replay_hash},
                lifecycle_name: {"rows": lifecycle_rows, "bytes": lifecycle_bytes, "sha256": lifecycle_hash},
                replay_manifest_name: {"bytes": replay_manifest_bytes, "sha256": replay_manifest_hash},
            },
            "ticker": "AAPL",
            "date": "2012-06-21",
            "level": 10,
        },
        "limitations": [
            "No matching-engine reconstruction, queue position, acknowledgement, or order-routing inference.",
            "No live exchange, venue latency, hardware-edge, or deployment claim.",
            "Visible executions and cancellations are reported exactly as supplied by the LOBSTER message stream; the 8,381 events with no in-window submission are retained as left-censored events, and hidden executions have order_id=0 and are not assigned to an order lifetime.",
            "The two deletion-size mismatches are retained and reported rather than silently corrected.",
        ],
        "outputs": {
            "window_csv": csv_path.name,
            "metrics_json": "historical_blocked_replay_metrics.json",
            "manifest_json": "historical_blocked_replay_manifest.json",
        },
        "runtime": {"python": platform.python_version()},
    }
    metrics_path = args.out / "historical_blocked_replay_metrics.json"
    metrics_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    manifest = {
        "artifact": summary["artifact"],
        "source_archive": summary["source"],
        "rows": replay_rows,
        "blocked_windows": WINDOWS,
        "windowing": summary["windowing"],
        "scope": summary["scope"],
        "limitations": summary["limitations"],
        "outputs": summary["outputs"],
        "reproducibility": {
            "command": f"python {Path(__file__).name} --archive {args.archive} --out {args.out}",
            "source_archive_sha256": source_archive_hash,
        },
    }
    (args.out / "historical_blocked_replay_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"rows": replay_rows, "windows": WINDOWS, "mismatch_count": sum(mismatch_counts), "out": str(args.out)}, indent=2))


if __name__ == "__main__":
    main()
