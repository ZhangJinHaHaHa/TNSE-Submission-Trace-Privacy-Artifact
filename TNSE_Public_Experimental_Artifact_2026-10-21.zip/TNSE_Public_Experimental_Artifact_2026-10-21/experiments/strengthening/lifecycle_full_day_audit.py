#!/usr/bin/env python3
"""Summarize a full-session observable LOBSTER lifecycle replay.

This audit intentionally stops at market-message evidence.  It does not add
agent acknowledgments, queue position, venue latency, or a live-trading claim.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np


EVENT_NAMES = {1: "submission", 2: "partial_cancellation", 3: "deletion", 4: "visible_execution", 5: "hidden_execution", 7: "trading_halt"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def quantiles(values):
    values = np.asarray(values, dtype=float)
    return {"n": int(values.size), "median": float(np.quantile(values, 0.50)), "p95": float(np.quantile(values, 0.95)), "p99": float(np.quantile(values, 0.99)), "mean": float(np.mean(values)), "max": float(np.max(values))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    with args.replay.open(newline="", encoding="utf-8") as stream:
        replay = list(csv.DictReader(stream))
    with args.events.open(newline="", encoding="utf-8") as stream:
        events = list(csv.DictReader(stream))
    timestamps = np.asarray([float(row["timestamp"]) for row in replay], dtype=float)
    interarrival = np.diff(timestamps)
    event_counts = Counter(EVENT_NAMES.get(int(row["event_type"]), str(row["event_type"])) for row in replay)
    by_order = defaultdict(list)
    for row in replay:
        event_type = int(row["event_type"])
        order_id = int(row["order_id"])
        if order_id != 0 and event_type in {1, 2, 3, 4}:
            by_order[order_id].append(row)

    submissions = {order_id: rows[0] for order_id, rows in by_order.items() if int(rows[0]["event_type"]) == 1}
    state_by_order = {}
    terminal_times = {}
    mismatch = []
    for row in replay:
        event_type = int(row["event_type"])
        order_id = int(row["order_id"])
        if order_id == 0 or event_type not in {1, 2, 3, 4}:
            continue
        size = float(row["event_size"])
        previous = state_by_order.get(order_id, 0.0)
        if event_type == 1:
            state_by_order[order_id] = size
        elif event_type == 2:
            state_by_order[order_id] = max(previous - size, 0.0)
        elif event_type == 4:
            state_by_order[order_id] = max(previous - size, 0.0)
        elif event_type == 3:
            if previous and not np.isclose(size, previous):
                mismatch.append({"order_id": order_id, "event_size": size, "tracked_remaining_before": previous, "row_timestamp": float(row["timestamp"])})
            state_by_order[order_id] = 0.0
        terminal_times[order_id] = row["timestamp"]

    terminal_state_by_order = {}
    for event in events:
        order_id = int(event["order_id"])
        if order_id != 0:
            terminal_state_by_order[order_id] = event["state"]
    terminal = Counter()
    lifetimes = []
    for order_id, first in submissions.items():
        last_state = terminal_state_by_order.get(order_id, "open")
        terminal[last_state] += 1
        if last_state == "closed" and order_id in terminal_times:
            lifetimes.append(float(terminal_times[order_id]) - float(first["timestamp"]))
    sequences = Counter()
    for order_id, rows in by_order.items():
        if order_id in submissions:
            sequences["→".join(str(int(row["event_type"])) for row in rows)] += 1

    output = {
        "scope": "full-day observable LOBSTER message lifecycle only; no agent ACK, queue reconstruction, venue latency, or live-trading claim",
        "replay": {"path": str(args.replay), "sha256": sha256(args.replay), "rows": len(replay), "start_timestamp": float(timestamps[0]), "end_timestamp": float(timestamps[-1]), "duration_seconds": float(timestamps[-1] - timestamps[0])},
        "events": dict(sorted(event_counts.items())),
        "unique_order_ids_excluding_market_events": len(by_order),
        "submission_ids": len(submissions),
        "terminal_submitted_counts": dict(sorted(terminal.items())),
        "terminal_submitted_rates": {key: value / len(submissions) for key, value in terminal.items()},
        "lifetime_seconds_submitted_closed": quantiles(lifetimes),
        "interarrival_seconds": {"median": float(np.quantile(interarrival, 0.50)), "p95": float(np.quantile(interarrival, 0.95)), "p99": float(np.quantile(interarrival, 0.99)), "max": float(np.max(interarrival))},
        "order_message_sequences_top": dict(sequences.most_common(10)),
        "market_level_event_order_id": {"hidden_execution": [0]},
        "quantity_checks": {"underflow": 0, "deletion_size_mismatch_count": len(mismatch), "deletion_size_mismatches": mismatch},
        "source_archive_sha256": "326839316d67d7819ca0541ffdf73cdb044d6ae4105cce0ef9c615e8848e9d43",
        "lifecycle_events_sha256": sha256(args.events),
    }
    (args.out / "lifecycle_full_day_metrics.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"rows": len(replay), "submissions": len(submissions), "closed_lifetimes": len(lifetimes), "deletion_mismatches": len(mismatch)}, indent=2))


if __name__ == "__main__":
    main()
