> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Common-parser verification of retained Qwen2.5 completions

`canonical_reanalysis_2026-10-21/summary.json` verifies all 1,152 retained records
against `checkpoint_action_parser.py` (`integer-side-qwen25-v1`), now shared by
both active checkpoint runners. The strict rule preserves the original Qwen2.5
integer-side definition. All original classifications remain unchanged:
384/384 public-only, 384/384 explicit-state and 371/384 hidden-state records are
strict; the 13 remaining hidden-state records are invalid. Public-only caching
leaves 960 unique model calls. No new inference was performed.

The frozen raw completions, action rows, run metrics, manifest and counterfactual
outputs remain historical evidence. The new record-level file stores canonical
labels beside the original labels, and its manifest records all input and
source hashes. Run from the supplement root:

```bash
python3 experiments/strengthening/reanalyze_checkpoint_parsing.py
```

Qwen2.5 uses a 240-row prefix of the same LOBSTER source whose 2,000-row prefix
is used by Qwen3. Its Metal-host timing covers the local HTTP call and fallback
retry, whereas Qwen3's H20 timing covers generation only. They are retained
under their respective measured timing scopes.
