> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Three-condition checkpoint/interface rerun audit

This audit records the completed rerun that is included with this submission.
It is deliberately narrower than a claim about arbitrary LLMs or a complete
LLM trading agent.

- **Model and replay.** One quantized `Qwen2.5-3B-Instruct` GGUF checkpoint was
  served locally with `llama.cpp` 0.3.18 on Apple Metal. The checkpoint SHA-256,
  prompt hashes, replay hash, server command, context length, backend, and
  latency summary are in `manifest.json`. The replay is the 240-row AAPL
  LOBSTER prefix used by the paper.
- **Design.** The run used `public_only`, `explicit_user_state`, and
  `hidden_system_state`, with three seeds, eight episodes, and eight scheduled
  steps. It made 960 unique model calls and retained 1,152 completion/action
  rows because the public condition is cached across the two paired states.
  `raw_completions.jsonl` is the source of the parsing audit.
- **Interface behavior.** The server rejected the requested `json_schema`
  response format. The runner therefore used the explicitly recorded
  `json_object` fallback for all 960 unique calls; this is structured JSON, not
  schema-constrained decoding. The request used `max_tokens=128` and explicit
  stop sequences.
- **Validity.** Public-only and explicit-state records were strictly valid in
  all 384 records each. Hidden-state strict validity was 371/384 (96.1--97.7%
  across the three seeds); the 13 invalid records all ended with
  `finish_reason=length` and malformed/trailing text. No normalized-but-
  non-strict records occurred in this run.
- **Invalid-row policy.** Invalid rows are retained for auditability. The
  parser-inclusive CSV aggregates use the documented sentinel action
  `(+1, 0, 0, 0, 0)` only to keep row counts and downstream file schemas
  stable. Such rows are not treated as model actions and their hidden-state
  AUC must not be read as a clean model-behavior estimate.
- **State sensitivity.** Strict expected-side compliance was 0.50 for the
  explicit condition and approximately 0.480--0.488 for hidden state. The
  paired raw side difference was zero; some numeric fields changed, but the
  requested side split was not reliably followed. This is reported as a
  limitation, not as evidence of robust private-state control.
- **Counterfactual field audit.** The retained strict-valid rows are also
  paired at the same public replay, seed, episode, and step. With invalid or
  incomplete pairs excluded and complete episodes resampled, explicit-state
  raw quantity/urgency/delay changes are `+0.0573/-0.0458/+0.4065`; hidden-
  state changes are `+0.0556/-0.1253/+0.5517`. The bootstrap intervals and
  denominators are in `robust_analysis/llm_counterfactual_sensitivity/`.
  Side differences remain zero, so this audit establishes measurable numeric
  conditioning of the interface rather than reliable private-state direction
  control.

Accordingly, this artifact establishes reproducible invocation of one local
pretrained checkpoint and exposes its interface/format limitations. It does
not establish arbitrary-LLM privacy, model-training privacy, profitable
trading, live-venue execution, or edge-hardware performance.
