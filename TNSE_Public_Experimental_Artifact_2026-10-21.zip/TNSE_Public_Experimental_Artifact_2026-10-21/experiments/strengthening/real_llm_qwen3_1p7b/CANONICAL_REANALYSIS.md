> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes historical experiments, not the files currently distributed. Historical market event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs are renamed public subsets. Consult the public root README.md, PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records do not replace withheld raw evidence. Qwen2.5 public canonical parse records additionally omit canonical_action values and are not the original canonical record file; aggregate canonical summaries remain unchanged.

# Canonical parser reconciliation

Use `canonical_reanalysis_2026-10-21/summary.json` for the current reported
validity rates. The original `raw_completions.jsonl` and `summary.json` remain
unchanged; their parse labels describe the archived runner, whose source is
preserved under `../archived_checkpoint_runners_2026-10-18/`. Original manifest
and provenance copies are retained with `_archived_original` suffixes.

Both active runners now call `checkpoint_action_parser.py`, version
`integer-side-qwen25-v1`, which applies the original Qwen2.5 strict integer-side
rule. Reclassifying the same 1,152 Qwen3 completions gives:

| Condition | Strict | Normalized | Invalid |
| --- | ---: | ---: | ---: |
| Public only | 178/384 (46.35%) | 206/384 (53.65%) | 0 |
| Explicit user state | 384/384 (100%) | 0 | 0 |
| Hidden system state | 384/384 (100%) | 0 | 0 |

The historical public-only 71.35% value counted 96 floating-point `side: 1.0`
responses as strict. Those records are now normalized under the common rule.
The bounded action values do not change. The record-level reanalysis retains
both labels and source-line hashes, and its manifest binds inputs, analysis,
parser and outputs. No model calls or timing measurements were repeated.
The same reanalysis leaves all Qwen2.5 classifications unchanged: 384, 384 and
371 strict records, plus 13 hidden-state invalid records.

From the supplement root, reproduce the correction without model weights:

```bash
python3 experiments/strengthening/reanalyze_checkpoint_parsing.py
```

The two checkpoints share the AAPL 2012-06-21 10-level LOBSTER source but use
different prefixes: Qwen2.5 uses 240 rows and Qwen3 uses 2,000 rows. The corrected
Qwen3 replay path resolves relative to this directory and its SHA-256 matches
the archived value. This is not a claim of identical per-call input sequences.

Timing scopes also differ. Qwen2.5 measures a local HTTP request, including the
failed schema-format request and fallback retry; its unique-call timing omits
cached duplicates. Qwen3 measures `model.generate` and excludes tokenization
and decoding. The recorded Metal and H20 timings remain descriptive values for
their respective runs, rather than a controlled comparison of model speed.

## Recovered execution evidence

`provenance_recovery.json` records the recovered invocation environment,
path-parameterized Python arguments, historical upload/run/download events,
original download hashes, and tokenizer file inventory. The safe original
environment and argv are retained in the internal audit; the package does not
reintroduce machine-specific model paths. `CUDA_VISIBLE_DEVICES=1` explains the
model process's `cuda:0`. The physical-GPU-5 mapping was supplied by the operator
and is distinguished from the recorded H20 device inventory.

The frozen release raw file includes a reversible October 16 metadata cleanup:
the unused default GGUF `filename` was replaced by the actual `model_files`
list. Restoring only those metadata fields reproduces the byte count and SHA-256
of the original downloaded raw file. The text responses, bounded actions and
latencies are unchanged. Verify that lineage, the original summary hash, the
archived runner hash and the corrected replay path without inference:

```bash
python3 experiments/strengthening/real_llm_qwen3_1p7b/verify_archived_provenance.py
```

The `_archived_original` JSON copies preserve the pre-repair released metadata,
not an unmodified copy of the first server manifest. The upstream model URI and
revision, tokenizer hashes/revision, model file contents and complete environment
lock were not recovered. Tokenizer filenames and byte counts alone do not close
those gaps. The recovered invocation improves traceability of the actual local
checkpoint experiment without claiming a newly authenticated model source.
