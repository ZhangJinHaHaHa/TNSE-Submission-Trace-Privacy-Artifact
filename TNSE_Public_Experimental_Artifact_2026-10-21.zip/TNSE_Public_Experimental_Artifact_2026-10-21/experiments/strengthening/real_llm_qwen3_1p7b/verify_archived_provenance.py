#!/usr/bin/env python3
"""Check retained output lineage without changing files or loading a model."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


def verify(folder: Path) -> dict:
    provenance = json.loads((folder / "provenance_recovery.json").read_text())
    lineage = provenance["download_lineage"]
    raw = (folder / "raw_completions.jsonl").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == lineage["released_raw_sha256"]
    reconstructed_lines = []
    for line in raw.decode().splitlines():
        record = json.loads(line)
        reconstructed = {"model": record["model"], "filename": lineage["unused_original_filename"]}
        reconstructed.update({key: value for key, value in record.items() if key not in {"model", "model_files"}})
        reconstructed_lines.append(json.dumps(reconstructed, ensure_ascii=False) + "\n")
    reconstructed_raw = "".join(reconstructed_lines).encode()
    reconstructed_hash = hashlib.sha256(reconstructed_raw).hexdigest()
    assert len(reconstructed_raw) == lineage["original_raw_bytes"]
    assert reconstructed_hash == lineage["original_raw_sha256"]
    summary = (folder / "summary.json").read_bytes()
    assert len(summary) == lineage["original_summary_bytes"]
    assert hashlib.sha256(summary).hexdigest() == lineage["original_summary_sha256"]
    runner = folder / provenance["runner_lineage"]["archived_release_runner"]
    assert hashlib.sha256(runner.read_bytes()).hexdigest() == provenance["runner_lineage"]["archived_release_runner_sha256"]
    manifest = json.loads((folder / "manifest.json").read_text())
    replay = folder / manifest["replay"]
    assert hashlib.sha256(replay.read_bytes()).hexdigest() == manifest["replay_sha256"]
    return {
        "verified": True,
        "records": len(reconstructed_lines),
        "released_raw_sha256": hashlib.sha256(raw).hexdigest(),
        "reconstructed_original_raw_sha256": reconstructed_hash,
        "original_summary_hash_matches": True,
        "archived_runner_hash_matches": True,
        "corrected_replay_path_and_hash_match": True,
        "verification_scope": "Local output lineage against recorded historical hashes, not model-source authentication or external timestamping",
        "new_model_calls": 0,
    }


if __name__ == "__main__":
    print(json.dumps(verify(Path(__file__).resolve().parent), indent=2))
