#!/usr/bin/env python3
"""Reclassify retained checkpoint completions without model inference."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

from checkpoint_action_parser import PARSER_VERSION, parse_action_fields


CONDITIONS = ("public_only", "explicit_user_state", "hidden_system_state")
CHECKPOINTS = {
    "real_llm_lobster": {
        "model_name": "Qwen2.5-3B-Instruct-GGUF",
        "replay": "lobster_replay/lobster_replay.csv",
        "replay_rows": 240,
        "archive_summary": "manifest.json",
        "latency_scope": "local HTTP request including json_schema failure and json_object retry; cached rows excluded from unique-call timing",
        "host": "Metal/macOS",
    },
    "real_llm_qwen3_1p7b": {
        "model_name": "Qwen3-1.7B",
        "replay": "lobster_replay_2000/lobster_replay_2000.csv",
        "replay_rows": 2000,
        "archive_summary": "summary.json",
        "latency_scope": "model.generate only; excludes tokenization and decoding",
        "host": "H20 server",
    },
}


def digest(filename: Path) -> str:
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def analyze(root: Path, directory: str, output_name: str) -> dict:
    metadata = CHECKPOINTS[directory]
    checkpoint = root / directory
    source = checkpoint / "raw_completions.jsonl"
    original_summary = checkpoint / metadata["archive_summary"]
    frozen_hashes = {"raw_completions.jsonl": digest(source), metadata["archive_summary"]: digest(original_summary)}
    source_lines = source.read_text().splitlines()
    raw_records = [json.loads(line) for line in source_lines]
    identities = [tuple(record[key] for key in ("seed", "episode", "step", "condition", "membership")) for record in raw_records]
    if len(identities) != len(set(identities)):
        raise ValueError(f"Duplicate completion identity in {source}")
    records = []
    for line_number, (source_line, record) in enumerate(zip(source_lines, raw_records), 1):
        status, action = parse_action_fields(record["response_text"])
        original_action = record.get("action")
        records.append({
            "source_line": line_number,
            "source_line_sha256": hashlib.sha256(source_line.encode()).hexdigest(),
            **{key: record[key] for key in ("seed", "episode", "step", "condition", "membership")},
            "cached_public_response": record.get("cached_public_response", False),
            "archived_parse_status": record["parse_status"],
            "canonical_parse_status": status,
            "classification_changed": status != record["parse_status"],
            "canonical_action": action,
            "archived_action_present": original_action is not None,
            "bounded_action_changed": action != original_action if original_action is not None else None,
        })
    condition_summaries = []
    for condition in CONDITIONS:
        subset = [record for record in records if record["condition"] == condition]
        raw_subset = [record for record in raw_records if record["condition"] == condition]
        counts = Counter(record["canonical_parse_status"] for record in subset)
        archive_counts = Counter(record["archived_parse_status"] for record in subset)
        unique_call_latencies = [record["latency_ms"] for record in raw_subset if not record.get("cached_public_response", False)]
        condition_summaries.append({
            "condition": condition,
            "records": len(subset),
            "unique_model_calls": len(unique_call_latencies),
            "archived_status_counts": dict(sorted(archive_counts.items())),
            "canonical_status_counts": dict(sorted(counts.items())),
            "strict_valid_count": counts["valid"],
            "normalized_count": counts["normalized"],
            "invalid_count": len(subset) - counts["valid"] - counts["normalized"],
            "strict_valid_rate": counts["valid"] / len(subset),
            "normalized_rate": counts["normalized"] / len(subset),
            "classification_changes": sum(record["classification_changed"] for record in subset),
            "bounded_action_changes": sum(record["bounded_action_changed"] is True for record in subset),
            "unique_call_latency_p50_ms": quantile(unique_call_latencies, 0.50),
            "unique_call_latency_p95_ms": quantile(unique_call_latencies, 0.95),
        })
    replay = root / metadata["replay"]
    with replay.open(newline="") as stream:
        replay_rows = sum(1 for _ in csv.DictReader(stream))
    if replay_rows != metadata["replay_rows"]:
        raise ValueError(f"Unexpected replay length: {replay}")
    summary = {
        "analysis": "canonical post-hoc parsing of unchanged retained completions",
        "model_name": metadata["model_name"],
        "parser_version": PARSER_VERSION,
        "records": len(records),
        "unique_model_calls": sum(item["unique_model_calls"] for item in condition_summaries),
        "new_model_calls": 0,
        "replay_rows": replay_rows,
        "latency_scope": metadata["latency_scope"],
        "host": metadata["host"],
        "conditions": condition_summaries,
        "raw_completions_sha256": frozen_hashes["raw_completions.jsonl"],
        "archived_summary_role": "frozen historical classification; canonical rates are in this file",
    }
    output = checkpoint / output_name
    output.mkdir(exist_ok=True)
    (output / "parse_records.jsonl").write_text("".join(json.dumps(record, sort_keys=True) + "\n" for record in records))
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    manifest = {
        "analysis": "canonical-checkpoint-parsing-v1",
        "reproduction": f"python3 experiments/strengthening/reanalyze_checkpoint_parsing.py --output-name {output_name}",
        "parser_version": PARSER_VERSION,
        "strict_definition": "exact four keys; bare JSON object; side is an integer -1 or 1, not boolean/float; finite numeric quantity/urgency/delay within [0,2]/[0,1]/[0,10]",
        "frozen_input_sha256": frozen_hashes,
        "replay": f"../{metadata['replay']}",
        "replay_sha256": digest(replay),
        "replay_rows": replay_rows,
        "shared_market_source": "LOBSTER AAPL 2012-06-21 10-level sample; the two checkpoints used different prefix lengths",
        "parser_sha256": digest(root / "checkpoint_action_parser.py"),
        "analysis_script_sha256": digest(Path(__file__).resolve()),
        "archived_runner_sha256": {name: digest(root / "archived_checkpoint_runners_2026-10-18" / name) for name in ("llm_pretrained_runner.py", "hf_gguf_runner.py")},
        "output_sha256": {name: digest(output / name) for name in ("summary.json", "parse_records.jsonl")},
        "new_inference_performed": False,
    }
    for filename, expected in frozen_hashes.items():
        if digest(checkpoint / filename) != expected:
            raise ValueError(f"Frozen input changed: {filename}")
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-name", default="canonical_reanalysis_2026-10-21")
    args = parser.parse_args()
    if Path(args.output_name).name != args.output_name or args.output_name in {".", "..", ""}:
        parser.error("output-name must be one new subdirectory name")
    root = Path(__file__).resolve().parent
    print(json.dumps([analyze(root, directory, args.output_name) for directory in CHECKPOINTS], indent=2))


if __name__ == "__main__":
    main()
