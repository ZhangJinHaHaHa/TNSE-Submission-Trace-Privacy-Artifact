"""Focused regressions for the certified projection and its action-release integration."""
from __future__ import annotations

import math
import unittest
from unittest.mock import patch

from bounded_release import Config, PUBLIC_FIELDS, Session, _project_coordinates
from validate_release import boundary_counterexample_check, projection_sensitivity_checks


class NoiseProbe:
    def __init__(self, noise: float = 0.0):
        self.noise = noise
        self.laplace_scales = []
        self.gaussian_means = []

    def laplace(self, location: float, scale: float) -> float:
        self.laplace_scales.append(scale)
        return location + self.noise

    def normal(self, location: float, scale: float) -> float:
        self.gaussian_means.append(location)
        return location + self.noise


class ProjectionTests(unittest.TestCase):
    def test_default_cell_diameters(self) -> None:
        self.assertEqual(Config().projection_bounds, ((-2.0, 2.0), (0.0, 4.0), (0.0, 3.0)))

    def test_extreme_finite_inputs_project_to_certified_endpoints(self) -> None:
        cfg = Config()
        self.assertEqual(_project_coordinates(1e300, 1e300, 1e300, cfg), (2.0, 4.0, 3.0))
        self.assertEqual(_project_coordinates(-1e300, -1e300, -1e300, cfg), (-2.0, 0.0, 0.0))

    def test_smaller_public_caps_and_declared_widths_intersect(self) -> None:
        cfg = Config(qty_cap=0.5, time_cap=2.0, delta_t=0.75, delta_d=1.25)
        self.assertEqual(_project_coordinates(99.0, 99.0, 99.0, cfg), (0.5, 0.75, 1.25))

    def test_small_declared_quantity_width_still_allows_postprocessing_floor(self) -> None:
        cfg = Config(delta_q=0.1)
        self.assertEqual(_project_coordinates(99.0, 0.0, 0.0, cfg)[0], 0.05)
        self.assertEqual(cfg.qty_floor, 0.15)

    def test_boundary_adjacent_pair_regressions(self) -> None:
        rows = projection_sensitivity_checks()
        self.assertEqual(len(rows), 12)
        self.assertEqual(sum(row["ordered_pairs_checked"] for row in rows), 2028)
        self.assertTrue(all(row["projected_diameter"] <= row["declared_sensitivity"] for row in rows))

    def test_original_counterexample_fails_before_and_passes_after_projection(self) -> None:
        result = boundary_counterexample_check()
        self.assertGreater(result["former_event_inequality_excess"], result["delta"])
        self.assertLessEqual(result["repaired_event_inequality_excess"], result["delta"])
        self.assertAlmostEqual(result["former_log_likelihood_ratio"], 2.291666666666667)
        self.assertAlmostEqual(result["repaired_log_likelihood_ratio"], 0.8)

    def test_session_samples_from_the_repaired_centers(self) -> None:
        cfg = Config(slots=1, max_orders=1)
        session = Session(cfg)
        probe = NoiseProbe()
        session.rng = probe
        with patch("bounded_release.randomized_response", return_value="order"):
            result = session.step("order", {"signed_qty": 99.0, "timing_offset": 10.0, "delay": 10.0})
        self.assertEqual(tuple(result), PUBLIC_FIELDS)
        self.assertEqual((result["signed_qty"], result["timing_offset"], result["delay"]), (2.0, 4.0, 3.0))
        self.assertEqual(probe.gaussian_means, [2.0])
        self.assertEqual(probe.laplace_scales, [4.0 / 0.45, 3.0 / 0.35])
        self.assertEqual(result["eps_after"], 1.75)
        self.assertEqual(result["delta_after"], 1e-5)

    def test_post_noise_public_output_caps_are_unchanged(self) -> None:
        session = Session(Config(slots=1, max_orders=1))
        session.rng = NoiseProbe(100.0)
        with patch("bounded_release.randomized_response", return_value="order"):
            result = session.step("order", {"signed_qty": 1.0, "timing_offset": 0.0, "delay": 0.0})
        self.assertEqual((result["signed_qty"], result["timing_offset"], result["delay"]), (2.0, 10.0, 10.0))

    def test_zero_sensitivities_erase_all_raw_coordinate_differences(self) -> None:
        cfg = Config(slots=1, max_orders=1, delta_q=0.0, delta_t=0.0, delta_d=0.0)
        low = Session(cfg, seed=10)
        high = Session(cfg, seed=10)
        with patch("bounded_release.randomized_response", return_value="order"):
            low_result = low.step("order", {"signed_qty": -99.0, "timing_offset": -99.0, "delay": -99.0})
            high_result = high.step("order", {"signed_qty": 99.0, "timing_offset": 99.0, "delay": 99.0})
        self.assertEqual(low_result, high_result)
        self.assertEqual(low_result["signed_qty"], cfg.qty_floor)
        self.assertEqual((low_result["timing_offset"], low_result["delay"]), (0.0, 0.0))

    def test_every_non_order_raw_status_uses_the_same_cover_default(self) -> None:
        outputs = []
        for status in ("no-order", "reject", "budget-exhausted", "audit-failure"):
            session = Session(Config(slots=1, max_orders=1), seed=10)
            with patch("bounded_release.randomized_response", return_value="order"):
                outputs.append(session.step(status))
        self.assertTrue(all(result == outputs[0] for result in outputs))

    def test_unsupported_configurations_are_rejected(self) -> None:
        for kwargs in (
            {"delta_q": -1.0}, {"delta_t": math.inf}, {"delta": math.nan},
            {"slots": True}, {"slots": 1.5}, {"eps_scale": "1"},
            {"eps_scale": float.fromhex("0x0.0000000000001p-1022")},
            {"eps_scale": 2000.0}, {"delta": 0.5, "max_orders": 2},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                Config(**kwargs)


if __name__ == "__main__":
    unittest.main()
