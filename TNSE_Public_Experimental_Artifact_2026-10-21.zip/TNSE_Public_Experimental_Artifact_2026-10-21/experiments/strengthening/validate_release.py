#!/usr/bin/env python3
"""Validation checks for :mod:`bounded_release`.

The output is an audit of the mechanism and its public-halt boundary.  It is
not a claim that a hardware failure has been made private: a real unavailable
gateway is represented by the same public exogenous halt signal for every raw
private status, and no dummy order is generated.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
from itertools import product
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

from bounded_release import (
    Config,
    LABELS,
    PUBLIC_FIELDS,
    PublicHaltActive,
    Session,
    _project_coordinates,
    analytic_gaussian_delta,
    analytic_gaussian_sigma,
    classic_gaussian_sigma,
    randomized_response,
    randomized_response_probabilities,
)


def rr_matrix(samples: int = 10_000, seed: int = 20261008) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for scale in (0.5, 1.0, 2.0):
        cfg = Config(eps_scale=scale)
        rng = np.random.default_rng(seed + int(scale * 100))
        counts = {raw: {public: 0 for public in LABELS} for raw in LABELS}
        for raw in LABELS:
            for _ in range(samples):
                counts[raw][randomized_response(raw, rng, cfg.eps_order)] += 1
        expected_ratio = math.exp(cfg.eps_order)
        for raw in LABELS:
            exact = randomized_response_probabilities(raw, cfg.eps_order)
            if not math.isclose(exact[raw] / exact[LABELS[0] if LABELS[0] != raw else LABELS[1]], expected_ratio, rel_tol=1e-12):
                raise AssertionError("RR probability ratio is not exact")
            correct = counts[raw][raw]
            others = sum(counts[raw][label] for label in LABELS if label != raw)
            observed_ratio = correct / (others / (len(LABELS) - 1))
            if abs(observed_ratio / expected_ratio - 1.0) > 0.10:
                raise AssertionError(
                    f"RR ratio outside 10% Monte Carlo tolerance: scale={scale}, raw={raw}, "
                    f"observed={observed_ratio}, expected={expected_ratio}"
                )
            for public in LABELS:
                rows.append({
                    "eps_scale": scale,
                    "raw_status": raw,
                    "public_status": public,
                    "count": counts[raw][public],
                    "probability": counts[raw][public] / samples,
                })
    return rows


def gaussian_calibration_checks() -> list[dict[str, Any]]:
    """Verify the actual quantity calibration used for each reported scale."""
    rows: list[dict[str, Any]] = []
    for scale in (0.5, 1.0, 2.0):
        cfg = Config(eps_scale=scale)
        analytic_sigma = analytic_gaussian_sigma(cfg.eps_qty, cfg.delta, cfg.delta_q)
        classic_sigma = classic_gaussian_sigma(cfg.eps_qty, cfg.delta, cfg.delta_q)
        default_sigma = cfg.sigma_qty
        delta_at_analytic = analytic_gaussian_delta(cfg.eps_qty, analytic_sigma, cfg.delta_q)
        delta_at_default = analytic_gaussian_delta(cfg.eps_qty, default_sigma, cfg.delta_q)
        if not (math.isfinite(analytic_sigma) and math.isfinite(default_sigma)):
            raise AssertionError("Gaussian sigma is non-finite")
        if analytic_sigma < 0.0 or default_sigma < 0.0:
            raise AssertionError("Gaussian sigma is negative")
        if default_sigma + 1e-12 < max(analytic_sigma, classic_sigma):
            raise AssertionError("default sigma is not the conservative maximum")
        if delta_at_analytic > cfg.delta + 1e-12 or delta_at_default > cfg.delta + 1e-12:
            raise AssertionError("analytic Gaussian hockey-stick inequality failed")
        rows.append({
            "eps_scale": scale,
            "epsilon_qty": cfg.eps_qty,
            "target_delta": cfg.delta,
            "quantity_sensitivity": cfg.delta_q,
            "analytic_min_sigma": analytic_sigma,
            "classic_sigma": classic_sigma,
            "default_sigma_max_of_both": default_sigma,
            "hockey_stick_delta_at_analytic_sigma": delta_at_analytic,
            "hockey_stick_delta_at_default_sigma": delta_at_default,
            "verified": True,
        })
    # The kernel's public contract rejects invalid probabilities/sensitivities
    # and accepts zero only as a declared zero-sensitivity edge case.
    for kwargs in ({"delta": 0.0}, {"delta": 1.0}, {"delta": float("nan")},
                   {"delta_q": -1.0}, {"delta_t": float("inf")},
                   {"slots": float("inf")}, {"slots": 1.5},
                   {"max_orders": float("inf")}, {"max_orders": 1.5},
                   {"slots": True}, {"eps_scale": "1"},
                   {"eps_scale": float.fromhex("0x0.0000000000001p-1022")},
                   {"eps_scale": 2000.0}, {"delta": 0.5, "max_orders": 2}):
        try:
            Config(**kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError(f"invalid Config was accepted: {kwargs}")
    zero = Config(delta_q=0.0)
    if zero.sigma_qty != 0.0 or analytic_gaussian_delta(zero.eps_qty, 0.0, zero.delta_q) != 0.0:
        raise AssertionError("zero declared sensitivity was not handled as a zero-noise edge case")
    return rows


def projection_sensitivity_checks() -> list[dict[str, Any]]:
    """Check projected adjacent pairs, including zero-width cells and tighter public caps."""
    configurations = (
        ("default", Config()),
        ("smaller_public_caps", Config(qty_cap=0.5, time_cap=1.0)),
        ("smaller_declared_sensitivities", Config(delta_q=0.2, delta_t=0.5, delta_d=0.25)),
        ("zero_sensitivities", Config(delta_q=0.0, delta_t=0.0, delta_d=0.0)),
    )
    probes = (-1e6, -10.0, -4.0, -3.0, -2.0, -0.15, 0.0, 0.15, 2.0, 3.0, 4.0, 10.0, 1e6)
    rows = []
    for name, cfg in configurations:
        coordinates = (
            ("signed_qty", cfg.delta_q, cfg.eps_qty),
            ("timing_offset", cfg.delta_t, cfg.eps_time),
            ("delay", cfg.delta_d, cfg.eps_delay),
        )
        for index, (coordinate, sensitivity, epsilon) in enumerate(coordinates):
            values = []
            for probe in probes:
                raw = [0.0, 0.0, 0.0]
                raw[index] = probe
                values.append(_project_coordinates(*raw, cfg)[index])
            differences = [abs(left - right) for left, right in product(values, repeat=2)]
            diameter = max(differences)
            if diameter > sensitivity + 1e-12:
                raise AssertionError(f"{name}/{coordinate}: projected diameter exceeds its sensitivity")
            if sensitivity == 0.0 and any(value != 0.0 for value in values):
                raise AssertionError("zero-sensitivity projection must be independent of raw input")
            if coordinate == "signed_qty":
                achieved_delta = analytic_gaussian_delta(epsilon, cfg.sigma_qty, diameter)
                if achieved_delta > cfg.delta + 1e-12:
                    raise AssertionError("projected quantity diameter invalidates Gaussian calibration")
                maximum_laplace_log_ratio = None
            else:
                achieved_delta = 0.0
                maximum_laplace_log_ratio = diameter / (sensitivity / epsilon) if sensitivity else 0.0
                if maximum_laplace_log_ratio > epsilon + 1e-12:
                    raise AssertionError("projected Laplace means exceed the declared pure-DP allocation")
            rows.append({
                "configuration": name,
                "coordinate": coordinate,
                "declared_sensitivity": sensitivity,
                "projected_minimum": min(values),
                "projected_maximum": max(values),
                "projected_diameter": diameter,
                "ordered_pairs_checked": len(differences),
                "epsilon": epsilon,
                "maximum_laplace_log_ratio": maximum_laplace_log_ratio,
                "gaussian_hockey_stick_delta": achieved_delta,
                "verified": True,
            })
    return rows


def boundary_counterexample_check() -> dict[str, Any]:
    """Recheck the exact zero-output event that exposed the former timing/delay mismatch."""
    cfg = Config(slots=1, max_orders=1)
    projected_low = _project_coordinates(0.0, 0.0, 0.0, cfg)
    projected_high = _project_coordinates(0.0, 10.0, 10.0, cfg)
    order_probability = randomized_response_probabilities("order", cfg.eps_order)["order"]
    probability_low = order_probability / 4.0
    former_log_ratio = 10.0 * cfg.eps_time / cfg.delta_t + 10.0 * cfg.eps_delay / cfg.delta_d
    repaired_log_ratio = (
        (projected_high[1] - projected_low[1]) * cfg.eps_time / cfg.delta_t
        + (projected_high[2] - projected_low[2]) * cfg.eps_delay / cfg.delta_d
    )
    former_probability_high = probability_low * math.exp(-former_log_ratio)
    repaired_probability_high = probability_low * math.exp(-repaired_log_ratio)
    former_excess = probability_low - math.exp(cfg.epsilon_cap) * former_probability_high
    repaired_excess = probability_low - math.exp(cfg.epsilon_cap) * repaired_probability_high
    if former_excess <= cfg.delta or repaired_excess > cfg.delta:
        raise AssertionError("the original adjacent-pair counterexample is not resolved")
    return {
        "event": "final order and released timing_offset = 0 and released delay = 0",
        "raw_low": [0.0, 0.0, 0.0],
        "raw_high": [0.0, 10.0, 10.0],
        "projected_low_quantity_time_delay": list(projected_low),
        "projected_high_quantity_time_delay": list(projected_high),
        "epsilon": cfg.epsilon_cap,
        "delta": cfg.delta,
        "probability_low": probability_low,
        "former_probability_high": former_probability_high,
        "repaired_probability_high": repaired_probability_high,
        "former_log_likelihood_ratio": former_log_ratio,
        "repaired_log_likelihood_ratio": repaired_log_ratio,
        "former_event_inequality_excess": former_excess,
        "repaired_event_inequality_excess": repaired_excess,
        "verified": True,
        "scope": "An exact regression for this event; not a numerical proof of the full ETI guarantee.",
    }


def session_invariants(seed: int, scale: float) -> dict[str, Any]:
    cfg = Config(eps_scale=scale)
    session = Session(cfg, seed=seed)
    raw_statuses = ("no-order", "order", "reject", "order", "audit-failure", "order", "budget-exhausted", "order")
    raw_actions = {"signed_qty": 99.0, "timing_offset": -4.0, "delay": 99.0}
    public_rows = []
    for slot, raw in enumerate(raw_statuses):
        result = session.step(raw, raw_actions if raw == "order" else None, slot)
        if tuple(result) != PUBLIC_FIELDS:
            raise AssertionError(f"public schema changed: {tuple(result)}")
        if result["eps_after"] > cfg.epsilon_cap + 1e-12 or result["delta_after"] > cfg.delta_cap + 1e-12:
            raise AssertionError("privacy budget cap exceeded")
        if result["status"] == "order":
            if not (-cfg.qty_cap - 1e-12 <= result["signed_qty"] <= cfg.qty_cap + 1e-12):
                raise AssertionError("quantity cap exceeded")
            if abs(result["signed_qty"]) < cfg.qty_floor - 1e-12:
                raise AssertionError("quantity floor violated")
            if not (0.0 <= result["timing_offset"] <= cfg.time_cap):
                raise AssertionError("timing cap violated")
            if not (0.0 <= result["delay"] <= cfg.time_cap):
                raise AssertionError("delay cap violated")
        public_rows.append(result)
    diagnostic = session.diagnostics
    if diagnostic["release_count"] > cfg.max_orders:
        raise AssertionError("max_orders exceeded")
    if diagnostic["cover_release_count"] < 0 or diagnostic["projected_release_count"] < 0:
        raise AssertionError("diagnostic count invalid")
    return {
        "seed": seed,
        "eps_scale": scale,
        "public_rows": len(public_rows),
        "release_count": diagnostic["release_count"],
        "cover_release_count": diagnostic["cover_release_count"],
        "projected_release_count": diagnostic["projected_release_count"],
        "epsilon_cap": cfg.epsilon_cap,
        "delta_cap": cfg.delta_cap,
        "epsilon_realized": diagnostic["eps_after"],
        "delta_realized": diagnostic["delta_after"],
    }


def halt_boundary_test() -> dict[str, Any]:
    receipts = []
    halted = 0
    for index, raw in enumerate(LABELS):
        session = Session(Config(), seed=100 + index)
        receipt = session.halt_from_public_signal(0, "gateway-unavailable")
        receipts.append(receipt)
        try:
            session.step(raw, {"signed_qty": 1.0, "timing_offset": 0.0, "delay": 0.0} if raw == "order" else None, 0)
        except PublicHaltActive:
            halted += 1
        else:
            raise AssertionError("a halted session emitted a release")
        if session.diagnostics["release_count"] != 0:
            raise AssertionError("halt path submitted or counted an order")
    if len({json.dumps(receipt, sort_keys=True) for receipt in receipts}) != 1:
        raise AssertionError("public exogenous halt was not status-independent")
    return {"statuses_tested": len(LABELS), "halted_sessions": halted, "orders_submitted": 0, "receipt": receipts[0]}


def validate(output: Path, samples: int = 10_000) -> dict[str, Any]:
    matrix = rr_matrix(samples=samples)
    gaussian_rows = gaussian_calibration_checks()
    projection_rows = projection_sensitivity_checks()
    counterexample = boundary_counterexample_check()
    invariant_rows = [session_invariants(seed, scale) for scale in (0.5, 1.0, 2.0) for seed in range(8)]
    halt = halt_boundary_test()
    summary = {
        "validated": True,
        "rr_samples_per_status_scale": samples,
        "rr_rows": len(matrix),
        "rr_ratio_exact_algebra": True,
        "scales": [0.5, 1.0, 2.0],
        "gaussian_calibration": {
            "method": "exact one-dimensional analytic Gaussian hockey-stick inequality",
            "default_sigma_rule": "max(classic positive sigma, analytic minimum sigma)",
            "verified_parameters": gaussian_rows,
            "invalid_parameter_checks": "reject non-finite/negative sensitivities and delta outside (0,1)",
        },
        "status_labels": list(LABELS),
        "public_fields": list(PUBLIC_FIELDS),
        "session_invariant_runs": len(invariant_rows),
        "session_invariants": invariant_rows,
        "projection_sensitivity": {
            "coordinate_checks": len(projection_rows),
            "ordered_adjacent_pairs_checked": sum(row["ordered_pairs_checked"] for row in projection_rows),
            "default_quantity_time_delay_diameters": [4.0, 4.0, 3.0],
            "verified_parameters": projection_rows,
        },
        "adjacent_boundary_regression": counterexample,
        "source_sha256": {
            filename: hashlib.sha256(Path(__file__).with_name(filename).read_bytes()).hexdigest()
            for filename in ("bounded_release.py", "validate_release.py", "test_bounded_release.py")
        },
        "public_halt_boundary": halt,
        "interpretation": (
            "The five-way audit-failure token is a randomized status cell. "
            "An actual unavailable gateway is represented by a public exogenous halt; "
            "the halt path emits no dummy or cover order. The projection and exact-event checks "
            "are regression evidence for the declared cells, not a computational proof of full DP."
        ),
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (output / "rr_matrix.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(matrix[0]))
        writer.writeheader()
        writer.writerows(matrix)
    with (output / "gaussian_calibration.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(gaussian_rows[0]))
        writer.writeheader()
        writer.writerows(gaussian_rows)
    with (output / "session_invariants.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(invariant_rows[0]))
        writer.writeheader()
        writer.writerows(invariant_rows)
    with (output / "projection_sensitivity.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(projection_rows[0]))
        writer.writeheader()
        writer.writerows(projection_rows)
    (output / "adjacent_boundary_regression.json").write_text(json.dumps(counterexample, indent=2) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "results" / "release_validation_projection_repair_2026-10-21")
    parser.add_argument("--samples", type=int, default=10_000)
    args = parser.parse_args()
    if args.samples < 1_000:
        raise SystemExit("--samples must be at least 1000 for the stochastic ratio check")
    print(json.dumps(validate(args.out, args.samples), indent=2))


if __name__ == "__main__":
    main()
