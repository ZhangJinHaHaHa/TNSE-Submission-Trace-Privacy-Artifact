#!/usr/bin/env python3
"""Verify the exported *complete* synthetic slot ledger, not just its first 20 entries.

The local receipt is not an independently trusted timestamp or external anchor.
This tool checks internal integrity and budget consistency given the supplied
public key and receipt. It cannot establish honesty of the key holder or the
truth of the declared sensitivity certificate.
"""
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

EPS_MAX, DELTA_MAX = 28.5, 7e-5
LABELS = {'order', 'no-order', 'reject', 'budget-exhausted', 'audit-failure'}


def verify_export(folder: Path) -> dict:
    receipt = json.loads((folder / 'anchor_receipt.json').read_text())
    pub = Ed25519PublicKey.from_public_bytes(bytes.fromhex(receipt['public_key_ed25519']))
    head = '0' * 64
    spent: dict[tuple[int, int], tuple[float, float, int]] = {}
    count = accepted = 0
    with (folder / 'ledger_full.jsonl').open() as f, \
         (folder / 'disposition_events_public.jsonl').open() as public_f:
        for line in f:
            entry = json.loads(line)
            assert entry['signature_alg'] == 'Ed25519'
            record = {k: v for k, v in entry.items()
                      if k not in ('signature', 'signature_alg', 'entry_hash')}
            assert 'raw_status' not in record, 'secret-dependent raw status in public ledger'
            assert entry['certificate'] == 'cert-v2'
            assert entry['record_type'] == 'scheduled-slot'
            public_event = json.loads(next(public_f))
            assert set(public_event) == {'seed','episode','ts','final_status'}
            assert (public_event['seed'],public_event['episode'],public_event['ts'],public_event['final_status']) == \
                   (entry['seed'],entry['episode'],entry['ts'],entry['status'])
            payload = json.dumps(record, sort_keys=True, separators=(',', ':')).encode()
            pub.verify(bytes.fromhex(entry['signature']), payload)
            assert entry['prev_hash'] == head, 'broken hash chain'
            head = hashlib.sha256((head + entry['signature']).encode() + payload).hexdigest()
            assert entry['entry_hash'] == head, 'wrong record hash'
            key = (entry['seed'], entry['episode'])
            eps, delta, next_slot = spent.get(key, (0.0, 0.0, 0))
            assert entry['ts'] == next_slot, 'omitted, duplicated, or out-of-order slot'
            assert entry['status'] in LABELS
            inc = entry['eps_increment']
            dinc = entry['delta_increment']
            assert inc in (0.0, .25, 1.75), 'unaccounted slot expenditure'
            assert dinc in (0.0, 1e-5)
            if inc == 0.0:
                assert entry['status'] == 'budget-exhausted'
            assert (inc == 1.75) == (entry['status'] == 'order')
            assert (dinc == 1e-5) == (entry['status'] == 'order')
            assert abs(eps + inc - entry['eps_after']) < 1e-7
            assert abs(delta + dinc - entry['delta_after']) < 1e-10
            eps += inc
            delta += dinc
            assert eps <= EPS_MAX + 1e-7 and delta <= DELTA_MAX + 1e-10
            spent[key] = (eps, delta, next_slot + 1)
            accepted += int(entry['status'] == 'order')
            count += 1
        assert not public_f.readline(), 'unsigned extra public status'
    assert head == receipt['head'], 'full log does not match supplied receipt'
    assert count == receipt['expected_scheduled_events']
    assert all(t == 72 for _, _, t in spent.values())
    assert len(spent) == 800
    return {'verified': True, 'entries': count, 'accepted_releases': accepted,
            'sessions': len(spent), 'head': head, 'receipt_scope': receipt['anchor_scope']}


if __name__ == '__main__':
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent / 'results' / 'revised_protocol'
    print(json.dumps(verify_export(folder), indent=2))
