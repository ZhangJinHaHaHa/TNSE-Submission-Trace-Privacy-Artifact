HISTORICAL SOURCE-SUBMISSION INVENTORIES ONLY
These three original files are retained byte-for-byte for provenance. They describe the full frozen source submission, including deliberately omitted data.
Do not run the SHA256SUMS.txt here as the public artifact's verification list. Use the root PUBLIC_FILE_INVENTORY.csv and SHA256SUMS.txt instead.
