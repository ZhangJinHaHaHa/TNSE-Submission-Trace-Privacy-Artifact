#!/usr/bin/env python3
"""Build an explicitly partial public artifact without changing its source ZIP."""
from __future__ import annotations

import argparse
import csv
import io
import json
import platform
import stat
import zipfile
import zlib
from pathlib import Path, PurePosixPath

from verify_public_release import archive_files, sha256, verify_files


SOURCE_ROOT = "TNSE_Revised_Supplement/"
PUBLIC_ROOT = "TNSE_Public_Experimental_Artifact_2026-10-21"
EXPECTED_SOURCE_SHA256 = "dd458539d71937625c123e9d54b752898c5c7ba60b23aca3b2e82c67943c1554"
DATE = "2026-10-21"
FIXED_ZIP_TIME = (2026, 10, 21, 0, 0, 0)
STRENGTHENING = "experiments/strengthening/"
PHYSICAL = "experiments/physical_edge/"
EXCLUDED_FILES = {
    STRENGTHENING + "lobster_replay/lobster_replay.csv": "Historical message fields and order-book observations (240-row prefix).",
    STRENGTHENING + "lobster_replay_2000/lobster_replay_2000.csv": "Historical message fields and order-book observations (2000-row prefix).",
    STRENGTHENING + "lobster_replay_2000/lifecycle_events.csv": "Historical per-event lifecycle records.",
    STRENGTHENING + "exchange_lifecycle/results/exchange_lifecycle_events.csv": "Mixed historical-derived and constructed exchange-event trace; safe scenario-only records remain separately.",
    STRENGTHENING + "real_llm_lobster/raw_completions.jsonl": "Historical observations in prompts and some response echoes; entire raw-text file withheld.",
    STRENGTHENING + "real_llm_lobster/raw_completion_samples.jsonl": "Historical observations in sampled request prompts; entire sample file withheld.",
    STRENGTHENING + "real_llm_lobster/action_rows.csv": "Per-record Qwen2.5 action values include numeric matches to historical observation components; withheld conservatively without asserting every match proves copying.",
    PHYSICAL + "source_package/strengthening/lobster_replay_2000/lobster_replay_2000.csv": "Duplicate historical 2000-row replay used by the board source package.",
}
NESTED_RULES = {
    PHYSICAL + "TNSE_Edge_Board_Results_20261017T190612Z.zip": {
        "output": PHYSICAL + "TNSE_Edge_Board_Results_20261017T190612Z_PUBLIC_SUBSET.zip",
        "excluded": {"observable_lifecycle.csv", "lifecycle_replay/exchange_lifecycle_events.csv"},
        "renamed": {"results_manifest.json": "HISTORICAL_SOURCE_results_manifest.json"},
    },
    STRENGTHENING + "lobster_replay_full_day/full_day_lifecycle_replay.zip": {
        "output": STRENGTHENING + "lobster_replay_full_day/full_day_lifecycle_metadata_PUBLIC_SUBSET.zip",
        "excluded": {"lobster_400390.csv", "lifecycle_events.csv"},
        "renamed": {},
    },
}
ARCHIVED_INDEXES = {"EXPERIMENT_INVENTORY.csv", "EXPERIMENT_INVENTORY.md", "SHA256SUMS.txt"}
NOTICE = (
    "> PUBLIC SUBSET NOTICE (2026-10-21): This retained submission document describes "
    "historical experiments, not the files currently distributed. Historical market "
    "event data and observation-bearing Qwen2.5 raw text are excluded. Nested ZIPs "
    "are renamed public subsets. Consult the public root README.md, "
    "PUBLIC_CHANGELOG.json and current PUBLIC_FILE_INVENTORY.csv; canonical records "
    "do not replace withheld raw evidence. Qwen2.5 public canonical parse records "
    "additionally omit canonical_action values and are not the original canonical "
    "record file; aggregate canonical summaries remain unchanged.\n\n"
)


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")


def csv_bytes(rows: list[dict], columns: list[str]) -> bytes:
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue().encode("utf-8")


def zip_bytes(files: dict[str, bytes], prefix: str = "") -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, payload in sorted(files.items()):
            member = zipfile.ZipInfo(prefix + name, FIXED_ZIP_TIME)
            member.compress_type = zipfile.ZIP_DEFLATED
            member.create_system = 3
            mode = 0o755 if name.endswith(".sh") else 0o644
            member.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(member, payload, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return buffer.getvalue()


def with_inventory(files: dict[str, bytes], origins: dict[str, str]) -> dict[str, bytes]:
    result = dict(files)
    if {"PUBLIC_FILE_INVENTORY.csv", "SHA256SUMS.txt"} & result.keys():
        raise ValueError("Inventory output already exists")
    rows = [
        {"path": name, "bytes": len(payload), "sha256": sha256(payload), "role": origins.get(name, "new_public_release_metadata")}
        for name, payload in sorted(result.items())
    ]
    result["PUBLIC_FILE_INVENTORY.csv"] = csv_bytes(rows, ["path", "bytes", "sha256", "role"])
    result["SHA256SUMS.txt"] = "".join(
        f"{sha256(payload)}  {name}\n" for name, payload in sorted(result.items())
    ).encode("utf-8")
    return result


def is_historical_metadata(name: str, payload: bytes) -> bool:
    lowered = PurePosixPath(name).name.lower()
    if any(token in lowered for token in ("manifest", "provenance", "frozen_event_audit", "lineage_check")):
        return True
    if name.endswith(".json"):
        return b"sha256" in payload or b"replay_file" in payload
    return name in ARCHIVED_INDEXES


def build(source_payload: bytes, source_name: str, tools_dir: Path) -> tuple[dict[str, bytes], dict]:
    if sha256(source_payload) != EXPECTED_SOURCE_SHA256:
        raise ValueError("Source ZIP does not match the audited frozen submission SHA-256")
    source_full = archive_files(source_payload)
    if any(not name.startswith(SOURCE_ROOT) for name in source_full):
        raise ValueError("Unexpected source ZIP root")
    source = {name[len(SOURCE_ROOT):]: payload for name, payload in source_full.items()}
    required = set(EXCLUDED_FILES) | set(NESTED_RULES) | ARCHIVED_INDEXES
    if not required <= source.keys():
        raise ValueError(f"Expected source files missing: {sorted(required - source.keys())}")
    result = {}
    origins = {}
    changes = []
    historical_metadata = []

    def record(operation: str, name: str, reason: str, payload: bytes | None = None, output: str | None = None, **details: object) -> None:
        item = {"operation": operation, "source_path": name, "reason": reason, **details}
        if payload is not None:
            item.update({"source_sha256": sha256(payload), "source_bytes": len(payload)})
        if output is not None:
            item["public_path"] = output
        changes.append(item)

    for name, payload in sorted(source.items()):
        if name in EXCLUDED_FILES:
            record("excluded", name, EXCLUDED_FILES[name], payload)
            continue
        if name in NESTED_RULES:
            rule = NESTED_RULES[name]
            old_members = archive_files(payload)
            if not rule["excluded"] <= old_members.keys():
                raise ValueError(f"Expected nested exclusions missing: {name}")
            kept = {}
            nested_origins = {}
            for member_name, member_payload in sorted(old_members.items()):
                location = name + "!/" + member_name
                if member_name in rule["excluded"]:
                    record("excluded_nested_member", location, "Historical per-event data omitted from public nested subset.", member_payload)
                    continue
                target_member = rule["renamed"].get(member_name, member_name)
                kept[target_member] = member_payload
                nested_origins[target_member] = "historical_source_metadata" if is_historical_metadata(member_name, member_payload) else "unchanged_historical_payload"
                if target_member != member_name:
                    record("relocated_nested_metadata", location, "Renamed historical source inventory; it is not the current subset inventory.", member_payload, rule["output"] + "!/" + target_member)
                if is_historical_metadata(member_name, member_payload):
                    historical_metadata.append({"source_path": location, "public_path": rule["output"] + "!/" + target_member, "source_sha256": sha256(member_payload), "scope": "Historical source metadata, not this public subset's inventory."})
            kept["README_PUBLIC_SUBSET.txt"] = (
                "PUBLIC SUBSET, NOT THE FROZEN SOURCE ARCHIVE\n"
                f"Source archive path: {name}\nSource SHA-256: {sha256(payload)}\n"
                "Historical event data were removed. Retained original manifests describe the historical run, including omitted files; they are not this subset's inventory.\n"
                "Use PUBLIC_FILE_INVENTORY.csv and SHA256SUMS.txt for actual current members. The inventory excludes itself/checksums; checksums cover everything except themselves.\n"
                "No experimental results were rerun. Source and output archive hashes are intentionally different. See the outer PUBLIC_CHANGELOG.json for each omitted/relocated member.\n"
            ).encode("utf-8")
            kept = with_inventory(kept, nested_origins)
            target = rule["output"]
            result[target] = zip_bytes(kept)
            origins[target] = "rebuilt_public_nested_subset"
            record("rebuilt_nested_archive", name, "Safe payloads retained; historical event members removed; current nested inventory/checksums and scope notice added.", payload, target, excluded_member_count=len(rule["excluded"]), public_member_count=len(kept), public_sha256=sha256(result[target]))
            continue
        target = name
        output_payload = payload
        role = "unchanged_historical_payload"
        if name in ARCHIVED_INDEXES:
            target = "historical_submission_manifests/" + name
            role = "historical_source_metadata"
            record("relocated_historical_inventory", name, "Original source-submission inventory retained byte-for-byte, explicitly outside the current verification entrypoints.", payload, target)
        elif name == STRENGTHENING + "lobster_replay_full_day/lifecycle_full_day_metrics.json":
            data = json.loads(payload)
            examples = data["quantity_checks"].pop("deletion_size_mismatches")
            if len(examples) != data["quantity_checks"]["deletion_size_mismatch_count"]:
                raise ValueError("Full-day mismatch count differs from omitted example count")
            data["public_release_redaction"] = {"field_omitted": "quantity_checks.deletion_size_mismatches", "example_count": len(examples), "aggregate_counts_unchanged": True, "reason": "Historical event-level examples withheld from public distribution."}
            output_payload = json_bytes(data)
            role = "public_summary_event_examples_removed"
            record("redacted_summary_field", name, "Removed event-level mismatch examples; retained all aggregate counts and summary statistics.", payload, target, field="quantity_checks.deletion_size_mismatches", removed_example_count=len(examples))
        elif name == STRENGTHENING + "historical_blocked_replay/historical_blocked_replay_metrics.json":
            data = json.loads(payload)
            examples = data.pop("mismatch_examples")
            if len(examples) != data["totals"]["deletion_size_mismatch_count"]:
                raise ValueError("Blocked mismatch count differs from omitted example count")
            data["public_release_redaction"] = {"field_omitted": "mismatch_examples", "example_count": len(examples), "aggregate_counts_unchanged": True, "reason": "Historical event-level examples withheld; retained source hashes identify the non-public historical evidence."}
            data["limitations"].append("The public subset retains mismatch counts but omits the event-level examples present in the frozen source submission.")
            output_payload = json_bytes(data)
            role = "public_summary_event_examples_removed"
            record("redacted_summary_field", name, "Removed event-level mismatch examples and added scope clarification; aggregate results unchanged.", payload, target, field="mismatch_examples", removed_example_count=len(examples))
        elif name == STRENGTHENING + "real_llm_lobster/canonical_reanalysis_2026-10-21/parse_records.jsonl":
            records = [json.loads(line) for line in payload.decode("utf-8").splitlines()]
            if len(records) != 1152 or any("canonical_action" not in row for row in records):
                raise ValueError("Unexpected Qwen2.5 canonical record schema/count")
            for row in records:
                row.pop("canonical_action")
                row["public_record_variant"] = "canonical_action_values_withheld"
            output_payload = "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in records).encode("utf-8")
            role = "public_derivative_canonical_decisions_without_action_values"
            record("redacted_canonical_action_values", name, "Public derivative, not the frozen original canonical record file: action values removed to avoid observation-component fragments; all other original decisions, hashes and metadata retained.", payload, target, field="canonical_action", records=1152, aggregate_summary_unchanged=True)
        elif name.endswith(".md") or PurePosixPath(name).name.startswith("README") or name == "REPAIR_INDEX.txt":
            output_payload = NOTICE.encode("utf-8") + payload
            role = "historical_document_with_public_scope_notice"
            record("prepended_public_scope_notice", name, "Historical document content retained; prominent public-subset notice added to prevent completeness or old-path assumptions.", payload, target)
        if is_historical_metadata(name, payload):
            historical_metadata.append({"source_path": name, "public_path": target, "source_sha256": sha256(payload), "scope": "Historical source metadata, not the current public-file inventory."})
            if role == "unchanged_historical_payload":
                role = "historical_source_metadata"
        result[target] = output_payload
        origins[target] = role

    added = {
        "README.md": (tools_dir / "README_PUBLIC.md").read_bytes(),
        "PUBLIC_REBUILD_INSTRUCTIONS.md": (tools_dir / "PUBLIC_REBUILD_INSTRUCTIONS.md").read_bytes(),
        "public_release_tools/README_PUBLIC.md": (tools_dir / "README_PUBLIC.md").read_bytes(),
        "public_release_tools/PUBLIC_REBUILD_INSTRUCTIONS.md": (tools_dir / "PUBLIC_REBUILD_INSTRUCTIONS.md").read_bytes(),
        "public_release_tools/build_public_release.py": (tools_dir / "build_public_release.py").read_bytes(),
        "public_release_tools/verify_public_release.py": (tools_dir / "verify_public_release.py").read_bytes(),
        "historical_submission_manifests/README.txt": (
            "HISTORICAL SOURCE-SUBMISSION INVENTORIES ONLY\n"
            "These three original files are retained byte-for-byte for provenance. They describe the full frozen source submission, including deliberately omitted data.\n"
            "Do not run the SHA256SUMS.txt here as the public artifact's verification list. Use the root PUBLIC_FILE_INVENTORY.csv and SHA256SUMS.txt instead.\n"
        ).encode("utf-8"),
        "SOURCE_ARCHIVE.json": json_bytes({"schema": "tnse-public-source-archive-v1", "source_filename": source_name, "source_sha256": sha256(source_payload), "source_bytes": len(source_payload), "source_root": SOURCE_ROOT, "public_root": PUBLIC_ROOT, "release_date": DATE, "source_unchanged": True, "new_experimental_execution": False, "public_subset_not_complete_submission": True, "no_new_license_grant": True}),
        "HISTORICAL_METADATA_INDEX.csv": csv_bytes(historical_metadata, ["source_path", "public_path", "source_sha256", "scope"]),
    }
    for name in sorted(added):
        record("added", name, "New public-release documentation, provenance, metadata index, or packaging/verification tool.", output=name)
    for name in ["PUBLIC_CHANGELOG.json", "PUBLIC_FILE_INVENTORY.csv", "SHA256SUMS.txt"]:
        record("added", name, "New current public change/inventory/checksum record; not a historical experiment result.", output=name)
    added["PUBLIC_CHANGELOG.json"] = json_bytes({"schema": "tnse-public-transformations-v1", "source_sha256": sha256(source_payload), "release_date": DATE, "records_do_not_contain_excluded_original_values": True, "unchanged_files": "See inventory roles; all author .py/.sh code and canonical summaries remain byte-identical to the source ZIP. Qwen2.5 parse records are a marked public derivative without action values.", "changes": changes})
    if result.keys() & added.keys():
        raise ValueError("Generated public files collide with retained files")
    result.update(added)
    result = with_inventory(result, origins)
    for name, payload in source.items():
        if name.endswith((".py", ".sh")) and result.get(name) != payload:
            raise ValueError(f"Author source changed: {name}")
        redacted_canonical = STRENGTHENING + "real_llm_lobster/canonical_reanalysis_2026-10-21/parse_records.jsonl"
        if "/canonical_reanalysis_2026-10-21/" in name and name != redacted_canonical and result.get(name) != payload:
            raise ValueError(f"Canonical analysis changed: {name}")
        if name.endswith(".jpg") and result.get(name) != payload:
            raise ValueError(f"Operator photo changed: {name}")
    if set(EXCLUDED_FILES) & result.keys() or set(NESTED_RULES) & result.keys():
        raise ValueError("An excluded source path survived")
    verification = verify_files(result, PUBLIC_ROOT)
    return result, {"verification": verification, "source_entries": len(source), "operations": len(changes), "historical_metadata_records": len(historical_metadata)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-zip", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    source_path = args.source_zip.resolve()
    output_dir = args.output_dir.resolve()
    if source_path == output_dir or source_path.is_relative_to(output_dir / PUBLIC_ROOT):
        raise ValueError("Source ZIP must remain outside the output tree")
    output_dir.mkdir(parents=True, exist_ok=True)
    root = output_dir / PUBLIC_ROOT
    archive_path = output_dir / (PUBLIC_ROOT + ".zip")
    report_path = output_dir / "PUBLIC_BUILD_REPORT.json"
    archive_checksum = output_dir / (PUBLIC_ROOT + ".zip.sha256")
    if any(path.exists() for path in (root, archive_path, report_path, archive_checksum)):
        raise ValueError("Use a fresh output directory; this builder does not overwrite prior public artifacts")
    source_payload = source_path.read_bytes()
    files, audit = build(source_payload, source_path.name, Path(__file__).resolve().parent)
    for name, payload in files.items():
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        if name.endswith(".sh"):
            target.chmod(0o755)
    archive_payload = zip_bytes(files, PUBLIC_ROOT + "/")
    archive_path.write_bytes(archive_payload)
    if sha256(source_path.read_bytes()) != EXPECTED_SOURCE_SHA256:
        raise ValueError("Source archive changed during build")
    archive_checksum.write_text(f"{sha256(archive_payload)}  {archive_path.name}\n", encoding="utf-8")
    report = {"schema": "tnse-public-build-report-v1", "source_sha256": EXPECTED_SOURCE_SHA256, "public_archive": str(archive_path), "public_archive_sha256": sha256(archive_payload), "public_archive_bytes": len(archive_payload), "source_unchanged_after_build": True, "python": platform.python_version(), "zlib_compile_version": zlib.ZLIB_VERSION, "zlib_runtime_version": zlib.ZLIB_RUNTIME_VERSION, "builder_sha256": sha256(Path(__file__).read_bytes()), **audit}
    report_path.write_bytes(json_bytes(report))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
