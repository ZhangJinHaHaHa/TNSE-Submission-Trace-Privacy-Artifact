#!/usr/bin/env python3
"""Verify exact public-file coverage, digests, and nested subset inventories."""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import zipfile
from pathlib import Path, PurePosixPath


INVENTORY = "PUBLIC_FILE_INVENTORY.csv"
CHECKSUMS = "SHA256SUMS.txt"
BOOKKEEPING = {INVENTORY, CHECKSUMS}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require_safe_path(name: str) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name or not name:
        raise ValueError(f"Unsafe archive path: {name!r}")


def archive_files(payload: bytes) -> dict[str, bytes]:
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        files = {}
        for member in archive.infolist():
            require_safe_path(member.filename)
            if member.is_dir():
                continue
            if member.filename in files:
                raise ValueError(f"Duplicate archive member: {member.filename}")
            if (member.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError(f"Symbolic-link archive member: {member.filename}")
            files[member.filename] = archive.read(member)
        return files


def verify_files(files: dict[str, bytes], label: str) -> dict:
    if not BOOKKEEPING <= files.keys():
        raise ValueError(f"Missing public inventory/checksums: {label}")
    rows = list(csv.DictReader(io.StringIO(files[INVENTORY].decode("utf-8"))))
    listed = {row["path"] for row in rows}
    expected = files.keys() - BOOKKEEPING
    if len(rows) != len(listed) or listed != expected:
        raise ValueError(f"Inventory coverage mismatch: {label}")
    for row in rows:
        payload = files[row["path"]]
        if int(row["bytes"]) != len(payload) or row["sha256"] != sha256(payload):
            raise ValueError(f"Inventory digest mismatch: {label}/{row['path']}")
    checksums = {}
    for line in files[CHECKSUMS].decode("utf-8").splitlines():
        expected_hash, name = line.split("  ", 1)
        if name in checksums:
            raise ValueError(f"Duplicate checksum path: {label}/{name}")
        checksums[name] = expected_hash
    if checksums.keys() != files.keys() - {CHECKSUMS}:
        raise ValueError(f"Checksum coverage mismatch: {label}")
    for name, expected_hash in checksums.items():
        if sha256(files[name]) != expected_hash:
            raise ValueError(f"Checksum digest mismatch: {label}/{name}")
    nested = []
    for name, payload in sorted(files.items()):
        if name.endswith(".zip"):
            if "PUBLIC_SUBSET" not in name:
                raise ValueError(f"Unexpected non-public nested ZIP: {label}/{name}")
            nested.append(verify_files(archive_files(payload), f"{label}/{name}!"))
    return {"label": label, "files": len(files), "verified": True, "nested": nested}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, help="extracted public root or public ZIP")
    args = parser.parse_args()
    if args.path.is_dir():
        files = {
            path.relative_to(args.path).as_posix(): path.read_bytes()
            for path in args.path.rglob("*") if path.is_file()
        }
    else:
        raw_files = archive_files(args.path.read_bytes())
        roots = {PurePosixPath(name).parts[0] for name in raw_files}
        if len(roots) != 1:
            raise ValueError("Expected one top-level public release directory")
        root = next(iter(roots)) + "/"
        files = {name[len(root):]: payload for name, payload in raw_files.items()}
    print(json.dumps(verify_files(files, args.path.name), indent=2))


if __name__ == "__main__":
    main()
